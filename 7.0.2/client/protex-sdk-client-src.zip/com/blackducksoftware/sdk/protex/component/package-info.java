@javax.xml.bind.annotation.XmlSchema(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component")
package com.blackducksoftware.sdk.protex.component;
