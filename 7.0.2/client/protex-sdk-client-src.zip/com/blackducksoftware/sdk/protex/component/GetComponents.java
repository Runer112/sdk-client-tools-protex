
package com.blackducksoftware.sdk.protex.component;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.ComponentPageFilter;


/**
 * <p>Java class for getComponents complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getComponents">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="pageFilter" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentPageFilter" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getComponents", propOrder = {
    "pageFilter"
})
public class GetComponents {

    protected ComponentPageFilter pageFilter;

    /**
     * Gets the value of the pageFilter property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentPageFilter }
     *     
     */
    public ComponentPageFilter getPageFilter() {
        return pageFilter;
    }

    /**
     * Sets the value of the pageFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentPageFilter }
     *     
     */
    public void setPageFilter(ComponentPageFilter value) {
        this.pageFilter = value;
    }

}
