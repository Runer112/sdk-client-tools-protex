
package com.blackducksoftware.sdk.protex.component;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createComponent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createComponent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="componentRequest" type="{urn:protex.blackducksoftware.com:sdk:v7.0:component}componentRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createComponent", propOrder = {
    "componentRequest"
})
public class CreateComponent {

    protected ComponentRequest componentRequest;

    /**
     * Gets the value of the componentRequest property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentRequest }
     *     
     */
    public ComponentRequest getComponentRequest() {
        return componentRequest;
    }

    /**
     * Sets the value of the componentRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentRequest }
     *     
     */
    public void setComponentRequest(ComponentRequest value) {
        this.componentRequest = value;
    }

}
