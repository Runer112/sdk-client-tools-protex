
package com.blackducksoftware.sdk.protex.component.custom;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.ComponentKey;


/**
 * <p>Java class for resetFileDiscoveryPattern complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="resetFileDiscoveryPattern">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="customComponentKey" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentKey" minOccurs="0"/>
 *         &lt;element name="patternId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "resetFileDiscoveryPattern", propOrder = {
    "customComponentKey",
    "patternId"
})
public class ResetFileDiscoveryPattern {

    protected ComponentKey customComponentKey;
    protected String patternId;

    /**
     * Gets the value of the customComponentKey property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentKey }
     *     
     */
    public ComponentKey getCustomComponentKey() {
        return customComponentKey;
    }

    /**
     * Sets the value of the customComponentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentKey }
     *     
     */
    public void setCustomComponentKey(ComponentKey value) {
        this.customComponentKey = value;
    }

    /**
     * Gets the value of the patternId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPatternId() {
        return patternId;
    }

    /**
     * Sets the value of the patternId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPatternId(String value) {
        this.patternId = value;
    }

}
