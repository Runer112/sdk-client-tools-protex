
package com.blackducksoftware.sdk.protex.component.custom;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.blackducksoftware.sdk.protex.component.custom package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _StartCodeprintingResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "startCodeprintingResponse");
    private final static QName _UpdateFileDiscoveryPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "updateFileDiscoveryPatternResponse");
    private final static QName _RemoveFileDiscoveryPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "removeFileDiscoveryPattern");
    private final static QName _ResetFileDiscoveryPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "resetFileDiscoveryPattern");
    private final static QName _GetCustomComponentSettings_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "getCustomComponentSettings");
    private final static QName _ResetFileDiscoveryPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "resetFileDiscoveryPatternResponse");
    private final static QName _GetFileDiscoveryPatternsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "getFileDiscoveryPatternsResponse");
    private final static QName _GetCustomComponentSettingsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "getCustomComponentSettingsResponse");
    private final static QName _UpdateCustomComponentSettings_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "updateCustomComponentSettings");
    private final static QName _CancelCodeprinting_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "cancelCodeprinting");
    private final static QName _StartCodeprinting_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "startCodeprinting");
    private final static QName _GetCodeprintingStatus_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "getCodeprintingStatus");
    private final static QName _GetFileDiscoveryPatterns_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "getFileDiscoveryPatterns");
    private final static QName _GetCustomComponentSetting_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "getCustomComponentSetting");
    private final static QName _RemoveFileDiscoveryPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "removeFileDiscoveryPatternResponse");
    private final static QName _UpdateFileDiscoveryPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "updateFileDiscoveryPattern");
    private final static QName _GetCustomComponentSettingResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "getCustomComponentSettingResponse");
    private final static QName _GetCodeprintingStatusResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "getCodeprintingStatusResponse");
    private final static QName _CancelCodeprintingResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "cancelCodeprintingResponse");
    private final static QName _UpdateCustomComponentSettingsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "updateCustomComponentSettingsResponse");
    private final static QName _AddFileDiscoveryPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "addFileDiscoveryPatternResponse");
    private final static QName _AddFileDiscoveryPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", "addFileDiscoveryPattern");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.blackducksoftware.sdk.protex.component.custom
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UpdateFileDiscoveryPattern }
     * 
     */
    public UpdateFileDiscoveryPattern createUpdateFileDiscoveryPattern() {
        return new UpdateFileDiscoveryPattern();
    }

    /**
     * Create an instance of {@link GetCustomComponentSettingResponse }
     * 
     */
    public GetCustomComponentSettingResponse createGetCustomComponentSettingResponse() {
        return new GetCustomComponentSettingResponse();
    }

    /**
     * Create an instance of {@link GetCodeprintingStatusResponse }
     * 
     */
    public GetCodeprintingStatusResponse createGetCodeprintingStatusResponse() {
        return new GetCodeprintingStatusResponse();
    }

    /**
     * Create an instance of {@link CancelCodeprintingResponse }
     * 
     */
    public CancelCodeprintingResponse createCancelCodeprintingResponse() {
        return new CancelCodeprintingResponse();
    }

    /**
     * Create an instance of {@link UpdateCustomComponentSettingsResponse }
     * 
     */
    public UpdateCustomComponentSettingsResponse createUpdateCustomComponentSettingsResponse() {
        return new UpdateCustomComponentSettingsResponse();
    }

    /**
     * Create an instance of {@link AddFileDiscoveryPatternResponse }
     * 
     */
    public AddFileDiscoveryPatternResponse createAddFileDiscoveryPatternResponse() {
        return new AddFileDiscoveryPatternResponse();
    }

    /**
     * Create an instance of {@link AddFileDiscoveryPattern }
     * 
     */
    public AddFileDiscoveryPattern createAddFileDiscoveryPattern() {
        return new AddFileDiscoveryPattern();
    }

    /**
     * Create an instance of {@link GetCodeprintingStatus }
     * 
     */
    public GetCodeprintingStatus createGetCodeprintingStatus() {
        return new GetCodeprintingStatus();
    }

    /**
     * Create an instance of {@link GetFileDiscoveryPatterns }
     * 
     */
    public GetFileDiscoveryPatterns createGetFileDiscoveryPatterns() {
        return new GetFileDiscoveryPatterns();
    }

    /**
     * Create an instance of {@link GetCustomComponentSetting }
     * 
     */
    public GetCustomComponentSetting createGetCustomComponentSetting() {
        return new GetCustomComponentSetting();
    }

    /**
     * Create an instance of {@link RemoveFileDiscoveryPatternResponse }
     * 
     */
    public RemoveFileDiscoveryPatternResponse createRemoveFileDiscoveryPatternResponse() {
        return new RemoveFileDiscoveryPatternResponse();
    }

    /**
     * Create an instance of {@link ResetFileDiscoveryPatternResponse }
     * 
     */
    public ResetFileDiscoveryPatternResponse createResetFileDiscoveryPatternResponse() {
        return new ResetFileDiscoveryPatternResponse();
    }

    /**
     * Create an instance of {@link GetCustomComponentSettings }
     * 
     */
    public GetCustomComponentSettings createGetCustomComponentSettings() {
        return new GetCustomComponentSettings();
    }

    /**
     * Create an instance of {@link GetCustomComponentSettingsResponse }
     * 
     */
    public GetCustomComponentSettingsResponse createGetCustomComponentSettingsResponse() {
        return new GetCustomComponentSettingsResponse();
    }

    /**
     * Create an instance of {@link GetFileDiscoveryPatternsResponse }
     * 
     */
    public GetFileDiscoveryPatternsResponse createGetFileDiscoveryPatternsResponse() {
        return new GetFileDiscoveryPatternsResponse();
    }

    /**
     * Create an instance of {@link UpdateCustomComponentSettings }
     * 
     */
    public UpdateCustomComponentSettings createUpdateCustomComponentSettings() {
        return new UpdateCustomComponentSettings();
    }

    /**
     * Create an instance of {@link StartCodeprinting }
     * 
     */
    public StartCodeprinting createStartCodeprinting() {
        return new StartCodeprinting();
    }

    /**
     * Create an instance of {@link CancelCodeprinting }
     * 
     */
    public CancelCodeprinting createCancelCodeprinting() {
        return new CancelCodeprinting();
    }

    /**
     * Create an instance of {@link UpdateFileDiscoveryPatternResponse }
     * 
     */
    public UpdateFileDiscoveryPatternResponse createUpdateFileDiscoveryPatternResponse() {
        return new UpdateFileDiscoveryPatternResponse();
    }

    /**
     * Create an instance of {@link StartCodeprintingResponse }
     * 
     */
    public StartCodeprintingResponse createStartCodeprintingResponse() {
        return new StartCodeprintingResponse();
    }

    /**
     * Create an instance of {@link RemoveFileDiscoveryPattern }
     * 
     */
    public RemoveFileDiscoveryPattern createRemoveFileDiscoveryPattern() {
        return new RemoveFileDiscoveryPattern();
    }

    /**
     * Create an instance of {@link ResetFileDiscoveryPattern }
     * 
     */
    public ResetFileDiscoveryPattern createResetFileDiscoveryPattern() {
        return new ResetFileDiscoveryPattern();
    }

    /**
     * Create an instance of {@link CustomComponentSettings }
     * 
     */
    public CustomComponentSettings createCustomComponentSettings() {
        return new CustomComponentSettings();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StartCodeprintingResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "startCodeprintingResponse")
    public JAXBElement<StartCodeprintingResponse> createStartCodeprintingResponse(StartCodeprintingResponse value) {
        return new JAXBElement<StartCodeprintingResponse>(_StartCodeprintingResponse_QNAME, StartCodeprintingResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateFileDiscoveryPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "updateFileDiscoveryPatternResponse")
    public JAXBElement<UpdateFileDiscoveryPatternResponse> createUpdateFileDiscoveryPatternResponse(UpdateFileDiscoveryPatternResponse value) {
        return new JAXBElement<UpdateFileDiscoveryPatternResponse>(_UpdateFileDiscoveryPatternResponse_QNAME, UpdateFileDiscoveryPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveFileDiscoveryPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "removeFileDiscoveryPattern")
    public JAXBElement<RemoveFileDiscoveryPattern> createRemoveFileDiscoveryPattern(RemoveFileDiscoveryPattern value) {
        return new JAXBElement<RemoveFileDiscoveryPattern>(_RemoveFileDiscoveryPattern_QNAME, RemoveFileDiscoveryPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResetFileDiscoveryPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "resetFileDiscoveryPattern")
    public JAXBElement<ResetFileDiscoveryPattern> createResetFileDiscoveryPattern(ResetFileDiscoveryPattern value) {
        return new JAXBElement<ResetFileDiscoveryPattern>(_ResetFileDiscoveryPattern_QNAME, ResetFileDiscoveryPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCustomComponentSettings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "getCustomComponentSettings")
    public JAXBElement<GetCustomComponentSettings> createGetCustomComponentSettings(GetCustomComponentSettings value) {
        return new JAXBElement<GetCustomComponentSettings>(_GetCustomComponentSettings_QNAME, GetCustomComponentSettings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResetFileDiscoveryPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "resetFileDiscoveryPatternResponse")
    public JAXBElement<ResetFileDiscoveryPatternResponse> createResetFileDiscoveryPatternResponse(ResetFileDiscoveryPatternResponse value) {
        return new JAXBElement<ResetFileDiscoveryPatternResponse>(_ResetFileDiscoveryPatternResponse_QNAME, ResetFileDiscoveryPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileDiscoveryPatternsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "getFileDiscoveryPatternsResponse")
    public JAXBElement<GetFileDiscoveryPatternsResponse> createGetFileDiscoveryPatternsResponse(GetFileDiscoveryPatternsResponse value) {
        return new JAXBElement<GetFileDiscoveryPatternsResponse>(_GetFileDiscoveryPatternsResponse_QNAME, GetFileDiscoveryPatternsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCustomComponentSettingsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "getCustomComponentSettingsResponse")
    public JAXBElement<GetCustomComponentSettingsResponse> createGetCustomComponentSettingsResponse(GetCustomComponentSettingsResponse value) {
        return new JAXBElement<GetCustomComponentSettingsResponse>(_GetCustomComponentSettingsResponse_QNAME, GetCustomComponentSettingsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateCustomComponentSettings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "updateCustomComponentSettings")
    public JAXBElement<UpdateCustomComponentSettings> createUpdateCustomComponentSettings(UpdateCustomComponentSettings value) {
        return new JAXBElement<UpdateCustomComponentSettings>(_UpdateCustomComponentSettings_QNAME, UpdateCustomComponentSettings.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CancelCodeprinting }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "cancelCodeprinting")
    public JAXBElement<CancelCodeprinting> createCancelCodeprinting(CancelCodeprinting value) {
        return new JAXBElement<CancelCodeprinting>(_CancelCodeprinting_QNAME, CancelCodeprinting.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StartCodeprinting }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "startCodeprinting")
    public JAXBElement<StartCodeprinting> createStartCodeprinting(StartCodeprinting value) {
        return new JAXBElement<StartCodeprinting>(_StartCodeprinting_QNAME, StartCodeprinting.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCodeprintingStatus }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "getCodeprintingStatus")
    public JAXBElement<GetCodeprintingStatus> createGetCodeprintingStatus(GetCodeprintingStatus value) {
        return new JAXBElement<GetCodeprintingStatus>(_GetCodeprintingStatus_QNAME, GetCodeprintingStatus.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileDiscoveryPatterns }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "getFileDiscoveryPatterns")
    public JAXBElement<GetFileDiscoveryPatterns> createGetFileDiscoveryPatterns(GetFileDiscoveryPatterns value) {
        return new JAXBElement<GetFileDiscoveryPatterns>(_GetFileDiscoveryPatterns_QNAME, GetFileDiscoveryPatterns.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCustomComponentSetting }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "getCustomComponentSetting")
    public JAXBElement<GetCustomComponentSetting> createGetCustomComponentSetting(GetCustomComponentSetting value) {
        return new JAXBElement<GetCustomComponentSetting>(_GetCustomComponentSetting_QNAME, GetCustomComponentSetting.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveFileDiscoveryPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "removeFileDiscoveryPatternResponse")
    public JAXBElement<RemoveFileDiscoveryPatternResponse> createRemoveFileDiscoveryPatternResponse(RemoveFileDiscoveryPatternResponse value) {
        return new JAXBElement<RemoveFileDiscoveryPatternResponse>(_RemoveFileDiscoveryPatternResponse_QNAME, RemoveFileDiscoveryPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateFileDiscoveryPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "updateFileDiscoveryPattern")
    public JAXBElement<UpdateFileDiscoveryPattern> createUpdateFileDiscoveryPattern(UpdateFileDiscoveryPattern value) {
        return new JAXBElement<UpdateFileDiscoveryPattern>(_UpdateFileDiscoveryPattern_QNAME, UpdateFileDiscoveryPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCustomComponentSettingResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "getCustomComponentSettingResponse")
    public JAXBElement<GetCustomComponentSettingResponse> createGetCustomComponentSettingResponse(GetCustomComponentSettingResponse value) {
        return new JAXBElement<GetCustomComponentSettingResponse>(_GetCustomComponentSettingResponse_QNAME, GetCustomComponentSettingResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCodeprintingStatusResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "getCodeprintingStatusResponse")
    public JAXBElement<GetCodeprintingStatusResponse> createGetCodeprintingStatusResponse(GetCodeprintingStatusResponse value) {
        return new JAXBElement<GetCodeprintingStatusResponse>(_GetCodeprintingStatusResponse_QNAME, GetCodeprintingStatusResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CancelCodeprintingResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "cancelCodeprintingResponse")
    public JAXBElement<CancelCodeprintingResponse> createCancelCodeprintingResponse(CancelCodeprintingResponse value) {
        return new JAXBElement<CancelCodeprintingResponse>(_CancelCodeprintingResponse_QNAME, CancelCodeprintingResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateCustomComponentSettingsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "updateCustomComponentSettingsResponse")
    public JAXBElement<UpdateCustomComponentSettingsResponse> createUpdateCustomComponentSettingsResponse(UpdateCustomComponentSettingsResponse value) {
        return new JAXBElement<UpdateCustomComponentSettingsResponse>(_UpdateCustomComponentSettingsResponse_QNAME, UpdateCustomComponentSettingsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddFileDiscoveryPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "addFileDiscoveryPatternResponse")
    public JAXBElement<AddFileDiscoveryPatternResponse> createAddFileDiscoveryPatternResponse(AddFileDiscoveryPatternResponse value) {
        return new JAXBElement<AddFileDiscoveryPatternResponse>(_AddFileDiscoveryPatternResponse_QNAME, AddFileDiscoveryPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddFileDiscoveryPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:customcomponentmanagement", name = "addFileDiscoveryPattern")
    public JAXBElement<AddFileDiscoveryPattern> createAddFileDiscoveryPattern(AddFileDiscoveryPattern value) {
        return new JAXBElement<AddFileDiscoveryPattern>(_AddFileDiscoveryPattern_QNAME, AddFileDiscoveryPattern.class, null, value);
    }

}
