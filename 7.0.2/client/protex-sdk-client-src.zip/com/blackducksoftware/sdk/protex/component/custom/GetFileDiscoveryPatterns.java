
package com.blackducksoftware.sdk.protex.component.custom;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.ComponentKey;
import com.blackducksoftware.sdk.protex.common.FileDiscoveryPatternPageFilter;
import com.blackducksoftware.sdk.protex.common.PatternOriginType;


/**
 * <p>Java class for getFileDiscoveryPatterns complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getFileDiscoveryPatterns">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="customComponentKey" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentKey" minOccurs="0"/>
 *         &lt;element name="originTypes" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}patternOriginType" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="pageFilter" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}fileDiscoveryPatternPageFilter" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getFileDiscoveryPatterns", propOrder = {
    "customComponentKey",
    "originTypes",
    "pageFilter"
})
public class GetFileDiscoveryPatterns {

    protected ComponentKey customComponentKey;
    protected List<PatternOriginType> originTypes;
    protected FileDiscoveryPatternPageFilter pageFilter;

    /**
     * Gets the value of the customComponentKey property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentKey }
     *     
     */
    public ComponentKey getCustomComponentKey() {
        return customComponentKey;
    }

    /**
     * Sets the value of the customComponentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentKey }
     *     
     */
    public void setCustomComponentKey(ComponentKey value) {
        this.customComponentKey = value;
    }

    /**
     * Gets the value of the originTypes property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the originTypes property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getOriginTypes().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PatternOriginType }
     * 
     * 
     */
    public List<PatternOriginType> getOriginTypes() {
        if (originTypes == null) {
            originTypes = new ArrayList<PatternOriginType>();
        }
        return this.originTypes;
    }

    /**
     * Gets the value of the pageFilter property.
     * 
     * @return
     *     possible object is
     *     {@link FileDiscoveryPatternPageFilter }
     *     
     */
    public FileDiscoveryPatternPageFilter getPageFilter() {
        return pageFilter;
    }

    /**
     * Sets the value of the pageFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileDiscoveryPatternPageFilter }
     *     
     */
    public void setPageFilter(FileDiscoveryPatternPageFilter value) {
        this.pageFilter = value;
    }

}
