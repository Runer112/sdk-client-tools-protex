
package com.blackducksoftware.sdk.protex.component.custom;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.ComponentKey;
import com.blackducksoftware.sdk.protex.common.FileDiscoveryPatternRequest;


/**
 * <p>Java class for addFileDiscoveryPattern complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="addFileDiscoveryPattern">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="customComponentKey" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}componentKey" minOccurs="0"/>
 *         &lt;element name="patternRequest" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}fileDiscoveryPatternRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "addFileDiscoveryPattern", propOrder = {
    "customComponentKey",
    "patternRequest"
})
public class AddFileDiscoveryPattern {

    protected ComponentKey customComponentKey;
    protected FileDiscoveryPatternRequest patternRequest;

    /**
     * Gets the value of the customComponentKey property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentKey }
     *     
     */
    public ComponentKey getCustomComponentKey() {
        return customComponentKey;
    }

    /**
     * Sets the value of the customComponentKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentKey }
     *     
     */
    public void setCustomComponentKey(ComponentKey value) {
        this.customComponentKey = value;
    }

    /**
     * Gets the value of the patternRequest property.
     * 
     * @return
     *     possible object is
     *     {@link FileDiscoveryPatternRequest }
     *     
     */
    public FileDiscoveryPatternRequest getPatternRequest() {
        return patternRequest;
    }

    /**
     * Sets the value of the patternRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileDiscoveryPatternRequest }
     *     
     */
    public void setPatternRequest(FileDiscoveryPatternRequest value) {
        this.patternRequest = value;
    }

}
