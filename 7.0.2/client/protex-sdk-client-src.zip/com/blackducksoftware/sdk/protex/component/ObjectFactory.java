
package com.blackducksoftware.sdk.protex.component;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.blackducksoftware.sdk.protex.component package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetComponentsByName_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentsByName");
    private final static QName _UpdateComponent_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "updateComponent");
    private final static QName _SuggestComponents_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "suggestComponents");
    private final static QName _GetComponentByKeyResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentByKeyResponse");
    private final static QName _GetComponentVersionsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentVersionsResponse");
    private final static QName _RemoveComponentObligation_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "removeComponentObligation");
    private final static QName _GetTaggedComponents_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getTaggedComponents");
    private final static QName _AddTagResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "addTagResponse");
    private final static QName _CheckComponentsExist_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "checkComponentsExist");
    private final static QName _GetTagsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getTagsResponse");
    private final static QName _GetComponentsByKeyResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentsByKeyResponse");
    private final static QName _GetComponentByKey_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentByKey");
    private final static QName _CreateComponentResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "createComponentResponse");
    private final static QName _GetHashesByComponent_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getHashesByComponent");
    private final static QName _GetComponentObligationsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentObligationsResponse");
    private final static QName _AddComponentObligationUsingReference_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "addComponentObligationUsingReference");
    private final static QName _DeleteComponent_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "deleteComponent");
    private final static QName _ResetComponent_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "resetComponent");
    private final static QName _GetTaggedComponentsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getTaggedComponentsResponse");
    private final static QName _UpdateComponentObligationResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "updateComponentObligationResponse");
    private final static QName _AddTag_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "addTag");
    private final static QName _RemoveComponentObligationResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "removeComponentObligationResponse");
    private final static QName _GetComponentsByHashResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentsByHashResponse");
    private final static QName _GetComponentsByHash_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentsByHash");
    private final static QName _AddComponentObligationResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "addComponentObligationResponse");
    private final static QName _UpdateComponentObligation_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "updateComponentObligation");
    private final static QName _SuggestComponentsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "suggestComponentsResponse");
    private final static QName _GetTags_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getTags");
    private final static QName _GetComponentsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentsResponse");
    private final static QName _GetComponents_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponents");
    private final static QName _ResetComponentResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "resetComponentResponse");
    private final static QName _AddComponentObligation_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "addComponentObligation");
    private final static QName _GetHashesByComponentResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getHashesByComponentResponse");
    private final static QName _GetComponentsByKey_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentsByKey");
    private final static QName _DeleteComponentResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "deleteComponentResponse");
    private final static QName _CreateComponent_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "createComponent");
    private final static QName _GetComponentVersions_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentVersions");
    private final static QName _RemoveTag_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "removeTag");
    private final static QName _UpdateComponentResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "updateComponentResponse");
    private final static QName _RemoveTagResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "removeTagResponse");
    private final static QName _GetComponentsByNameResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentsByNameResponse");
    private final static QName _AddComponentObligationUsingReferenceResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "addComponentObligationUsingReferenceResponse");
    private final static QName _GetComponentObligations_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "getComponentObligations");
    private final static QName _CheckComponentsExistResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:component", "checkComponentsExistResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.blackducksoftware.sdk.protex.component
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetHashesByComponentResponse }
     * 
     */
    public GetHashesByComponentResponse createGetHashesByComponentResponse() {
        return new GetHashesByComponentResponse();
    }

    /**
     * Create an instance of {@link GetComponentVersions }
     * 
     */
    public GetComponentVersions createGetComponentVersions() {
        return new GetComponentVersions();
    }

    /**
     * Create an instance of {@link RemoveTag }
     * 
     */
    public RemoveTag createRemoveTag() {
        return new RemoveTag();
    }

    /**
     * Create an instance of {@link DeleteComponentResponse }
     * 
     */
    public DeleteComponentResponse createDeleteComponentResponse() {
        return new DeleteComponentResponse();
    }

    /**
     * Create an instance of {@link GetComponentsByKey }
     * 
     */
    public GetComponentsByKey createGetComponentsByKey() {
        return new GetComponentsByKey();
    }

    /**
     * Create an instance of {@link CreateComponent }
     * 
     */
    public CreateComponent createCreateComponent() {
        return new CreateComponent();
    }

    /**
     * Create an instance of {@link UpdateComponentObligation }
     * 
     */
    public UpdateComponentObligation createUpdateComponentObligation() {
        return new UpdateComponentObligation();
    }

    /**
     * Create an instance of {@link AddComponentObligationResponse }
     * 
     */
    public AddComponentObligationResponse createAddComponentObligationResponse() {
        return new AddComponentObligationResponse();
    }

    /**
     * Create an instance of {@link GetComponentsByHash }
     * 
     */
    public GetComponentsByHash createGetComponentsByHash() {
        return new GetComponentsByHash();
    }

    /**
     * Create an instance of {@link GetComponentsByHashResponse }
     * 
     */
    public GetComponentsByHashResponse createGetComponentsByHashResponse() {
        return new GetComponentsByHashResponse();
    }

    /**
     * Create an instance of {@link SuggestComponentsResponse }
     * 
     */
    public SuggestComponentsResponse createSuggestComponentsResponse() {
        return new SuggestComponentsResponse();
    }

    /**
     * Create an instance of {@link RemoveComponentObligationResponse }
     * 
     */
    public RemoveComponentObligationResponse createRemoveComponentObligationResponse() {
        return new RemoveComponentObligationResponse();
    }

    /**
     * Create an instance of {@link ResetComponentResponse }
     * 
     */
    public ResetComponentResponse createResetComponentResponse() {
        return new ResetComponentResponse();
    }

    /**
     * Create an instance of {@link AddComponentObligation }
     * 
     */
    public AddComponentObligation createAddComponentObligation() {
        return new AddComponentObligation();
    }

    /**
     * Create an instance of {@link GetTags }
     * 
     */
    public GetTags createGetTags() {
        return new GetTags();
    }

    /**
     * Create an instance of {@link GetComponentsResponse }
     * 
     */
    public GetComponentsResponse createGetComponentsResponse() {
        return new GetComponentsResponse();
    }

    /**
     * Create an instance of {@link GetComponents }
     * 
     */
    public GetComponents createGetComponents() {
        return new GetComponents();
    }

    /**
     * Create an instance of {@link GetComponentObligations }
     * 
     */
    public GetComponentObligations createGetComponentObligations() {
        return new GetComponentObligations();
    }

    /**
     * Create an instance of {@link CheckComponentsExistResponse }
     * 
     */
    public CheckComponentsExistResponse createCheckComponentsExistResponse() {
        return new CheckComponentsExistResponse();
    }

    /**
     * Create an instance of {@link GetComponentsByNameResponse }
     * 
     */
    public GetComponentsByNameResponse createGetComponentsByNameResponse() {
        return new GetComponentsByNameResponse();
    }

    /**
     * Create an instance of {@link UpdateComponentResponse }
     * 
     */
    public UpdateComponentResponse createUpdateComponentResponse() {
        return new UpdateComponentResponse();
    }

    /**
     * Create an instance of {@link RemoveTagResponse }
     * 
     */
    public RemoveTagResponse createRemoveTagResponse() {
        return new RemoveTagResponse();
    }

    /**
     * Create an instance of {@link AddComponentObligationUsingReferenceResponse }
     * 
     */
    public AddComponentObligationUsingReferenceResponse createAddComponentObligationUsingReferenceResponse() {
        return new AddComponentObligationUsingReferenceResponse();
    }

    /**
     * Create an instance of {@link GetComponentByKeyResponse }
     * 
     */
    public GetComponentByKeyResponse createGetComponentByKeyResponse() {
        return new GetComponentByKeyResponse();
    }

    /**
     * Create an instance of {@link RemoveComponentObligation }
     * 
     */
    public RemoveComponentObligation createRemoveComponentObligation() {
        return new RemoveComponentObligation();
    }

    /**
     * Create an instance of {@link GetComponentVersionsResponse }
     * 
     */
    public GetComponentVersionsResponse createGetComponentVersionsResponse() {
        return new GetComponentVersionsResponse();
    }

    /**
     * Create an instance of {@link SuggestComponents }
     * 
     */
    public SuggestComponents createSuggestComponents() {
        return new SuggestComponents();
    }

    /**
     * Create an instance of {@link UpdateComponent }
     * 
     */
    public UpdateComponent createUpdateComponent() {
        return new UpdateComponent();
    }

    /**
     * Create an instance of {@link GetComponentsByName }
     * 
     */
    public GetComponentsByName createGetComponentsByName() {
        return new GetComponentsByName();
    }

    /**
     * Create an instance of {@link GetTaggedComponentsResponse }
     * 
     */
    public GetTaggedComponentsResponse createGetTaggedComponentsResponse() {
        return new GetTaggedComponentsResponse();
    }

    /**
     * Create an instance of {@link ResetComponent }
     * 
     */
    public ResetComponent createResetComponent() {
        return new ResetComponent();
    }

    /**
     * Create an instance of {@link DeleteComponent }
     * 
     */
    public DeleteComponent createDeleteComponent() {
        return new DeleteComponent();
    }

    /**
     * Create an instance of {@link UpdateComponentObligationResponse }
     * 
     */
    public UpdateComponentObligationResponse createUpdateComponentObligationResponse() {
        return new UpdateComponentObligationResponse();
    }

    /**
     * Create an instance of {@link AddTag }
     * 
     */
    public AddTag createAddTag() {
        return new AddTag();
    }

    /**
     * Create an instance of {@link GetTagsResponse }
     * 
     */
    public GetTagsResponse createGetTagsResponse() {
        return new GetTagsResponse();
    }

    /**
     * Create an instance of {@link CheckComponentsExist }
     * 
     */
    public CheckComponentsExist createCheckComponentsExist() {
        return new CheckComponentsExist();
    }

    /**
     * Create an instance of {@link AddTagResponse }
     * 
     */
    public AddTagResponse createAddTagResponse() {
        return new AddTagResponse();
    }

    /**
     * Create an instance of {@link GetTaggedComponents }
     * 
     */
    public GetTaggedComponents createGetTaggedComponents() {
        return new GetTaggedComponents();
    }

    /**
     * Create an instance of {@link GetHashesByComponent }
     * 
     */
    public GetHashesByComponent createGetHashesByComponent() {
        return new GetHashesByComponent();
    }

    /**
     * Create an instance of {@link CreateComponentResponse }
     * 
     */
    public CreateComponentResponse createCreateComponentResponse() {
        return new CreateComponentResponse();
    }

    /**
     * Create an instance of {@link AddComponentObligationUsingReference }
     * 
     */
    public AddComponentObligationUsingReference createAddComponentObligationUsingReference() {
        return new AddComponentObligationUsingReference();
    }

    /**
     * Create an instance of {@link GetComponentObligationsResponse }
     * 
     */
    public GetComponentObligationsResponse createGetComponentObligationsResponse() {
        return new GetComponentObligationsResponse();
    }

    /**
     * Create an instance of {@link GetComponentsByKeyResponse }
     * 
     */
    public GetComponentsByKeyResponse createGetComponentsByKeyResponse() {
        return new GetComponentsByKeyResponse();
    }

    /**
     * Create an instance of {@link GetComponentByKey }
     * 
     */
    public GetComponentByKey createGetComponentByKey() {
        return new GetComponentByKey();
    }

    /**
     * Create an instance of {@link Component }
     * 
     */
    public Component createComponent() {
        return new Component();
    }

    /**
     * Create an instance of {@link ComponentRequest }
     * 
     */
    public ComponentRequest createComponentRequest() {
        return new ComponentRequest();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentsByName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentsByName")
    public JAXBElement<GetComponentsByName> createGetComponentsByName(GetComponentsByName value) {
        return new JAXBElement<GetComponentsByName>(_GetComponentsByName_QNAME, GetComponentsByName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateComponent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "updateComponent")
    public JAXBElement<UpdateComponent> createUpdateComponent(UpdateComponent value) {
        return new JAXBElement<UpdateComponent>(_UpdateComponent_QNAME, UpdateComponent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuggestComponents }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "suggestComponents")
    public JAXBElement<SuggestComponents> createSuggestComponents(SuggestComponents value) {
        return new JAXBElement<SuggestComponents>(_SuggestComponents_QNAME, SuggestComponents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentByKeyResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentByKeyResponse")
    public JAXBElement<GetComponentByKeyResponse> createGetComponentByKeyResponse(GetComponentByKeyResponse value) {
        return new JAXBElement<GetComponentByKeyResponse>(_GetComponentByKeyResponse_QNAME, GetComponentByKeyResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentVersionsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentVersionsResponse")
    public JAXBElement<GetComponentVersionsResponse> createGetComponentVersionsResponse(GetComponentVersionsResponse value) {
        return new JAXBElement<GetComponentVersionsResponse>(_GetComponentVersionsResponse_QNAME, GetComponentVersionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveComponentObligation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "removeComponentObligation")
    public JAXBElement<RemoveComponentObligation> createRemoveComponentObligation(RemoveComponentObligation value) {
        return new JAXBElement<RemoveComponentObligation>(_RemoveComponentObligation_QNAME, RemoveComponentObligation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTaggedComponents }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getTaggedComponents")
    public JAXBElement<GetTaggedComponents> createGetTaggedComponents(GetTaggedComponents value) {
        return new JAXBElement<GetTaggedComponents>(_GetTaggedComponents_QNAME, GetTaggedComponents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddTagResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "addTagResponse")
    public JAXBElement<AddTagResponse> createAddTagResponse(AddTagResponse value) {
        return new JAXBElement<AddTagResponse>(_AddTagResponse_QNAME, AddTagResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CheckComponentsExist }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "checkComponentsExist")
    public JAXBElement<CheckComponentsExist> createCheckComponentsExist(CheckComponentsExist value) {
        return new JAXBElement<CheckComponentsExist>(_CheckComponentsExist_QNAME, CheckComponentsExist.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTagsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getTagsResponse")
    public JAXBElement<GetTagsResponse> createGetTagsResponse(GetTagsResponse value) {
        return new JAXBElement<GetTagsResponse>(_GetTagsResponse_QNAME, GetTagsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentsByKeyResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentsByKeyResponse")
    public JAXBElement<GetComponentsByKeyResponse> createGetComponentsByKeyResponse(GetComponentsByKeyResponse value) {
        return new JAXBElement<GetComponentsByKeyResponse>(_GetComponentsByKeyResponse_QNAME, GetComponentsByKeyResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentByKey }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentByKey")
    public JAXBElement<GetComponentByKey> createGetComponentByKey(GetComponentByKey value) {
        return new JAXBElement<GetComponentByKey>(_GetComponentByKey_QNAME, GetComponentByKey.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateComponentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "createComponentResponse")
    public JAXBElement<CreateComponentResponse> createCreateComponentResponse(CreateComponentResponse value) {
        return new JAXBElement<CreateComponentResponse>(_CreateComponentResponse_QNAME, CreateComponentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetHashesByComponent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getHashesByComponent")
    public JAXBElement<GetHashesByComponent> createGetHashesByComponent(GetHashesByComponent value) {
        return new JAXBElement<GetHashesByComponent>(_GetHashesByComponent_QNAME, GetHashesByComponent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentObligationsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentObligationsResponse")
    public JAXBElement<GetComponentObligationsResponse> createGetComponentObligationsResponse(GetComponentObligationsResponse value) {
        return new JAXBElement<GetComponentObligationsResponse>(_GetComponentObligationsResponse_QNAME, GetComponentObligationsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddComponentObligationUsingReference }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "addComponentObligationUsingReference")
    public JAXBElement<AddComponentObligationUsingReference> createAddComponentObligationUsingReference(AddComponentObligationUsingReference value) {
        return new JAXBElement<AddComponentObligationUsingReference>(_AddComponentObligationUsingReference_QNAME, AddComponentObligationUsingReference.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteComponent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "deleteComponent")
    public JAXBElement<DeleteComponent> createDeleteComponent(DeleteComponent value) {
        return new JAXBElement<DeleteComponent>(_DeleteComponent_QNAME, DeleteComponent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResetComponent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "resetComponent")
    public JAXBElement<ResetComponent> createResetComponent(ResetComponent value) {
        return new JAXBElement<ResetComponent>(_ResetComponent_QNAME, ResetComponent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTaggedComponentsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getTaggedComponentsResponse")
    public JAXBElement<GetTaggedComponentsResponse> createGetTaggedComponentsResponse(GetTaggedComponentsResponse value) {
        return new JAXBElement<GetTaggedComponentsResponse>(_GetTaggedComponentsResponse_QNAME, GetTaggedComponentsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateComponentObligationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "updateComponentObligationResponse")
    public JAXBElement<UpdateComponentObligationResponse> createUpdateComponentObligationResponse(UpdateComponentObligationResponse value) {
        return new JAXBElement<UpdateComponentObligationResponse>(_UpdateComponentObligationResponse_QNAME, UpdateComponentObligationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddTag }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "addTag")
    public JAXBElement<AddTag> createAddTag(AddTag value) {
        return new JAXBElement<AddTag>(_AddTag_QNAME, AddTag.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveComponentObligationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "removeComponentObligationResponse")
    public JAXBElement<RemoveComponentObligationResponse> createRemoveComponentObligationResponse(RemoveComponentObligationResponse value) {
        return new JAXBElement<RemoveComponentObligationResponse>(_RemoveComponentObligationResponse_QNAME, RemoveComponentObligationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentsByHashResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentsByHashResponse")
    public JAXBElement<GetComponentsByHashResponse> createGetComponentsByHashResponse(GetComponentsByHashResponse value) {
        return new JAXBElement<GetComponentsByHashResponse>(_GetComponentsByHashResponse_QNAME, GetComponentsByHashResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentsByHash }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentsByHash")
    public JAXBElement<GetComponentsByHash> createGetComponentsByHash(GetComponentsByHash value) {
        return new JAXBElement<GetComponentsByHash>(_GetComponentsByHash_QNAME, GetComponentsByHash.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddComponentObligationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "addComponentObligationResponse")
    public JAXBElement<AddComponentObligationResponse> createAddComponentObligationResponse(AddComponentObligationResponse value) {
        return new JAXBElement<AddComponentObligationResponse>(_AddComponentObligationResponse_QNAME, AddComponentObligationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateComponentObligation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "updateComponentObligation")
    public JAXBElement<UpdateComponentObligation> createUpdateComponentObligation(UpdateComponentObligation value) {
        return new JAXBElement<UpdateComponentObligation>(_UpdateComponentObligation_QNAME, UpdateComponentObligation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuggestComponentsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "suggestComponentsResponse")
    public JAXBElement<SuggestComponentsResponse> createSuggestComponentsResponse(SuggestComponentsResponse value) {
        return new JAXBElement<SuggestComponentsResponse>(_SuggestComponentsResponse_QNAME, SuggestComponentsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetTags }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getTags")
    public JAXBElement<GetTags> createGetTags(GetTags value) {
        return new JAXBElement<GetTags>(_GetTags_QNAME, GetTags.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentsResponse")
    public JAXBElement<GetComponentsResponse> createGetComponentsResponse(GetComponentsResponse value) {
        return new JAXBElement<GetComponentsResponse>(_GetComponentsResponse_QNAME, GetComponentsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponents }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponents")
    public JAXBElement<GetComponents> createGetComponents(GetComponents value) {
        return new JAXBElement<GetComponents>(_GetComponents_QNAME, GetComponents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResetComponentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "resetComponentResponse")
    public JAXBElement<ResetComponentResponse> createResetComponentResponse(ResetComponentResponse value) {
        return new JAXBElement<ResetComponentResponse>(_ResetComponentResponse_QNAME, ResetComponentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddComponentObligation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "addComponentObligation")
    public JAXBElement<AddComponentObligation> createAddComponentObligation(AddComponentObligation value) {
        return new JAXBElement<AddComponentObligation>(_AddComponentObligation_QNAME, AddComponentObligation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetHashesByComponentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getHashesByComponentResponse")
    public JAXBElement<GetHashesByComponentResponse> createGetHashesByComponentResponse(GetHashesByComponentResponse value) {
        return new JAXBElement<GetHashesByComponentResponse>(_GetHashesByComponentResponse_QNAME, GetHashesByComponentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentsByKey }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentsByKey")
    public JAXBElement<GetComponentsByKey> createGetComponentsByKey(GetComponentsByKey value) {
        return new JAXBElement<GetComponentsByKey>(_GetComponentsByKey_QNAME, GetComponentsByKey.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteComponentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "deleteComponentResponse")
    public JAXBElement<DeleteComponentResponse> createDeleteComponentResponse(DeleteComponentResponse value) {
        return new JAXBElement<DeleteComponentResponse>(_DeleteComponentResponse_QNAME, DeleteComponentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateComponent }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "createComponent")
    public JAXBElement<CreateComponent> createCreateComponent(CreateComponent value) {
        return new JAXBElement<CreateComponent>(_CreateComponent_QNAME, CreateComponent.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentVersions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentVersions")
    public JAXBElement<GetComponentVersions> createGetComponentVersions(GetComponentVersions value) {
        return new JAXBElement<GetComponentVersions>(_GetComponentVersions_QNAME, GetComponentVersions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveTag }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "removeTag")
    public JAXBElement<RemoveTag> createRemoveTag(RemoveTag value) {
        return new JAXBElement<RemoveTag>(_RemoveTag_QNAME, RemoveTag.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateComponentResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "updateComponentResponse")
    public JAXBElement<UpdateComponentResponse> createUpdateComponentResponse(UpdateComponentResponse value) {
        return new JAXBElement<UpdateComponentResponse>(_UpdateComponentResponse_QNAME, UpdateComponentResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveTagResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "removeTagResponse")
    public JAXBElement<RemoveTagResponse> createRemoveTagResponse(RemoveTagResponse value) {
        return new JAXBElement<RemoveTagResponse>(_RemoveTagResponse_QNAME, RemoveTagResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentsByNameResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentsByNameResponse")
    public JAXBElement<GetComponentsByNameResponse> createGetComponentsByNameResponse(GetComponentsByNameResponse value) {
        return new JAXBElement<GetComponentsByNameResponse>(_GetComponentsByNameResponse_QNAME, GetComponentsByNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddComponentObligationUsingReferenceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "addComponentObligationUsingReferenceResponse")
    public JAXBElement<AddComponentObligationUsingReferenceResponse> createAddComponentObligationUsingReferenceResponse(AddComponentObligationUsingReferenceResponse value) {
        return new JAXBElement<AddComponentObligationUsingReferenceResponse>(_AddComponentObligationUsingReferenceResponse_QNAME, AddComponentObligationUsingReferenceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentObligations }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "getComponentObligations")
    public JAXBElement<GetComponentObligations> createGetComponentObligations(GetComponentObligations value) {
        return new JAXBElement<GetComponentObligations>(_GetComponentObligations_QNAME, GetComponentObligations.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CheckComponentsExistResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:component", name = "checkComponentsExistResponse")
    public JAXBElement<CheckComponentsExistResponse> createCheckComponentsExistResponse(CheckComponentsExistResponse value) {
        return new JAXBElement<CheckComponentsExistResponse>(_CheckComponentsExistResponse_QNAME, CheckComponentsExistResponse.class, null, value);
    }

}
