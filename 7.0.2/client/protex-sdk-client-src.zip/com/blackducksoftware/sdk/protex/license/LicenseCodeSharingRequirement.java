
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for licenseCodeSharingRequirement.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="licenseCodeSharingRequirement">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="RECIPROCAL"/>
 *     &lt;enumeration value="WEAK_RECIPROCAL"/>
 *     &lt;enumeration value="PERMISSIVE"/>
 *     &lt;enumeration value="UNKNOWN"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "licenseCodeSharingRequirement")
@XmlEnum
public enum LicenseCodeSharingRequirement {

    RECIPROCAL,
    WEAK_RECIPROCAL,
    PERMISSIVE,
    UNKNOWN;

    public String value() {
        return name();
    }

    public static LicenseCodeSharingRequirement fromValue(String v) {
        return valueOf(v);
    }

}
