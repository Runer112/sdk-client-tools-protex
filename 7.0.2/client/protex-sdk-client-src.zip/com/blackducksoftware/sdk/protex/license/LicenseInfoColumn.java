
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for licenseInfoColumn.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="licenseInfoColumn">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="LICENSE_ID"/>
 *     &lt;enumeration value="LICENSE_NAME"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "licenseInfoColumn")
@XmlEnum
public enum LicenseInfoColumn {

    LICENSE_ID,
    LICENSE_NAME;

    public String value() {
        return name();
    }

    public static LicenseInfoColumn fromValue(String v) {
        return valueOf(v);
    }

}
