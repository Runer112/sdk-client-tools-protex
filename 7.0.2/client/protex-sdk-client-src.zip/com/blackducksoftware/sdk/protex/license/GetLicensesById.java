
package com.blackducksoftware.sdk.protex.license;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.GetBehavior;


/**
 * <p>Java class for getLicensesById complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getLicensesById">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="licenseIds" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="getBehavior" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}getBehavior" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getLicensesById", propOrder = {
    "licenseIds",
    "getBehavior"
})
public class GetLicensesById {

    protected List<String> licenseIds;
    protected GetBehavior getBehavior;

    /**
     * Gets the value of the licenseIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the licenseIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLicenseIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getLicenseIds() {
        if (licenseIds == null) {
            licenseIds = new ArrayList<String>();
        }
        return this.licenseIds;
    }

    /**
     * Gets the value of the getBehavior property.
     * 
     * @return
     *     possible object is
     *     {@link GetBehavior }
     *     
     */
    public GetBehavior getGetBehavior() {
        return getBehavior;
    }

    /**
     * Sets the value of the getBehavior property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetBehavior }
     *     
     */
    public void setGetBehavior(GetBehavior value) {
        this.getBehavior = value;
    }

}
