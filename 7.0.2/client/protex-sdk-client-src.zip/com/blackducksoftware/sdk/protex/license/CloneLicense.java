
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for cloneLicense complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="cloneLicense">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="clonedLicenseName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="originalLicenseId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cloneLicense", propOrder = {
    "clonedLicenseName",
    "originalLicenseId"
})
public class CloneLicense {

    protected String clonedLicenseName;
    protected String originalLicenseId;

    /**
     * Gets the value of the clonedLicenseName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClonedLicenseName() {
        return clonedLicenseName;
    }

    /**
     * Sets the value of the clonedLicenseName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClonedLicenseName(String value) {
        this.clonedLicenseName = value;
    }

    /**
     * Gets the value of the originalLicenseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginalLicenseId() {
        return originalLicenseId;
    }

    /**
     * Sets the value of the originalLicenseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginalLicenseId(String value) {
        this.originalLicenseId = value;
    }

}
