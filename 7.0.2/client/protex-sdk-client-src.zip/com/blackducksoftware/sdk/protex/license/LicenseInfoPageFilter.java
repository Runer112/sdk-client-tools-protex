
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.PageFilter;


/**
 * <p>Java class for licenseInfoPageFilter complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="licenseInfoPageFilter">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v7.0:common}pageFilter">
 *       &lt;sequence>
 *         &lt;element name="sortedColumn" type="{urn:protex.blackducksoftware.com:sdk:v7.0:license}licenseInfoColumn" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "licenseInfoPageFilter", propOrder = {
    "sortedColumn"
})
public class LicenseInfoPageFilter
    extends PageFilter
{

    protected LicenseInfoColumn sortedColumn;

    /**
     * Gets the value of the sortedColumn property.
     * 
     * @return
     *     possible object is
     *     {@link LicenseInfoColumn }
     *     
     */
    public LicenseInfoColumn getSortedColumn() {
        return sortedColumn;
    }

    /**
     * Sets the value of the sortedColumn property.
     * 
     * @param value
     *     allowed object is
     *     {@link LicenseInfoColumn }
     *     
     */
    public void setSortedColumn(LicenseInfoColumn value) {
        this.sortedColumn = value;
    }

}
