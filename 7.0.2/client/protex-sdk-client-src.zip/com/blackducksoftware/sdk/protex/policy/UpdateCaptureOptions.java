
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.CaptureOptions;


/**
 * <p>Java class for updateCaptureOptions complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateCaptureOptions">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="captureOptions" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}captureOptions" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateCaptureOptions", propOrder = {
    "captureOptions"
})
public class UpdateCaptureOptions {

    protected CaptureOptions captureOptions;

    /**
     * Gets the value of the captureOptions property.
     * 
     * @return
     *     possible object is
     *     {@link CaptureOptions }
     *     
     */
    public CaptureOptions getCaptureOptions() {
        return captureOptions;
    }

    /**
     * Sets the value of the captureOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link CaptureOptions }
     *     
     */
    public void setCaptureOptions(CaptureOptions value) {
        this.captureOptions = value;
    }

}
