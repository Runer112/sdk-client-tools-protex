
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.RapidIdConfigurationRequest;


/**
 * <p>Java class for updateRapidIdConfiguration complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateRapidIdConfiguration">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="configurationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="rapidIdConfigurationUpdateRequest" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}rapidIdConfigurationRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateRapidIdConfiguration", propOrder = {
    "configurationId",
    "rapidIdConfigurationUpdateRequest"
})
public class UpdateRapidIdConfiguration {

    protected Long configurationId;
    protected RapidIdConfigurationRequest rapidIdConfigurationUpdateRequest;

    /**
     * Gets the value of the configurationId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getConfigurationId() {
        return configurationId;
    }

    /**
     * Sets the value of the configurationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setConfigurationId(Long value) {
        this.configurationId = value;
    }

    /**
     * Gets the value of the rapidIdConfigurationUpdateRequest property.
     * 
     * @return
     *     possible object is
     *     {@link RapidIdConfigurationRequest }
     *     
     */
    public RapidIdConfigurationRequest getRapidIdConfigurationUpdateRequest() {
        return rapidIdConfigurationUpdateRequest;
    }

    /**
     * Sets the value of the rapidIdConfigurationUpdateRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link RapidIdConfigurationRequest }
     *     
     */
    public void setRapidIdConfigurationUpdateRequest(RapidIdConfigurationRequest value) {
        this.rapidIdConfigurationUpdateRequest = value;
    }

}
