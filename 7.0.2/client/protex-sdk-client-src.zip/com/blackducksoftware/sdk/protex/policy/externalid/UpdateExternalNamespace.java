
package com.blackducksoftware.sdk.protex.policy.externalid;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateExternalNamespace complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateExternalNamespace">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="namespaceUpdateRequest" type="{urn:protex.blackducksoftware.com:sdk:v7.0:externalid}externalNamespaceRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateExternalNamespace", propOrder = {
    "namespaceUpdateRequest"
})
public class UpdateExternalNamespace {

    protected ExternalNamespaceRequest namespaceUpdateRequest;

    /**
     * Gets the value of the namespaceUpdateRequest property.
     * 
     * @return
     *     possible object is
     *     {@link ExternalNamespaceRequest }
     *     
     */
    public ExternalNamespaceRequest getNamespaceUpdateRequest() {
        return namespaceUpdateRequest;
    }

    /**
     * Sets the value of the namespaceUpdateRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExternalNamespaceRequest }
     *     
     */
    public void setNamespaceUpdateRequest(ExternalNamespaceRequest value) {
        this.namespaceUpdateRequest = value;
    }

}
