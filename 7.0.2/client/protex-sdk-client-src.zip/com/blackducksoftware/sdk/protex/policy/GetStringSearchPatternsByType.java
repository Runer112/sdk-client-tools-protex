
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.StringSearchPatternOriginType;


/**
 * <p>Java class for getStringSearchPatternsByType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getStringSearchPatternsByType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="patternType" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}stringSearchPatternOriginType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getStringSearchPatternsByType", propOrder = {
    "patternType"
})
public class GetStringSearchPatternsByType {

    protected StringSearchPatternOriginType patternType;

    /**
     * Gets the value of the patternType property.
     * 
     * @return
     *     possible object is
     *     {@link StringSearchPatternOriginType }
     *     
     */
    public StringSearchPatternOriginType getPatternType() {
        return patternType;
    }

    /**
     * Sets the value of the patternType property.
     * 
     * @param value
     *     allowed object is
     *     {@link StringSearchPatternOriginType }
     *     
     */
    public void setPatternType(StringSearchPatternOriginType value) {
        this.patternType = value;
    }

}
