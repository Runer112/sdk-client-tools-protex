
package com.blackducksoftware.sdk.protex.policy.externalid;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createExternalIdMapping complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createExternalIdMapping">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="externalNamespaceKey" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="externalIdMapping" type="{urn:protex.blackducksoftware.com:sdk:v7.0:externalid}externalIdMapping" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createExternalIdMapping", propOrder = {
    "externalNamespaceKey",
    "externalIdMapping"
})
public class CreateExternalIdMapping {

    protected String externalNamespaceKey;
    protected ExternalIdMapping externalIdMapping;

    /**
     * Gets the value of the externalNamespaceKey property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getExternalNamespaceKey() {
        return externalNamespaceKey;
    }

    /**
     * Sets the value of the externalNamespaceKey property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setExternalNamespaceKey(String value) {
        this.externalNamespaceKey = value;
    }

    /**
     * Gets the value of the externalIdMapping property.
     * 
     * @return
     *     possible object is
     *     {@link ExternalIdMapping }
     *     
     */
    public ExternalIdMapping getExternalIdMapping() {
        return externalIdMapping;
    }

    /**
     * Sets the value of the externalIdMapping property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExternalIdMapping }
     *     
     */
    public void setExternalIdMapping(ExternalIdMapping value) {
        this.externalIdMapping = value;
    }

}
