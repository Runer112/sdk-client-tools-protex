
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for fileComparisonRepository complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="fileComparisonRepository">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="locationURL" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="type" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}fileComparisonRepositoryType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fileComparisonRepository", propOrder = {
    "locationURL",
    "type"
})
public class FileComparisonRepository {

    protected String locationURL;
    protected FileComparisonRepositoryType type;

    /**
     * Gets the value of the locationURL property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationURL() {
        return locationURL;
    }

    /**
     * Sets the value of the locationURL property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationURL(String value) {
        this.locationURL = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link FileComparisonRepositoryType }
     *     
     */
    public FileComparisonRepositoryType getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileComparisonRepositoryType }
     *     
     */
    public void setType(FileComparisonRepositoryType value) {
        this.type = value;
    }

}
