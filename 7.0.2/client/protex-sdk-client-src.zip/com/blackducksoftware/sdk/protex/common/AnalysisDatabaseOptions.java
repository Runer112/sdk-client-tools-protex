
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for analysisDatabaseOptions complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="analysisDatabaseOptions">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="customCodeMatchesOption" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="customStringSearchesOption" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="forceCodeMatchOptions" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="forceStringSearchOptions" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="standardCodeMatchesOption" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="standardStringSearchesOption" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "analysisDatabaseOptions", propOrder = {
    "customCodeMatchesOption",
    "customStringSearchesOption",
    "forceCodeMatchOptions",
    "forceStringSearchOptions",
    "standardCodeMatchesOption",
    "standardStringSearchesOption"
})
public class AnalysisDatabaseOptions {

    protected Boolean customCodeMatchesOption;
    protected Boolean customStringSearchesOption;
    protected Boolean forceCodeMatchOptions;
    protected Boolean forceStringSearchOptions;
    protected Boolean standardCodeMatchesOption;
    protected Boolean standardStringSearchesOption;

    /**
     * Gets the value of the customCodeMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCustomCodeMatchesOption() {
        return customCodeMatchesOption;
    }

    /**
     * Sets the value of the customCodeMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCustomCodeMatchesOption(Boolean value) {
        this.customCodeMatchesOption = value;
    }

    /**
     * Gets the value of the customStringSearchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCustomStringSearchesOption() {
        return customStringSearchesOption;
    }

    /**
     * Sets the value of the customStringSearchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCustomStringSearchesOption(Boolean value) {
        this.customStringSearchesOption = value;
    }

    /**
     * Gets the value of the forceCodeMatchOptions property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isForceCodeMatchOptions() {
        return forceCodeMatchOptions;
    }

    /**
     * Sets the value of the forceCodeMatchOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setForceCodeMatchOptions(Boolean value) {
        this.forceCodeMatchOptions = value;
    }

    /**
     * Gets the value of the forceStringSearchOptions property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isForceStringSearchOptions() {
        return forceStringSearchOptions;
    }

    /**
     * Sets the value of the forceStringSearchOptions property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setForceStringSearchOptions(Boolean value) {
        this.forceStringSearchOptions = value;
    }

    /**
     * Gets the value of the standardCodeMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isStandardCodeMatchesOption() {
        return standardCodeMatchesOption;
    }

    /**
     * Sets the value of the standardCodeMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setStandardCodeMatchesOption(Boolean value) {
        this.standardCodeMatchesOption = value;
    }

    /**
     * Gets the value of the standardStringSearchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isStandardStringSearchesOption() {
        return standardStringSearchesOption;
    }

    /**
     * Sets the value of the standardStringSearchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setStandardStringSearchesOption(Boolean value) {
        this.standardStringSearchesOption = value;
    }

}
