
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for guardedByFileType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="guardedByFileType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="DISABLED"/>
 *     &lt;enumeration value="FORCED"/>
 *     &lt;enumeration value="EDITABLE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "guardedByFileType")
@XmlEnum
public enum GuardedByFileType {

    DISABLED,
    FORCED,
    EDITABLE;

    public String value() {
        return name();
    }

    public static GuardedByFileType fromValue(String v) {
        return valueOf(v);
    }

}
