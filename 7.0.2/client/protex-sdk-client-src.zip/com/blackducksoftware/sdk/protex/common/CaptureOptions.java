
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for captureOptions complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="captureOptions">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="binaryDependenciesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="blockCountThresholdOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleIntegerOption" minOccurs="0"/>
 *         &lt;element name="decompressCompressedFilesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="detectFileChangesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleDetectFileChangesOption" minOccurs="0"/>
 *         &lt;element name="discardRejectedCodeMatchesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="expandArchivesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleExpandArchivesOption" minOccurs="0"/>
 *         &lt;element name="fileMatchesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="javaImportOrCIncludeDependenciesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="javaPackageStatementDependenciesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="keepOnlyDiscoveriesToBestMatchingComponentSourcePathOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="keepOnlyDiscoveriesToCodeprintedComponentsOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="keepOnlyDiscoveriesToComponentsReleasedOnOrAfterOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleComponentsReleasedOnOrAfterOption" minOccurs="0"/>
 *         &lt;element name="keepOnlyDiscoveriesToMavenArtifactsOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="keepOnlyDiscoveriesToTopComponentMatchesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="manualBomRefreshOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="multiUserFileComparisonOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="snippetMatchesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="storeNonPrecisionDiscoveriesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="stringSearchRegularExpressionOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="stringSearchWildcardsOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="stringSearchesOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="uploadSourceCodeOption" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleUploadSourceCodeOption" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "captureOptions", propOrder = {
    "binaryDependenciesOption",
    "blockCountThresholdOption",
    "decompressCompressedFilesOption",
    "detectFileChangesOption",
    "discardRejectedCodeMatchesOption",
    "expandArchivesOption",
    "fileMatchesOption",
    "javaImportOrCIncludeDependenciesOption",
    "javaPackageStatementDependenciesOption",
    "keepOnlyDiscoveriesToBestMatchingComponentSourcePathOption",
    "keepOnlyDiscoveriesToCodeprintedComponentsOption",
    "keepOnlyDiscoveriesToComponentsReleasedOnOrAfterOption",
    "keepOnlyDiscoveriesToMavenArtifactsOption",
    "keepOnlyDiscoveriesToTopComponentMatchesOption",
    "manualBomRefreshOption",
    "multiUserFileComparisonOption",
    "snippetMatchesOption",
    "storeNonPrecisionDiscoveriesOption",
    "stringSearchRegularExpressionOption",
    "stringSearchWildcardsOption",
    "stringSearchesOption",
    "uploadSourceCodeOption"
})
public class CaptureOptions {

    protected ForcibleBooleanOption binaryDependenciesOption;
    protected ForcibleIntegerOption blockCountThresholdOption;
    protected ForcibleBooleanOption decompressCompressedFilesOption;
    protected ForcibleDetectFileChangesOption detectFileChangesOption;
    protected ForcibleBooleanOption discardRejectedCodeMatchesOption;
    protected ForcibleExpandArchivesOption expandArchivesOption;
    protected ForcibleBooleanOption fileMatchesOption;
    protected ForcibleBooleanOption javaImportOrCIncludeDependenciesOption;
    protected ForcibleBooleanOption javaPackageStatementDependenciesOption;
    protected ForcibleBooleanOption keepOnlyDiscoveriesToBestMatchingComponentSourcePathOption;
    protected ForcibleBooleanOption keepOnlyDiscoveriesToCodeprintedComponentsOption;
    protected ForcibleComponentsReleasedOnOrAfterOption keepOnlyDiscoveriesToComponentsReleasedOnOrAfterOption;
    protected ForcibleBooleanOption keepOnlyDiscoveriesToMavenArtifactsOption;
    protected ForcibleBooleanOption keepOnlyDiscoveriesToTopComponentMatchesOption;
    protected ForcibleBooleanOption manualBomRefreshOption;
    protected ForcibleBooleanOption multiUserFileComparisonOption;
    protected ForcibleBooleanOption snippetMatchesOption;
    protected ForcibleBooleanOption storeNonPrecisionDiscoveriesOption;
    protected ForcibleBooleanOption stringSearchRegularExpressionOption;
    protected ForcibleBooleanOption stringSearchWildcardsOption;
    protected ForcibleBooleanOption stringSearchesOption;
    protected ForcibleUploadSourceCodeOption uploadSourceCodeOption;

    /**
     * Gets the value of the binaryDependenciesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getBinaryDependenciesOption() {
        return binaryDependenciesOption;
    }

    /**
     * Sets the value of the binaryDependenciesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setBinaryDependenciesOption(ForcibleBooleanOption value) {
        this.binaryDependenciesOption = value;
    }

    /**
     * Gets the value of the blockCountThresholdOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleIntegerOption }
     *     
     */
    public ForcibleIntegerOption getBlockCountThresholdOption() {
        return blockCountThresholdOption;
    }

    /**
     * Sets the value of the blockCountThresholdOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleIntegerOption }
     *     
     */
    public void setBlockCountThresholdOption(ForcibleIntegerOption value) {
        this.blockCountThresholdOption = value;
    }

    /**
     * Gets the value of the decompressCompressedFilesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getDecompressCompressedFilesOption() {
        return decompressCompressedFilesOption;
    }

    /**
     * Sets the value of the decompressCompressedFilesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setDecompressCompressedFilesOption(ForcibleBooleanOption value) {
        this.decompressCompressedFilesOption = value;
    }

    /**
     * Gets the value of the detectFileChangesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleDetectFileChangesOption }
     *     
     */
    public ForcibleDetectFileChangesOption getDetectFileChangesOption() {
        return detectFileChangesOption;
    }

    /**
     * Sets the value of the detectFileChangesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleDetectFileChangesOption }
     *     
     */
    public void setDetectFileChangesOption(ForcibleDetectFileChangesOption value) {
        this.detectFileChangesOption = value;
    }

    /**
     * Gets the value of the discardRejectedCodeMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getDiscardRejectedCodeMatchesOption() {
        return discardRejectedCodeMatchesOption;
    }

    /**
     * Sets the value of the discardRejectedCodeMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setDiscardRejectedCodeMatchesOption(ForcibleBooleanOption value) {
        this.discardRejectedCodeMatchesOption = value;
    }

    /**
     * Gets the value of the expandArchivesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleExpandArchivesOption }
     *     
     */
    public ForcibleExpandArchivesOption getExpandArchivesOption() {
        return expandArchivesOption;
    }

    /**
     * Sets the value of the expandArchivesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleExpandArchivesOption }
     *     
     */
    public void setExpandArchivesOption(ForcibleExpandArchivesOption value) {
        this.expandArchivesOption = value;
    }

    /**
     * Gets the value of the fileMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getFileMatchesOption() {
        return fileMatchesOption;
    }

    /**
     * Sets the value of the fileMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setFileMatchesOption(ForcibleBooleanOption value) {
        this.fileMatchesOption = value;
    }

    /**
     * Gets the value of the javaImportOrCIncludeDependenciesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getJavaImportOrCIncludeDependenciesOption() {
        return javaImportOrCIncludeDependenciesOption;
    }

    /**
     * Sets the value of the javaImportOrCIncludeDependenciesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setJavaImportOrCIncludeDependenciesOption(ForcibleBooleanOption value) {
        this.javaImportOrCIncludeDependenciesOption = value;
    }

    /**
     * Gets the value of the javaPackageStatementDependenciesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getJavaPackageStatementDependenciesOption() {
        return javaPackageStatementDependenciesOption;
    }

    /**
     * Sets the value of the javaPackageStatementDependenciesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setJavaPackageStatementDependenciesOption(ForcibleBooleanOption value) {
        this.javaPackageStatementDependenciesOption = value;
    }

    /**
     * Gets the value of the keepOnlyDiscoveriesToBestMatchingComponentSourcePathOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getKeepOnlyDiscoveriesToBestMatchingComponentSourcePathOption() {
        return keepOnlyDiscoveriesToBestMatchingComponentSourcePathOption;
    }

    /**
     * Sets the value of the keepOnlyDiscoveriesToBestMatchingComponentSourcePathOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setKeepOnlyDiscoveriesToBestMatchingComponentSourcePathOption(ForcibleBooleanOption value) {
        this.keepOnlyDiscoveriesToBestMatchingComponentSourcePathOption = value;
    }

    /**
     * Gets the value of the keepOnlyDiscoveriesToCodeprintedComponentsOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getKeepOnlyDiscoveriesToCodeprintedComponentsOption() {
        return keepOnlyDiscoveriesToCodeprintedComponentsOption;
    }

    /**
     * Sets the value of the keepOnlyDiscoveriesToCodeprintedComponentsOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setKeepOnlyDiscoveriesToCodeprintedComponentsOption(ForcibleBooleanOption value) {
        this.keepOnlyDiscoveriesToCodeprintedComponentsOption = value;
    }

    /**
     * Gets the value of the keepOnlyDiscoveriesToComponentsReleasedOnOrAfterOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleComponentsReleasedOnOrAfterOption }
     *     
     */
    public ForcibleComponentsReleasedOnOrAfterOption getKeepOnlyDiscoveriesToComponentsReleasedOnOrAfterOption() {
        return keepOnlyDiscoveriesToComponentsReleasedOnOrAfterOption;
    }

    /**
     * Sets the value of the keepOnlyDiscoveriesToComponentsReleasedOnOrAfterOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleComponentsReleasedOnOrAfterOption }
     *     
     */
    public void setKeepOnlyDiscoveriesToComponentsReleasedOnOrAfterOption(ForcibleComponentsReleasedOnOrAfterOption value) {
        this.keepOnlyDiscoveriesToComponentsReleasedOnOrAfterOption = value;
    }

    /**
     * Gets the value of the keepOnlyDiscoveriesToMavenArtifactsOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getKeepOnlyDiscoveriesToMavenArtifactsOption() {
        return keepOnlyDiscoveriesToMavenArtifactsOption;
    }

    /**
     * Sets the value of the keepOnlyDiscoveriesToMavenArtifactsOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setKeepOnlyDiscoveriesToMavenArtifactsOption(ForcibleBooleanOption value) {
        this.keepOnlyDiscoveriesToMavenArtifactsOption = value;
    }

    /**
     * Gets the value of the keepOnlyDiscoveriesToTopComponentMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getKeepOnlyDiscoveriesToTopComponentMatchesOption() {
        return keepOnlyDiscoveriesToTopComponentMatchesOption;
    }

    /**
     * Sets the value of the keepOnlyDiscoveriesToTopComponentMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setKeepOnlyDiscoveriesToTopComponentMatchesOption(ForcibleBooleanOption value) {
        this.keepOnlyDiscoveriesToTopComponentMatchesOption = value;
    }

    /**
     * Gets the value of the manualBomRefreshOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getManualBomRefreshOption() {
        return manualBomRefreshOption;
    }

    /**
     * Sets the value of the manualBomRefreshOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setManualBomRefreshOption(ForcibleBooleanOption value) {
        this.manualBomRefreshOption = value;
    }

    /**
     * Gets the value of the multiUserFileComparisonOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getMultiUserFileComparisonOption() {
        return multiUserFileComparisonOption;
    }

    /**
     * Sets the value of the multiUserFileComparisonOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setMultiUserFileComparisonOption(ForcibleBooleanOption value) {
        this.multiUserFileComparisonOption = value;
    }

    /**
     * Gets the value of the snippetMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getSnippetMatchesOption() {
        return snippetMatchesOption;
    }

    /**
     * Sets the value of the snippetMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setSnippetMatchesOption(ForcibleBooleanOption value) {
        this.snippetMatchesOption = value;
    }

    /**
     * Gets the value of the storeNonPrecisionDiscoveriesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getStoreNonPrecisionDiscoveriesOption() {
        return storeNonPrecisionDiscoveriesOption;
    }

    /**
     * Sets the value of the storeNonPrecisionDiscoveriesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setStoreNonPrecisionDiscoveriesOption(ForcibleBooleanOption value) {
        this.storeNonPrecisionDiscoveriesOption = value;
    }

    /**
     * Gets the value of the stringSearchRegularExpressionOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getStringSearchRegularExpressionOption() {
        return stringSearchRegularExpressionOption;
    }

    /**
     * Sets the value of the stringSearchRegularExpressionOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setStringSearchRegularExpressionOption(ForcibleBooleanOption value) {
        this.stringSearchRegularExpressionOption = value;
    }

    /**
     * Gets the value of the stringSearchWildcardsOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getStringSearchWildcardsOption() {
        return stringSearchWildcardsOption;
    }

    /**
     * Sets the value of the stringSearchWildcardsOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setStringSearchWildcardsOption(ForcibleBooleanOption value) {
        this.stringSearchWildcardsOption = value;
    }

    /**
     * Gets the value of the stringSearchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getStringSearchesOption() {
        return stringSearchesOption;
    }

    /**
     * Sets the value of the stringSearchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setStringSearchesOption(ForcibleBooleanOption value) {
        this.stringSearchesOption = value;
    }

    /**
     * Gets the value of the uploadSourceCodeOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleUploadSourceCodeOption }
     *     
     */
    public ForcibleUploadSourceCodeOption getUploadSourceCodeOption() {
        return uploadSourceCodeOption;
    }

    /**
     * Sets the value of the uploadSourceCodeOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleUploadSourceCodeOption }
     *     
     */
    public void setUploadSourceCodeOption(ForcibleUploadSourceCodeOption value) {
        this.uploadSourceCodeOption = value;
    }

}
