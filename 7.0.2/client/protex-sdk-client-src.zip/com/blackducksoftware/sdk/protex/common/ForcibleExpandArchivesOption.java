
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for forcibleExpandArchivesOption complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="forcibleExpandArchivesOption">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="forced" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="value" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}expandArchivesOption" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "forcibleExpandArchivesOption", propOrder = {
    "forced",
    "value"
})
public class ForcibleExpandArchivesOption {

    protected Boolean forced;
    protected ExpandArchivesOption value;

    /**
     * Gets the value of the forced property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isForced() {
        return forced;
    }

    /**
     * Sets the value of the forced property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setForced(Boolean value) {
        this.forced = value;
    }

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link ExpandArchivesOption }
     *     
     */
    public ExpandArchivesOption getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExpandArchivesOption }
     *     
     */
    public void setValue(ExpandArchivesOption value) {
        this.value = value;
    }

}
