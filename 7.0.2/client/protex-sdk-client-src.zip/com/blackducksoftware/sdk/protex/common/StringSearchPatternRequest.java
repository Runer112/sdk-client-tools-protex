
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for stringSearchPatternRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="stringSearchPatternRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="advancedPattern" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="associatedLicenseId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="enabled" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="method" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}stringSearchMethod" minOccurs="0"/>
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="requireId" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}forcibleBooleanOption" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "stringSearchPatternRequest", propOrder = {
    "advancedPattern",
    "associatedLicenseId",
    "enabled",
    "method",
    "name",
    "requireId"
})
@XmlSeeAlso({
    StringSearchPattern.class
})
public class StringSearchPatternRequest {

    protected String advancedPattern;
    protected String associatedLicenseId;
    protected ForcibleBooleanOption enabled;
    protected StringSearchMethod method;
    protected String name;
    protected ForcibleBooleanOption requireId;

    /**
     * Gets the value of the advancedPattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAdvancedPattern() {
        return advancedPattern;
    }

    /**
     * Sets the value of the advancedPattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAdvancedPattern(String value) {
        this.advancedPattern = value;
    }

    /**
     * Gets the value of the associatedLicenseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssociatedLicenseId() {
        return associatedLicenseId;
    }

    /**
     * Sets the value of the associatedLicenseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssociatedLicenseId(String value) {
        this.associatedLicenseId = value;
    }

    /**
     * Gets the value of the enabled property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getEnabled() {
        return enabled;
    }

    /**
     * Sets the value of the enabled property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setEnabled(ForcibleBooleanOption value) {
        this.enabled = value;
    }

    /**
     * Gets the value of the method property.
     * 
     * @return
     *     possible object is
     *     {@link StringSearchMethod }
     *     
     */
    public StringSearchMethod getMethod() {
        return method;
    }

    /**
     * Sets the value of the method property.
     * 
     * @param value
     *     allowed object is
     *     {@link StringSearchMethod }
     *     
     */
    public void setMethod(StringSearchMethod value) {
        this.method = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the requireId property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getRequireId() {
        return requireId;
    }

    /**
     * Sets the value of the requireId property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setRequireId(ForcibleBooleanOption value) {
        this.requireId = value;
    }

}
