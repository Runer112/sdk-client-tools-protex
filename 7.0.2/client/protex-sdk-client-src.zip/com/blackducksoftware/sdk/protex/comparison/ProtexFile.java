
package com.blackducksoftware.sdk.protex.comparison;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for protexFile complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="protexFile">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="componentOrProjectId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="filePath" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fileType" type="{urn:protex.blackducksoftware.com:sdk:v7.0:comparison}protexFileSourceType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "protexFile", propOrder = {
    "componentOrProjectId",
    "filePath",
    "fileType"
})
public class ProtexFile {

    protected String componentOrProjectId;
    protected String filePath;
    protected ProtexFileSourceType fileType;

    /**
     * Gets the value of the componentOrProjectId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getComponentOrProjectId() {
        return componentOrProjectId;
    }

    /**
     * Sets the value of the componentOrProjectId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setComponentOrProjectId(String value) {
        this.componentOrProjectId = value;
    }

    /**
     * Gets the value of the filePath property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFilePath() {
        return filePath;
    }

    /**
     * Sets the value of the filePath property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFilePath(String value) {
        this.filePath = value;
    }

    /**
     * Gets the value of the fileType property.
     * 
     * @return
     *     possible object is
     *     {@link ProtexFileSourceType }
     *     
     */
    public ProtexFileSourceType getFileType() {
        return fileType;
    }

    /**
     * Sets the value of the fileType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtexFileSourceType }
     *     
     */
    public void setFileType(ProtexFileSourceType value) {
        this.fileType = value;
    }

}
