
package com.blackducksoftware.sdk.protex.comparison;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.Snippet;


/**
 * <p>Java class for relatedSnippets complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="relatedSnippets">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="leftSnippet" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}snippet" minOccurs="0"/>
 *         &lt;element name="rightSnippet" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}snippet" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "relatedSnippets", propOrder = {
    "leftSnippet",
    "rightSnippet"
})
public class RelatedSnippets {

    protected Snippet leftSnippet;
    protected Snippet rightSnippet;

    /**
     * Gets the value of the leftSnippet property.
     * 
     * @return
     *     possible object is
     *     {@link Snippet }
     *     
     */
    public Snippet getLeftSnippet() {
        return leftSnippet;
    }

    /**
     * Sets the value of the leftSnippet property.
     * 
     * @param value
     *     allowed object is
     *     {@link Snippet }
     *     
     */
    public void setLeftSnippet(Snippet value) {
        this.leftSnippet = value;
    }

    /**
     * Gets the value of the rightSnippet property.
     * 
     * @return
     *     possible object is
     *     {@link Snippet }
     *     
     */
    public Snippet getRightSnippet() {
        return rightSnippet;
    }

    /**
     * Sets the value of the rightSnippet property.
     * 
     * @param value
     *     allowed object is
     *     {@link Snippet }
     *     
     */
    public void setRightSnippet(Snippet value) {
        this.rightSnippet = value;
    }

}
