
package com.blackducksoftware.sdk.protex.comparison;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.blackducksoftware.sdk.protex.comparison package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetFileUrlResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:comparison", "getFileUrlResponse");
    private final static QName _GetFileSimilarities_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:comparison", "getFileSimilarities");
    private final static QName _GetFileSimilaritiesResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:comparison", "getFileSimilaritiesResponse");
    private final static QName _GetFileUrl_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:comparison", "getFileUrl");
    private final static QName _GetFileDifferencesResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:comparison", "getFileDifferencesResponse");
    private final static QName _SetFileComparisonRepositoryResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:comparison", "setFileComparisonRepositoryResponse");
    private final static QName _GetFileComparisonRepositoryResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:comparison", "getFileComparisonRepositoryResponse");
    private final static QName _GetFileDifferences_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:comparison", "getFileDifferences");
    private final static QName _GetFileComparisonRepository_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:comparison", "getFileComparisonRepository");
    private final static QName _SetFileComparisonRepository_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v7.0:comparison", "setFileComparisonRepository");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.blackducksoftware.sdk.protex.comparison
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetFileDifferencesResponse }
     * 
     */
    public GetFileDifferencesResponse createGetFileDifferencesResponse() {
        return new GetFileDifferencesResponse();
    }

    /**
     * Create an instance of {@link SetFileComparisonRepositoryResponse }
     * 
     */
    public SetFileComparisonRepositoryResponse createSetFileComparisonRepositoryResponse() {
        return new SetFileComparisonRepositoryResponse();
    }

    /**
     * Create an instance of {@link GetFileDifferences }
     * 
     */
    public GetFileDifferences createGetFileDifferences() {
        return new GetFileDifferences();
    }

    /**
     * Create an instance of {@link GetFileComparisonRepositoryResponse }
     * 
     */
    public GetFileComparisonRepositoryResponse createGetFileComparisonRepositoryResponse() {
        return new GetFileComparisonRepositoryResponse();
    }

    /**
     * Create an instance of {@link SetFileComparisonRepository }
     * 
     */
    public SetFileComparisonRepository createSetFileComparisonRepository() {
        return new SetFileComparisonRepository();
    }

    /**
     * Create an instance of {@link GetFileComparisonRepository }
     * 
     */
    public GetFileComparisonRepository createGetFileComparisonRepository() {
        return new GetFileComparisonRepository();
    }

    /**
     * Create an instance of {@link GetFileUrlResponse }
     * 
     */
    public GetFileUrlResponse createGetFileUrlResponse() {
        return new GetFileUrlResponse();
    }

    /**
     * Create an instance of {@link GetFileSimilarities }
     * 
     */
    public GetFileSimilarities createGetFileSimilarities() {
        return new GetFileSimilarities();
    }

    /**
     * Create an instance of {@link GetFileUrl }
     * 
     */
    public GetFileUrl createGetFileUrl() {
        return new GetFileUrl();
    }

    /**
     * Create an instance of {@link GetFileSimilaritiesResponse }
     * 
     */
    public GetFileSimilaritiesResponse createGetFileSimilaritiesResponse() {
        return new GetFileSimilaritiesResponse();
    }

    /**
     * Create an instance of {@link RelatedSnippets }
     * 
     */
    public RelatedSnippets createRelatedSnippets() {
        return new RelatedSnippets();
    }

    /**
     * Create an instance of {@link ProtexFile }
     * 
     */
    public ProtexFile createProtexFile() {
        return new ProtexFile();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileUrlResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:comparison", name = "getFileUrlResponse")
    public JAXBElement<GetFileUrlResponse> createGetFileUrlResponse(GetFileUrlResponse value) {
        return new JAXBElement<GetFileUrlResponse>(_GetFileUrlResponse_QNAME, GetFileUrlResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileSimilarities }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:comparison", name = "getFileSimilarities")
    public JAXBElement<GetFileSimilarities> createGetFileSimilarities(GetFileSimilarities value) {
        return new JAXBElement<GetFileSimilarities>(_GetFileSimilarities_QNAME, GetFileSimilarities.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileSimilaritiesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:comparison", name = "getFileSimilaritiesResponse")
    public JAXBElement<GetFileSimilaritiesResponse> createGetFileSimilaritiesResponse(GetFileSimilaritiesResponse value) {
        return new JAXBElement<GetFileSimilaritiesResponse>(_GetFileSimilaritiesResponse_QNAME, GetFileSimilaritiesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileUrl }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:comparison", name = "getFileUrl")
    public JAXBElement<GetFileUrl> createGetFileUrl(GetFileUrl value) {
        return new JAXBElement<GetFileUrl>(_GetFileUrl_QNAME, GetFileUrl.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileDifferencesResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:comparison", name = "getFileDifferencesResponse")
    public JAXBElement<GetFileDifferencesResponse> createGetFileDifferencesResponse(GetFileDifferencesResponse value) {
        return new JAXBElement<GetFileDifferencesResponse>(_GetFileDifferencesResponse_QNAME, GetFileDifferencesResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetFileComparisonRepositoryResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:comparison", name = "setFileComparisonRepositoryResponse")
    public JAXBElement<SetFileComparisonRepositoryResponse> createSetFileComparisonRepositoryResponse(SetFileComparisonRepositoryResponse value) {
        return new JAXBElement<SetFileComparisonRepositoryResponse>(_SetFileComparisonRepositoryResponse_QNAME, SetFileComparisonRepositoryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileComparisonRepositoryResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:comparison", name = "getFileComparisonRepositoryResponse")
    public JAXBElement<GetFileComparisonRepositoryResponse> createGetFileComparisonRepositoryResponse(GetFileComparisonRepositoryResponse value) {
        return new JAXBElement<GetFileComparisonRepositoryResponse>(_GetFileComparisonRepositoryResponse_QNAME, GetFileComparisonRepositoryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileDifferences }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:comparison", name = "getFileDifferences")
    public JAXBElement<GetFileDifferences> createGetFileDifferences(GetFileDifferences value) {
        return new JAXBElement<GetFileDifferences>(_GetFileDifferences_QNAME, GetFileDifferences.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileComparisonRepository }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:comparison", name = "getFileComparisonRepository")
    public JAXBElement<GetFileComparisonRepository> createGetFileComparisonRepository(GetFileComparisonRepository value) {
        return new JAXBElement<GetFileComparisonRepository>(_GetFileComparisonRepository_QNAME, GetFileComparisonRepository.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetFileComparisonRepository }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v7.0:comparison", name = "setFileComparisonRepository")
    public JAXBElement<SetFileComparisonRepository> createSetFileComparisonRepository(SetFileComparisonRepository value) {
        return new JAXBElement<SetFileComparisonRepository>(_SetFileComparisonRepository_QNAME, SetFileComparisonRepository.class, null, value);
    }

}
