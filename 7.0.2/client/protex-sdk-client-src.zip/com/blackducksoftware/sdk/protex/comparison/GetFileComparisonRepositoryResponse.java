
package com.blackducksoftware.sdk.protex.comparison;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.FileComparisonRepository;


/**
 * <p>Java class for getFileComparisonRepositoryResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getFileComparisonRepositoryResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="return" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}fileComparisonRepository" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getFileComparisonRepositoryResponse", propOrder = {
    "_return"
})
public class GetFileComparisonRepositoryResponse {

    @XmlElement(name = "return")
    protected FileComparisonRepository _return;

    /**
     * Gets the value of the return property.
     * 
     * @return
     *     possible object is
     *     {@link FileComparisonRepository }
     *     
     */
    public FileComparisonRepository getReturn() {
        return _return;
    }

    /**
     * Sets the value of the return property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileComparisonRepository }
     *     
     */
    public void setReturn(FileComparisonRepository value) {
        this._return = value;
    }

}
