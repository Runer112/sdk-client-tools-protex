
package com.blackducksoftware.sdk.protex.project;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.FileDiscoveryPattern;


/**
 * <p>Java class for getFileDiscoveryPatternByIdResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getFileDiscoveryPatternByIdResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="return" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}fileDiscoveryPattern" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getFileDiscoveryPatternByIdResponse", propOrder = {
    "_return"
})
public class GetFileDiscoveryPatternByIdResponse {

    @XmlElement(name = "return")
    protected FileDiscoveryPattern _return;

    /**
     * Gets the value of the return property.
     * 
     * @return
     *     possible object is
     *     {@link FileDiscoveryPattern }
     *     
     */
    public FileDiscoveryPattern getReturn() {
        return _return;
    }

    /**
     * Sets the value of the return property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileDiscoveryPattern }
     *     
     */
    public void setReturn(FileDiscoveryPattern value) {
        this._return = value;
    }

}
