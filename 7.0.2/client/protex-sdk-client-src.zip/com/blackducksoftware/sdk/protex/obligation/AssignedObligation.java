
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for assignedObligation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="assignedObligation">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}assignedObligationRequest">
 *       &lt;sequence>
 *         &lt;element name="fulfillmentInherited" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="obligationId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="originObjectId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="originType" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}obligationOriginType" minOccurs="0"/>
 *         &lt;element name="reviewAndReportInherited" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "assignedObligation", propOrder = {
    "fulfillmentInherited",
    "obligationId",
    "originObjectId",
    "originType",
    "reviewAndReportInherited"
})
public class AssignedObligation
    extends AssignedObligationRequest
{

    protected Boolean fulfillmentInherited;
    protected String obligationId;
    protected String originObjectId;
    protected ObligationOriginType originType;
    protected Boolean reviewAndReportInherited;

    /**
     * Gets the value of the fulfillmentInherited property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFulfillmentInherited() {
        return fulfillmentInherited;
    }

    /**
     * Sets the value of the fulfillmentInherited property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFulfillmentInherited(Boolean value) {
        this.fulfillmentInherited = value;
    }

    /**
     * Gets the value of the obligationId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObligationId() {
        return obligationId;
    }

    /**
     * Sets the value of the obligationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObligationId(String value) {
        this.obligationId = value;
    }

    /**
     * Gets the value of the originObjectId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginObjectId() {
        return originObjectId;
    }

    /**
     * Sets the value of the originObjectId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginObjectId(String value) {
        this.originObjectId = value;
    }

    /**
     * Gets the value of the originType property.
     * 
     * @return
     *     possible object is
     *     {@link ObligationOriginType }
     *     
     */
    public ObligationOriginType getOriginType() {
        return originType;
    }

    /**
     * Sets the value of the originType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObligationOriginType }
     *     
     */
    public void setOriginType(ObligationOriginType value) {
        this.originType = value;
    }

    /**
     * Gets the value of the reviewAndReportInherited property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReviewAndReportInherited() {
        return reviewAndReportInherited;
    }

    /**
     * Sets the value of the reviewAndReportInherited property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReviewAndReportInherited(Boolean value) {
        this.reviewAndReportInherited = value;
    }

}
