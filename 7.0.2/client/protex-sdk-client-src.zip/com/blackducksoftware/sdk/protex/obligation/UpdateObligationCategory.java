
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateObligationCategory complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateObligationCategory">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="obligationCategoryId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="obligationCategoryUpdateRequest" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}obligationCategoryRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateObligationCategory", propOrder = {
    "obligationCategoryId",
    "obligationCategoryUpdateRequest"
})
public class UpdateObligationCategory {

    protected String obligationCategoryId;
    protected ObligationCategoryRequest obligationCategoryUpdateRequest;

    /**
     * Gets the value of the obligationCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObligationCategoryId() {
        return obligationCategoryId;
    }

    /**
     * Sets the value of the obligationCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObligationCategoryId(String value) {
        this.obligationCategoryId = value;
    }

    /**
     * Gets the value of the obligationCategoryUpdateRequest property.
     * 
     * @return
     *     possible object is
     *     {@link ObligationCategoryRequest }
     *     
     */
    public ObligationCategoryRequest getObligationCategoryUpdateRequest() {
        return obligationCategoryUpdateRequest;
    }

    /**
     * Sets the value of the obligationCategoryUpdateRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObligationCategoryRequest }
     *     
     */
    public void setObligationCategoryUpdateRequest(ObligationCategoryRequest value) {
        this.obligationCategoryUpdateRequest = value;
    }

}
