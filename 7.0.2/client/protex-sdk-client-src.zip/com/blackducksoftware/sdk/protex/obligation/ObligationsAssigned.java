
package com.blackducksoftware.sdk.protex.obligation;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for obligationsAssigned complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="obligationsAssigned">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="assignedObligations" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}assignedObligation" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="element" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}protexElementWithObligations" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "obligationsAssigned", propOrder = {
    "assignedObligations",
    "element"
})
public class ObligationsAssigned {

    @XmlElement(nillable = true)
    protected List<AssignedObligation> assignedObligations;
    protected ProtexElementWithObligations element;

    /**
     * Gets the value of the assignedObligations property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the assignedObligations property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getAssignedObligations().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AssignedObligation }
     * 
     * 
     */
    public List<AssignedObligation> getAssignedObligations() {
        if (assignedObligations == null) {
            assignedObligations = new ArrayList<AssignedObligation>();
        }
        return this.assignedObligations;
    }

    /**
     * Gets the value of the element property.
     * 
     * @return
     *     possible object is
     *     {@link ProtexElementWithObligations }
     *     
     */
    public ProtexElementWithObligations getElement() {
        return element;
    }

    /**
     * Sets the value of the element property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtexElementWithObligations }
     *     
     */
    public void setElement(ProtexElementWithObligations value) {
        this.element = value;
    }

}
