
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for assignedObligationColumn.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="assignedObligationColumn">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="OBLIGATION_ID"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "assignedObligationColumn")
@XmlEnum
public enum AssignedObligationColumn {

    OBLIGATION_ID;

    public String value() {
        return name();
    }

    public static AssignedObligationColumn fromValue(String v) {
        return valueOf(v);
    }

}
