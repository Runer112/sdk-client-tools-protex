
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.PageFilter;


/**
 * <p>Java class for obligationPageFilter complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="obligationPageFilter">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v7.0:common}pageFilter">
 *       &lt;sequence>
 *         &lt;element name="sortedColumn" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}obligationColumn" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "obligationPageFilter", propOrder = {
    "sortedColumn"
})
public class ObligationPageFilter
    extends PageFilter
{

    protected ObligationColumn sortedColumn;

    /**
     * Gets the value of the sortedColumn property.
     * 
     * @return
     *     possible object is
     *     {@link ObligationColumn }
     *     
     */
    public ObligationColumn getSortedColumn() {
        return sortedColumn;
    }

    /**
     * Sets the value of the sortedColumn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObligationColumn }
     *     
     */
    public void setSortedColumn(ObligationColumn value) {
        this.sortedColumn = value;
    }

}
