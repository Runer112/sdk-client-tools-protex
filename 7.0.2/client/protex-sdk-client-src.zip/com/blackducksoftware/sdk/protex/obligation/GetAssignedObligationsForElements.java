
package com.blackducksoftware.sdk.protex.obligation;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.GetBehavior;


/**
 * <p>Java class for getAssignedObligationsForElements complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getAssignedObligationsForElements">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="elements" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}protexElementWithObligations" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="pageFilter" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}assignedObligationPageFilter" minOccurs="0"/>
 *         &lt;element name="getBehavior" type="{urn:protex.blackducksoftware.com:sdk:v7.0:common}getBehavior" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getAssignedObligationsForElements", propOrder = {
    "elements",
    "pageFilter",
    "getBehavior"
})
public class GetAssignedObligationsForElements {

    protected List<ProtexElementWithObligations> elements;
    protected AssignedObligationPageFilter pageFilter;
    protected GetBehavior getBehavior;

    /**
     * Gets the value of the elements property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the elements property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getElements().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProtexElementWithObligations }
     * 
     * 
     */
    public List<ProtexElementWithObligations> getElements() {
        if (elements == null) {
            elements = new ArrayList<ProtexElementWithObligations>();
        }
        return this.elements;
    }

    /**
     * Gets the value of the pageFilter property.
     * 
     * @return
     *     possible object is
     *     {@link AssignedObligationPageFilter }
     *     
     */
    public AssignedObligationPageFilter getPageFilter() {
        return pageFilter;
    }

    /**
     * Sets the value of the pageFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link AssignedObligationPageFilter }
     *     
     */
    public void setPageFilter(AssignedObligationPageFilter value) {
        this.pageFilter = value;
    }

    /**
     * Gets the value of the getBehavior property.
     * 
     * @return
     *     possible object is
     *     {@link GetBehavior }
     *     
     */
    public GetBehavior getGetBehavior() {
        return getBehavior;
    }

    /**
     * Sets the value of the getBehavior property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetBehavior }
     *     
     */
    public void setGetBehavior(GetBehavior value) {
        this.getBehavior = value;
    }

}
