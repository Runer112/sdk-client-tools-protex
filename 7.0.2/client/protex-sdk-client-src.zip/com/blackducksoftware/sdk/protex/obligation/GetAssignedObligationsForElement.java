
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getAssignedObligationsForElement complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getAssignedObligationsForElement">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="element" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}protexElementWithObligations" minOccurs="0"/>
 *         &lt;element name="pageFilter" type="{urn:protex.blackducksoftware.com:sdk:v7.0:obligation}assignedObligationPageFilter" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getAssignedObligationsForElement", propOrder = {
    "element",
    "pageFilter"
})
public class GetAssignedObligationsForElement {

    protected ProtexElementWithObligations element;
    protected AssignedObligationPageFilter pageFilter;

    /**
     * Gets the value of the element property.
     * 
     * @return
     *     possible object is
     *     {@link ProtexElementWithObligations }
     *     
     */
    public ProtexElementWithObligations getElement() {
        return element;
    }

    /**
     * Sets the value of the element property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProtexElementWithObligations }
     *     
     */
    public void setElement(ProtexElementWithObligations value) {
        this.element = value;
    }

    /**
     * Gets the value of the pageFilter property.
     * 
     * @return
     *     possible object is
     *     {@link AssignedObligationPageFilter }
     *     
     */
    public AssignedObligationPageFilter getPageFilter() {
        return pageFilter;
    }

    /**
     * Sets the value of the pageFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link AssignedObligationPageFilter }
     *     
     */
    public void setPageFilter(AssignedObligationPageFilter value) {
        this.pageFilter = value;
    }

}
