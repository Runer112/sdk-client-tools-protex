@javax.xml.bind.annotation.XmlSchema(namespace = "urn:blackducksoftware.com:sdk:v7.0:fault")
package com.blackducksoftware.sdk.fault;
