/*
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */package com.blackducksoftware.sdk.protex.util;

 import java.util.ArrayList;
import java.util.HashMap;
 import java.util.List;
import java.util.Map;

 import com.blackducksoftware.sdk.protex.project.codetree.CodeTreeNode;
import com.blackducksoftware.sdk.protex.project.codetree.CodeTreeNodeRequest;
 import com.blackducksoftware.sdk.protex.project.codetree.CodeTreeNodeType;
import com.blackducksoftware.sdk.protex.project.codetree.NodeCount;
 import com.blackducksoftware.sdk.protex.project.codetree.NodeCountType;

 public class CodeTreeUtilities {

     /**
      * File Separator for CodeTree paths. This value is NOT OS dependent!
      */
     private static final String FS = "/";

     public static final Integer INFINITE_DEPTH = -1;

     public static final Integer SINGLE_NODE = 0;

     public static final Integer DIRECT_CHILDREN = 1;

     public static final List<CodeTreeNodeType> ALL_CODE_TREE_NODE_TYPES;

     public static final CodeTreeNodeRequest ALL_NODES_PARAMETERS;

     static {
         ALL_CODE_TREE_NODE_TYPES = new ArrayList<CodeTreeNodeType>();

         for (CodeTreeNodeType nodeType : CodeTreeNodeType.values()) {
             ALL_CODE_TREE_NODE_TYPES.add(nodeType);
         }

         ALL_NODES_PARAMETERS = new CodeTreeNodeRequest();
         ALL_NODES_PARAMETERS.setDepth(INFINITE_DEPTH);
         ALL_NODES_PARAMETERS.setIncludeParentNode(true);
         ALL_NODES_PARAMETERS.getIncludedNodeTypes().addAll(ALL_CODE_TREE_NODE_TYPES);
     }

     /**
      * constructs a safe path, avoiding double Files separators &quot;/&quot;
      * 
      * @param parentPath
      *            the parentPath, i.e. &quot;/&quot;, &quot;/folder1&quot;
      * @param nodeName
      *            name of a file, folder or expanded Archive file
      * @return - the concatenated path
      */
     public String constructPath(String parentPath, String nodeName) {
         String p = ((parentPath.length() == 0) || (parentPath.endsWith(FS) || (nodeName.length() == 0)) ? parentPath
                 : parentPath + FS)
                 + nodeName;
         return p;
     }

     /**
      * Extracts count information into a moer random-access friendly form
      * 
      * @param node
      *            A code tree node with count informaton
      * @return A map relating each count type to the returned count
      */
     public static Map<NodeCountType, Long> getNodeCountMap(CodeTreeNode node) {
         Map<NodeCountType, Long> counts = new HashMap<NodeCountType, Long>();

         if (node != null && node.getNodeCounts() != null) {
             for (NodeCount count : node.getNodeCounts()) {
                 counts.put(count.getCountType(), count.getCount());
             }
         }

         return counts;
     }
 }
