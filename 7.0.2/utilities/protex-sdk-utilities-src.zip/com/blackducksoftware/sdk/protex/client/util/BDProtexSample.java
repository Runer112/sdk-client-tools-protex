/*
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */
package com.blackducksoftware.sdk.protex.client.util;

import java.util.ArrayList;
import java.util.List;

/**
 * Black Duck Protex SDK Sample program
 */
public abstract class BDProtexSample {

    /**
     * Get the usage parameters for printing a usage command line as they are processed by this class
     * 
     * @return the String to use in a usage command line
     */
    @Deprecated
    public static String getUsageServiceParameters() {
        return "[-D" + ProtexServerProxy.PROTEX_SDK_DEBUG_PROPERTY + "=<logging level>] <serverUri> <username> <password>";
    }

    /**
     * Print the detailed description of usage for the parameters processed by this class
     */
    @Deprecated
    public static void printUsageServiceParameterDetails() {
        System.out
        .println("  logging level - The level of debug logging the Soap messages. "
                + "Set to 0..4 for COMPACT_PRETTY(0), COMPACT(1), VERBOSE_SECURE(2), VERBOSE_SECURE_PRETTY(3), VERBOSE(4)");

        System.out.println("  serverUri - the base Uri for the server, i.e. http://protex.example.com:<port>/");
        System.out.println("  username  - the username for this server, i.e. tester@example.com");
        System.out.println("  password  - the passowrd for this user, i.e. simplepassword");
    }

    /**
     * @return An ordered list of parameters accepted/required by all samples
     */
    protected static List<String> getDefaultUsageParameters() {
        List<String> defaultParams = new ArrayList<String>();

        defaultParams.add("[-D" + ProtexServerProxy.PROTEX_SDK_DEBUG_PROPERTY + "=<logging level>]");
        defaultParams.add("<serverUri>");
        defaultParams.add("<username>");
        defaultParams.add("<password>");

        return defaultParams;
    }

    /**
     * @return A list of detailed descriptions for command line parameters accepted/required by all samples
     */
    protected static List<String> getDefaultUsageParameterDetails() {
        List<String> defaultParamDetails = new ArrayList<String>();

        defaultParamDetails
        .add(formatUsageDetail("logging level",
                "The level of debug logging the Soap messages. Set to 0..4 for COMPACT_PRETTY(0), COMPACT(1), VERBOSE_SECURE(2), VERBOSE_SECURE_PRETTY(3), VERBOSE(4)"));
        defaultParamDetails.add(formatUsageDetail("serverUri", "The base Uri for the server, i.e. http://protex.example.com:<port>/"));
        defaultParamDetails.add(formatUsageDetail("username", "The username for this server, i.e. tester@example.com"));
        defaultParamDetails.add(formatUsageDetail("password", "The passowrd for this user, i.e. simplepassword"));

        return defaultParamDetails;
    }

    /**
     * @param parameter
     *            A command line parameter accepted/required by the sample
     * @param description
     *            A description of the parameter
     * @return A full output string describing the parameter
     */
    protected static String formatUsageDetail(String parameter, String description) {
        return "\t" + parameter + " - " + description;
    }

    /**
     * Outputs usage information for the sample
     * 
     * @param className
     *            The name of the class
     * @param parameters
     *            A full list of parameters accepted/required by the sample
     * @param parameterDescriptions
     *            A full list of descriptions for parameters accepted/required by the sample
     */
    protected static void outputUsageDetails(String className, List<String> parameters, List<String> parameterDescriptions) {
        StringBuilder parameterString = new StringBuilder(className);

        for (String parameter : parameters) {
            parameterString.append(" ");

            parameterString.append(parameter);
        }

        System.out.println(parameterString);

        for (String description : parameterDescriptions) {
            System.out.println(description);
        }
    }
}
