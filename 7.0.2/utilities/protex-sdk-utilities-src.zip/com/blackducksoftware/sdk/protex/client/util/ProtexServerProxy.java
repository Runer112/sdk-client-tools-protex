/*
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */
package com.blackducksoftware.sdk.protex.client.util;

import java.io.Closeable;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.xml.ws.soap.SOAPFaultException;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.handler.WSHandlerConstants;

import com.blackducksoftware.sdk.fault.ErrorCode;
import com.blackducksoftware.sdk.fault.SdkFault;
import com.blackducksoftware.sdk.impl.logging.PrettyLoggingInInterceptor;
import com.blackducksoftware.sdk.impl.logging.PrettyLoggingOutInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEPasswordMaskedLoggingInInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEPasswordMaskedLoggingOutInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEPasswordMaskedPrettyLoggingInInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEPasswordMaskedPrettyLoggingOutInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEStrippedLoggingInInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEStrippedLoggingOutInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEStrippedPrettyLoggingInInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEStrippedPrettyLoggingOutInterceptor;
import com.blackducksoftware.sdk.impl.logging.WsseLoggingLevel;
import com.blackducksoftware.sdk.protex.comparison.FileComparisonApi;
import com.blackducksoftware.sdk.protex.component.ComponentApi;
import com.blackducksoftware.sdk.protex.component.custom.CustomComponentManagementApi;
import com.blackducksoftware.sdk.protex.license.LicenseApi;
import com.blackducksoftware.sdk.protex.obligation.ObligationApi;
import com.blackducksoftware.sdk.protex.policy.PolicyApi;
import com.blackducksoftware.sdk.protex.policy.externalid.ExternalIdApi;
import com.blackducksoftware.sdk.protex.project.ProjectApi;
import com.blackducksoftware.sdk.protex.project.bom.BomApi;
import com.blackducksoftware.sdk.protex.project.codetree.CodeTreeApi;
import com.blackducksoftware.sdk.protex.project.codetree.discovery.DiscoveryApi;
import com.blackducksoftware.sdk.protex.project.codetree.identification.IdentificationApi;
import com.blackducksoftware.sdk.protex.project.localcomponent.LocalComponentApi;
import com.blackducksoftware.sdk.protex.report.ReportApi;
import com.blackducksoftware.sdk.protex.role.RoleApi;
import com.blackducksoftware.sdk.protex.user.UserApi;

/**
 * A Proxy class which provides the ability to retrieve references to the service API interfaces
 * 
 * <p>
 * Provides a {@link #close()} method to allow for erasing of the stored server password used with the proxy instance
 * </p>
 */
public class ProtexServerProxy implements Closeable {

    /**
     * Property which controls the amount of debug logging which occurs. Valid values are
     * "false" and numeric constants represents values of {@link WsseLoggingLevel}
     */
    public static final String PROTEX_SDK_DEBUG_PROPERTY = "protex.sdk.debug";

    /** Timeout value which indicates no timeout should be used */
    public static final long INDEFINITE_TIMEOUT = 0L;

    /**
     * String constant which is a unique base WSDL version identifier for the Protex SDK APIs
     * referenced by this Proxy
     */
    private static final String PROTEX_SDK_VERSION = "7_0";

    /** The logging level of WSSE operations. Defaults to {@link WsseLoggingLevel#COMPACT_PRETTY} */
    protected WsseLoggingLevel wsseLoggingLevel = WsseLoggingLevel.COMPACT_PRETTY;

    /** Boolean which controls Proxy debug logging. Defaults to false (info logging only) */
    protected boolean logDebug = false;

    /** Input properties for WSDL communication */
    protected Map<String, Object> inProps = null;

    /** Output properties for WSDL communication */
    protected Map<String, Object> outProps = null;

    /** The URL of the server this proxy will communicate with to get service API instances */
    private String serverUrl = null;

    /**
     * The user name to authenticate with to obtain access to the server. All server API calls
     * will be made with these credentials
     */
    private String userName = null;

    /**
     * The password to authenticate with to obtain access to the server. All service API calls
     * will be made with these credentials
     */
    private char[] password = null;

    /** The default timeout when communicating with the server. Defaults to {@link #INDEFINITE_TIMEOUT} */
    private long defaultTimeout = INDEFINITE_TIMEOUT;

    /** The default limit for returned list size */
    private long maximumChildElements = 1000000;

    /** Internally cached reference to the license API on the server being interfaced with by this proxy */
    private LicenseApi licenseApi = null;

    /** Internally cached reference to the local component API on the server being interfaced with by this proxy */
    private LocalComponentApi localComponentApi = null;

    /** Internally cached reference to the component API on the server being interfaced with by this proxy */
    private ComponentApi componentApi = null;

    /**
     * Internally cached reference to the custom component management API on the server being interfaced with by this
     * proxy
     */
    private CustomComponentManagementApi customComponentManagementApi = null;

    /** Internally cached reference to the obligation API on the server being interfaced with by this proxy */
    private ObligationApi obligationApi = null;

    /** Internally cached reference to the policy API on the server being interfaced with by this proxy */
    private PolicyApi policyApi = null;

    /** Internally cached reference to the external ID API on the server being interfaced with by this proxy */
    private ExternalIdApi externalIdApi = null;

    /** Internally cached reference to the file comparison API on the server being interfaced with by this proxy */
    private FileComparisonApi fileComparisonApi = null;

    /** Internally cached reference to the project API on the server being interfaced with by this proxy */
    private ProjectApi projectApi = null;

    /** Internally cached reference to the code tree API on the server being interfaced with by this proxy */
    private CodeTreeApi codeTreeApi = null;

    /** Internally cached reference to the BOM API on the server being interfaced with by this proxy */
    private BomApi bomApi = null;

    /** Internally cached reference to the discovery API on the server being interfaced with by this proxy */
    private DiscoveryApi discoveryApi = null;

    /** Internally cached reference to the identification API on the server being interfaced with by this proxy */
    private IdentificationApi identificationApi = null;

    /** Internally cached reference to the report API on the server being interfaced with by this proxy */
    private ReportApi reportApi = null;

    /** Internally cached reference to the role API on the server being interfaced with by this proxy */
    private RoleApi roleApi = null;

    /** Internally cached reference to the user API on the server being interfaced with by this proxy */
    private UserApi userApi = null;

    /**
     * Creates a new proxy to interact with a Protex server via SDK entry points
     * 
     * <p>
     * Use per server and per user
     * </p>
     * 
     * @param serverUrl
     *            The base URI for the Protex server. Example: http://protex.example.com:80/
     * @param userName
     *            The user name to use to login to the Protex server. Example: test@example.com
     * @param password
     *            The password for the provided user
     * @param serverDefaultTimeout
     *            The default timeout for API connections if one is not specified upon creation
     */
    public ProtexServerProxy(String serverUrl, String userName, String password, long serverDefaultTimeout) {
        while ((serverUrl.length() > 0) && serverUrl.endsWith("/")) {
            serverUrl = serverUrl.substring(0, serverUrl.length() - 1);
        }

        String debugProperty = System.getProperty(PROTEX_SDK_DEBUG_PROPERTY, "false");

        if (debugProperty.equals(WsseLoggingLevel.COMPACT_PRETTY.getExternalLevel()) || debugProperty.equals("true")) {
            logDebug = true;
            wsseLoggingLevel = WsseLoggingLevel.COMPACT_PRETTY;
        } else if (debugProperty.equals(WsseLoggingLevel.COMPACT.getExternalLevel())
                || debugProperty.equals(WsseLoggingLevel.VERBOSE_SECURE.getExternalLevel())
                || debugProperty.equals(WsseLoggingLevel.VERBOSE_SECURE_PRETTY.getExternalLevel())
                || debugProperty.equals(WsseLoggingLevel.VERBOSE.getExternalLevel())) {
            logDebug = true;
            wsseLoggingLevel = WsseLoggingLevel.createFromExternalLevel(debugProperty);
        } else if ("false".equals(debugProperty)) {
            logDebug = false;
        } else {
            System.err.println("Unknown value for system property 'protex.sdk.debug=" + debugProperty
                    + "'. Expected 0, 1, 2, 3, or 4");
        }

        if (logDebug) {
            System.out.println("ServerUrl: " + serverUrl);
            System.out.println("Authenticate with: " + userName + " :: " + getPasswordMask(password.toCharArray()));
            System.out.println("WSDL Base Version: " + PROTEX_SDK_VERSION);
        }

        this.serverUrl = serverUrl;
        this.userName = userName;
        this.password = password.toCharArray();
        defaultTimeout = serverDefaultTimeout;

        System.out.println("Proxy initialized - SDK version 7.0");
    }

    /**
     * Creates a new proxy to interact with a Protex server via SDK entry points
     * 
     * <p>
     * Uses a default timeout of {@link #INDEFINITE_TIMEOUT}
     * </p>
     * 
     * <p>
     * Use per server and per user
     * </p>
     * 
     * @param serverUrl
     *            The base URI for the Protex server. Example: http://protex.example.com:80/
     * @param userName
     *            The user name to use to login to the Protex server. Example: test@example.com
     * @param password
     *            The password for the provided user
     */
    public ProtexServerProxy(String serverUrl, String userName, String password) {
        this(serverUrl, userName, password, INDEFINITE_TIMEOUT);
    }

    /**
     * Gets the default timeout for all get*Api calls that don't specify their own
     * 
     * @return The timeout in milliseconds
     */
    public Long getDefaultTimeout() {
        return defaultTimeout;
    }

    /**
     * Sets the default timeout for all get*Api calls that don't specify their own
     * 
     * @param defaultTimeout
     *            The timeout in milliseconds
     */
    public void setDefaultTimeout(long defaultTimeout) {
        this.defaultTimeout = defaultTimeout;
    }

    /**
     * Gets the maximum number of elements allowed in returned lists
     * 
     * @return The timeout in milliseconds
     */
    public Long getMaximumChildElements() {
        return maximumChildElements;
    }

    /**
     * Sets the maximum number of elements allowed in returned lists
     * 
     * @param maximumChildElements
     *            The maximum number of elements allowed in returned lists
     */
    public void setMaximumChildElements(long maximumChildElements) {
        this.maximumChildElements = maximumChildElements;
    }

    /**
     * Validates the configured User Credentials
     * 
     * @throws ServerAuthenticationException
     *             If the credentials fail to authenticate with the server for any reason (invalid URL or user
     *             name/password)
     */
    public void validateCredentials() throws ServerAuthenticationException {
        try {
            // call the cheapest method possible on the server, as every call is sent with the credentials (according to
            // WS-I Basic profile compliance)
            getUserApi().getCurrentUserHasServerFileAccess();
        } catch (SdkFault e) {
            if (ErrorCode.INVALID_CREDENTIALS.equals(e.getFaultInfo().getErrorCode())) {
                throw new ServerAuthenticationException("Invalid credentials provided for '" + userName + "'", e);
            } else {
                // Eat these errors - we just want to know if the user exists and can talk to the server
                System.err.println(e.getMessage());
            }
        } catch (SOAPFaultException e) {
            throw new ServerAuthenticationException("Validating credentials for '" + userName + "' failed", e);
        }
    }

    /**
     * Resets all cached API connections. Any subsequent calls to get*Api() will create a fresh connection
     * to the server
     * 
     * <p>
     * This call may be used to attempt to handle {@code TimeoutException} occurrences - call this method and use
     * get*Api() to get a fresh connection
     * </p>
     */
    public void resetApiConnections() {
        licenseApi = null;
        localComponentApi = null;
        obligationApi = null;
        policyApi = null;
        externalIdApi = null;
        fileComparisonApi = null;
        projectApi = null;
        codeTreeApi = null;
        bomApi = null;
        discoveryApi = null;
        identificationApi = null;
        reportApi = null;
        roleApi = null;
        userApi = null;
    }

    @Override
    public void close() throws IOException {
        // Null out the password upon destruction
        for (int i = 0; i < password.length; i++) {
            password[i] = '\0';
        }
    }

    /* === APIs === */

    /**
     * Get a reference the license API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The license API entry point for SDK calls to the server
     */
    public LicenseApi getLicenseApi() {
        return this.getLicenseApi(defaultTimeout);
    }

    /**
     * Get a reference the license API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The license API entry point for SDK calls to the server
     */
    public LicenseApi getLicenseApi(long timeout) {
        licenseApi = getApiInstance(licenseApi, ProtexApi.LICENSE, timeout);
        return licenseApi;
    }

    /**
     * Get a reference the component API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The custom component API entry point for SDK calls to the server
     */
    public ComponentApi getComponentApi() {
        return getComponentApi(defaultTimeout);
    }

    /**
     * Get a reference the component API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The custom component API entry point for SDK calls to the server
     */
    public ComponentApi getComponentApi(long timeout) {
        componentApi = getApiInstance(componentApi, ProtexApi.COMPONENT, timeout);
        return componentApi;
    }

    /**
     * Get a reference the custom component API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The custom component API entry point for SDK calls to the server
     */
    public CustomComponentManagementApi getCustomComponentManagementApi() {
        return getCustomComponentManagementApi(defaultTimeout);
    }

    /**
     * Get a reference the custom component API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The custom component API entry point for SDK calls to the server
     */
    public CustomComponentManagementApi getCustomComponentManagementApi(long timeout) {
        customComponentManagementApi = getApiInstance(customComponentManagementApi, ProtexApi.CUSTOM_COMPONENT_MANAGEMENT, timeout);
        return customComponentManagementApi;
    }

    /**
     * Get a reference the local component API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The local component API entry point for SDK calls to the server
     */
    public LocalComponentApi getLocalComponentApi() {
        return getLocalComponentApi(defaultTimeout);
    }

    /**
     * Get a reference the local component API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The local component API entry point for SDK calls to the server
     */
    public LocalComponentApi getLocalComponentApi(Long timeout) {
        localComponentApi = getApiInstance(localComponentApi, ProtexApi.LOCAL_COMPONENT, timeout);
        return localComponentApi;
    }

    /**
     * Get a reference the obligation API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The obligation API entry point for SDK calls to the server
     */
    public ObligationApi getObligationApi() {
        return getObligationApi(defaultTimeout);
    }

    /**
     * Get a reference the obligation API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The obligation API entry point for SDK calls to the server
     */
    public ObligationApi getObligationApi(long timeout) {
        obligationApi = getApiInstance(obligationApi, ProtexApi.OBLIGATION, timeout);
        return obligationApi;
    }

    /**
     * Get a reference the policy API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The policy API entry point for SDK calls to the server
     */
    public PolicyApi getPolicyApi() {
        return getPolicyApi(defaultTimeout);
    }

    /**
     * Get a reference the policy API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The policy API entry point for SDK calls to the server
     */
    public PolicyApi getPolicyApi(long timeout) {
        policyApi = getApiInstance(policyApi, ProtexApi.POLICY, timeout);
        return policyApi;
    }

    /**
     * Get a reference the external ID API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The external ID API entry point for SDK calls to the server
     */
    public ExternalIdApi getExternalIdApi() {
        return getExternalIdApi(defaultTimeout);
    }

    /**
     * Get a reference the external ID API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The license API entry point for SDK calls to the server
     */
    public ExternalIdApi getExternalIdApi(long timeout) {
        externalIdApi = getApiInstance(externalIdApi, ProtexApi.EXTERNAL_ID, timeout);
        return externalIdApi;
    }

    /**
     * Get a reference the file comparison API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The file comparison API entry point for SDK calls to the server
     */
    public FileComparisonApi getFileComparisonApi() {
        return getFileComparisonApi(defaultTimeout);
    }

    /**
     * Get a reference the file comparison API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The file comparison API entry point for SDK calls to the server
     */
    public FileComparisonApi getFileComparisonApi(long timeout) {
        fileComparisonApi = getApiInstance(fileComparisonApi, ProtexApi.FILE_COMPARISON, timeout);
        return fileComparisonApi;
    }

    /**
     * Get a reference the project API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The project API entry point for SDK calls to the server
     */
    public ProjectApi getProjectApi() {
        return getProjectApi(defaultTimeout);
    }

    /**
     * Get a reference the project API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The project API entry point for SDK calls to the server
     */
    public ProjectApi getProjectApi(long timeout) {
        projectApi = getApiInstance(projectApi, ProtexApi.PROJECT, timeout);
        return projectApi;
    }

    /**
     * Get a reference the BOM API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The BOM API entry point for SDK calls to the server
     */
    public BomApi getBomApi() {
        return getBomApi(defaultTimeout);
    }

    /**
     * Get a reference the BOM API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The BOM API entry point for SDK calls to the server
     */
    public BomApi getBomApi(long timeout) {
        bomApi = getApiInstance(bomApi, ProtexApi.BOM, timeout);
        return bomApi;
    }

    /**
     * Get a reference the code tree API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The code tree API entry point for SDK calls to the server
     */
    public CodeTreeApi getCodeTreeApi() {
        return getCodeTreeApi(defaultTimeout);
    }

    /**
     * Get a reference the code tree API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The code tree API entry point for SDK calls to the server
     */
    public CodeTreeApi getCodeTreeApi(Long timeout) {
        codeTreeApi = getApiInstance(codeTreeApi, ProtexApi.CODETREE, timeout);
        return codeTreeApi;
    }

    /**
     * Get a reference the discovery API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The discovery API entry point for SDK calls to the server
     */
    public DiscoveryApi getDiscoveryApi() {
        return getDiscoveryApi(defaultTimeout);
    }

    /**
     * Get a reference the discovery API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The discovery API entry point for SDK calls to the server
     */
    public DiscoveryApi getDiscoveryApi(Long timeout) {
        discoveryApi = getApiInstance(discoveryApi, ProtexApi.DISCOVERY, timeout);
        return discoveryApi;
    }

    /**
     * Get a reference the identification API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The identification API entry point for SDK calls to the server
     */
    public IdentificationApi getIdentificationApi() {
        return getIdentificationApi(defaultTimeout);
    }

    /**
     * Get a reference the identification API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The identification API entry point for SDK calls to the server
     */
    public IdentificationApi getIdentificationApi(Long timeout) {
        identificationApi = getApiInstance(identificationApi, ProtexApi.IDENTIFICATION, timeout);
        return identificationApi;
    }

    /**
     * Get a reference the report API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The report API entry point for SDK calls to the server
     */
    public ReportApi getReportApi() {
        return getReportApi(defaultTimeout);
    }

    /**
     * Get a reference the report API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The report API entry point for SDK calls to the server
     */
    public ReportApi getReportApi(Long timeout) {
        reportApi = getApiInstance(reportApi, ProtexApi.REPORT, timeout);
        return reportApi;
    }

    /**
     * Get a reference the role API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The role API entry point for SDK calls to the server
     */
    public RoleApi getRoleApi() {
        return getRoleApi(defaultTimeout);
    }

    /**
     * Get a reference the role API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The role API entry point for SDK calls to the server
     */
    public RoleApi getRoleApi(Long timeout) {
        roleApi = getApiInstance(roleApi, ProtexApi.ROLE, timeout);
        return roleApi;
    }

    /**
     * Get a reference the user API entry point
     * 
     * <p>
     * Uses the configured proxy default timeout for server communication
     * </p>
     * 
     * @return The user API entry point for SDK calls to the server
     */
    public UserApi getUserApi() {
        return getUserApi(defaultTimeout);
    }

    /**
     * Get a reference the user API entry point
     * 
     * @param timeout
     *            The timeout to use when communicating with the server. Applies only to
     *            this call (does not change proxy default timeout)
     * @return The user API entry point for SDK calls to the server
     */
    public UserApi getUserApi(Long timeout) {
        userApi = getApiInstance(userApi, ProtexApi.USER, timeout);
        return userApi;
    }

    /**
     * Initialize the Authentication Properties, such as user name and password
     * 
     * @param userName
     *            The user name to login to the Protex server, for example: test@example.com
     * @param password
     *            The user's password
     */
    protected void initAuthProps(String userName, char[] password) {
        if (inProps == null) {
            inProps = new HashMap<String, Object>();
            // instrument service with authentication credentials
            inProps.put(WSHandlerConstants.ACTION, WSHandlerConstants.NO_SECURITY);
        }

        if (outProps == null) {
            outProps = new HashMap<String, Object>();
            outProps.put(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
            // Specify our username
            outProps.put(WSHandlerConstants.USER, userName);
            // Password type : plain text
            outProps.put(WSHandlerConstants.PASSWORD_TYPE, WSConstants.PW_TEXT);
            // Callback used to retrieve password for given user.
            outProps.put(WSHandlerConstants.PW_CALLBACK_REF, new ProgrammedPasswordCallback(userName, password));
            outProps.put(WSHandlerConstants.MUST_UNDERSTAND, "false");
        }

        if (logDebug) {
            System.out.println("Authenticate with: " + userName + " :: " + getPasswordMask(password));
        }
    }

    /**
     * Configures properties on the CXF end point like maximum child elements. Clients may override this method to add
     * custom configuration
     * 
     * @param cxfEndpoint
     *            The end point to configure properties on
     */
    protected void configureCxfEndpoint(org.apache.cxf.endpoint.Endpoint cxfEndpoint) {
        cxfEndpoint.put("org.apache.cxf.stax.maxChildElements", maximumChildElements);
    }

    /**
     * Instrument the service port object with authentication information and the appropriate handlers
     * 
     * @param serviceApi
     *            The service port Object
     * @param userName
     *            The user name to login to the Protex server, for example: test@example.com
     * @param password
     *            The users password
     * @param timeout
     *            Optional HTTP timeout in milliseconds, if {@link #INDEFINITE_TIMEOUT}, there is
     *            no timeout
     */
    protected void instrumentService(Object serviceApi, String userName, char[] password, long timeout) {
        if (logDebug) {
            System.out.println("instrument service: " + serviceApi.toString());
        }
        initAuthProps(userName, password);

        org.apache.cxf.endpoint.Client client = org.apache.cxf.frontend.ClientProxy.getClient(serviceApi);
        org.apache.cxf.endpoint.Endpoint cxfEndpoint = client.getEndpoint();

        WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(outProps);
        cxfEndpoint.getOutInterceptors().add(wssOut);

        if (logDebug) {
            AbstractPhaseInterceptor<Message> inInterceptor = null;
            AbstractPhaseInterceptor<Message> outInterceptor = null;
            AbstractPhaseInterceptor<Message> faultInterceptor = null;
            if (wsseLoggingLevel == WsseLoggingLevel.COMPACT) {
                inInterceptor = new WSSEStrippedLoggingInInterceptor();
                faultInterceptor = new WSSEStrippedLoggingInInterceptor();
                outInterceptor = new WSSEStrippedLoggingOutInterceptor();
            } else if (wsseLoggingLevel == WsseLoggingLevel.COMPACT_PRETTY) {
                inInterceptor = new WSSEStrippedPrettyLoggingInInterceptor();
                faultInterceptor = new WSSEStrippedPrettyLoggingInInterceptor();
                outInterceptor = new WSSEStrippedPrettyLoggingOutInterceptor();
            } else if (wsseLoggingLevel == WsseLoggingLevel.VERBOSE) {
                inInterceptor = new PrettyLoggingInInterceptor();
                faultInterceptor = new PrettyLoggingInInterceptor();
                outInterceptor = new PrettyLoggingOutInterceptor();
            } else if (wsseLoggingLevel == WsseLoggingLevel.VERBOSE_SECURE) {
                inInterceptor = new WSSEPasswordMaskedLoggingInInterceptor();
                faultInterceptor = new WSSEPasswordMaskedLoggingInInterceptor();
                outInterceptor = new WSSEPasswordMaskedLoggingOutInterceptor();
            } else if (wsseLoggingLevel == WsseLoggingLevel.VERBOSE_SECURE_PRETTY) {
                inInterceptor = new WSSEPasswordMaskedPrettyLoggingInInterceptor();
                faultInterceptor = new WSSEPasswordMaskedPrettyLoggingInInterceptor();
                outInterceptor = new WSSEPasswordMaskedPrettyLoggingOutInterceptor();
            }
            cxfEndpoint.getInInterceptors().add(inInterceptor);
            cxfEndpoint.getInInterceptors().add(faultInterceptor);

            cxfEndpoint.getOutInterceptors().add(outInterceptor);
        }

        configureCxfEndpoint(cxfEndpoint);

        // Set timeout
        setTimeout(serviceApi, timeout);

        /*
         * ONLY FOR DEVELOPMENT - uncomment if you are working with a non exact match on the hostname in the SSL
         * Certificate - NOT RECOMMENDED FOR PRODUCTION USE
         */
        // HTTPConduit http = (HTTPConduit) client.getConduit();
        //
        // TLSClientParameters tlsClientParameters = new TLSClientParameters();
        // tlsClientParameters.setDisableCNCheck(true);
        // http.setTlsClientParameters(tlsClientParameters);
    }

    /**
     * Masks the provided string to avoid showing sensitive credential information in logged messages
     * 
     * @param password
     *            The string to mask with '*' characters
     * @return A masked string which does not reveal the password used by this proxy
     */
    protected String getPasswordMask(char[] password) {
        char[] mask = new char[password.length];
        Arrays.fill(mask, '*');
        return new String(mask);
    }

    /**
     * Creates a connection the Protex SDK API specified on the server this proxy is configured with
     * 
     * @param targetApi
     *            The cached API value for the API to retrieve. May be null
     * @param api
     *            The SDK API type being retrieved
     * @param timeout
     *            The timeout to configure the connection with
     * @return An instance of the API requested
     */
    private <T> T getApiInstance(T targetApi, ProtexApi api, long timeout) {
        if (targetApi == null) {
            targetApi = (T) getPortFromUrl(api.getApiClass(), serverUrl + api.getServiceStub());

            instrumentService(targetApi, userName, password, timeout);
        } else {
            Long serviceTimeout = getTimeout(targetApi);

            if (timeout != serviceTimeout) {
                setTimeout(targetApi, timeout);
            }
        }

        return targetApi;
    }

    /**
     * Get the current HTTP timeout value for a service port
     * 
     * @param serviceApi
     *            The object representing the service API port
     * @return The timeout in milliseconds for the provided API port
     */
    private Long getTimeout(Object serviceApi) {
        if (logDebug) {
            System.out.println("get timeout for service: " + serviceApi.toString());
        }

        org.apache.cxf.endpoint.Client client = org.apache.cxf.frontend.ClientProxy.getClient(serviceApi);
        /* get timeout */
        HTTPConduit http = (HTTPConduit) client.getConduit();

        HTTPClientPolicy httpClientPolicy = http.getClient();
        return httpClientPolicy.getConnectionTimeout();
    }

    /**
     * Set the HTTP timeout value for a service port
     * 
     * @param serviceApi
     *            The object representing the service API port
     * @param timeout
     *            The timeout in milliseconds to configure the server API port with
     * 
     */
    private void setTimeout(Object serviceApi, Long timeout) {
        if (logDebug) {
            System.out.println("set timeout for service: " + serviceApi.toString());
        }
        org.apache.cxf.endpoint.Client client = org.apache.cxf.frontend.ClientProxy.getClient(serviceApi);
        /* set timeout */
        HTTPConduit http = (HTTPConduit) client.getConduit();

        HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
        httpClientPolicy.setConnectionTimeout(timeout.longValue());
        httpClientPolicy.setReceiveTimeout(timeout.longValue());

        http.setClient(httpClientPolicy);
    }

    /**
     * Creates a service API port to the given URL
     * 
     * @param serviceClass
     *            The class which represents the port object being retrieved
     * @param serviceUrl
     *            The URL which corresponds to the communication point for the port object
     * @return An instance of the port object mapped to the specified class
     */
    private <T> Object getPortFromUrl(Class<T> serviceClass, String serviceUrl) {
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
        factory.setServiceClass(serviceClass);
        factory.setAddress(serviceUrl);

        if (logDebug) {
            System.out.println("getPortFromUrl: ServiceUrl = " + serviceUrl);
        }

        return factory.create();
    }

    /**
     * Encodes information about the SDK APIs which are offered by a Protex server
     */
    private static enum ProtexApi {

        LICENSE("license", LicenseApi.class),
        COMPONENT("component", ComponentApi.class),
        CUSTOM_COMPONENT_MANAGEMENT("customcomponentmanagement", CustomComponentManagementApi.class),
        LOCAL_COMPONENT("localcomponent", LocalComponentApi.class),
        OBLIGATION("obligation", ObligationApi.class),
        POLICY("policy", PolicyApi.class),
        EXTERNAL_ID("externalid", ExternalIdApi.class),
        FILE_COMPARISON("filecomparison", FileComparisonApi.class),
        PROJECT("project", ProjectApi.class),
        CODETREE("codetree", CodeTreeApi.class),
        BOM("bom", BomApi.class),
        DISCOVERY("discovery", DiscoveryApi.class),
        IDENTIFICATION("identification", IdentificationApi.class),
        REPORT("report", ReportApi.class),
        ROLE("role", RoleApi.class),
        USER("user", UserApi.class),

        ;

        /** The URL which references the WSDL file on a protex server for the API */
        private final String serviceStub;

        /** The class which the target URL maps to for the API */
        private final Class<?> apiClass;

        /**
         * @param apiStub
         *            The URL which references the WSDL file on a protex server for the API
         * @param apiClass
         *            The class which the target URL maps to for the API
         */
        private ProtexApi(String apiStub, Class<?> apiClass) {
            serviceStub = "/protex-sdk/v" + PROTEX_SDK_VERSION + "/" + apiStub;
            this.apiClass = apiClass;
        }

        /**
         * @return The URL which references the WSDL file on a protex server for the API
         */
        public String getServiceStub() {
            return serviceStub;
        }

        /**
         * @return The class which the target URL maps to for the API
         */
        public Class<?> getApiClass() {
            return apiClass;
        }
    }

}
