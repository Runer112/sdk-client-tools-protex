/*
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */
package com.blackducksoftware.sdk.protex.client.util;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.UnsupportedCallbackException;

import org.apache.ws.security.WSPasswordCallback;

// TODO Implement TextPromptUserPasswordCallback() method prompting on the cmd line, if not set
// TODO Implement WindowPromptPasswordCallback() method prompting with window, if not set

public class ProgrammedPasswordCallback implements CallbackHandler {

    private String username = null;

    private char[] password = null;

    public ProgrammedPasswordCallback(String username, char[] password) {
        this.username = username;
        this.password = password;
    }

    @Override
    public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {

        WSPasswordCallback pc = null;
        try {
            pc = (WSPasswordCallback) callbacks[0];
        } catch (ClassCastException ce) {
            throw new UnsupportedCallbackException(pc, "callback method is not of type "
                    + WSPasswordCallback.class.getName());
        }
        String identifier = pc.getIdentifier();
        if (username == null) {
            throw new UnsupportedCallbackException(pc,
                    "Password not set in client. Call constructor method "
                            + ProgrammedPasswordCallback.class.getName()
                            + "(\"<your username>\", \"<your password>\")");
        }

        // set the password for our outgoing message.
        if (username.equals(identifier)) {
            pc.setPassword(new String(password));
        } else {
            throw new UnsupportedCallbackException(pc,
                    "Password not set in client. Call constructor method "
                            + ProgrammedPasswordCallback.class.getName()
                            + "(\"<your username>\", \"<your password>\")");
        }
    }
}
