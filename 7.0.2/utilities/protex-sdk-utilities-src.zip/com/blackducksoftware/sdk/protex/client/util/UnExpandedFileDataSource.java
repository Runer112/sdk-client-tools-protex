package com.blackducksoftware.sdk.protex.client.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * This DateSource wraps up the source archive inside a zip archive.
 */
import javax.activation.DataSource;

public class UnExpandedFileDataSource implements DataSource {

    private final File sourceArchive;

    private File zipArchive;

    public UnExpandedFileDataSource(File sourceArchive) {
        this.sourceArchive = sourceArchive;
        createZipArchive();
    }

    @Override
    public String getContentType() {
        return "application/zip";
    }

    @Override
    public InputStream getInputStream() throws IOException {

        byte[] buffer = new byte[1024];
        int len;

        FileOutputStream fos = new FileOutputStream(zipArchive);
        ZipOutputStream zos = new ZipOutputStream(fos);
        FileInputStream fis = new FileInputStream(sourceArchive);
        zos.putNextEntry(new ZipEntry(sourceArchive.getName()));

        while ((len = fis.read(buffer)) > 0) {
            zos.write(buffer, 0, len);
        }

        zos.closeEntry();
        fis.close();
        zos.close();

        return new FileInputStream(zipArchive);
    }

    @Override
    public String getName() {
        return sourceArchive.getName();
    }

    public File getZipArchive() {
        return zipArchive;
    }

    private void createZipArchive() {
        String sourceName = sourceArchive.getName();
        String zipArchiveName = sourceName.substring(0, sourceName.lastIndexOf(".")) + ".zip";
        zipArchive = new File(zipArchiveName);
        zipArchive.deleteOnExit();
    }

    @Override
    public OutputStream getOutputStream() throws IOException {
        throw new IOException("Read Only DataSource");
    }
}
