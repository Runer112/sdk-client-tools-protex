/*
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */
package com.blackducksoftware.sdk.protex.util;

import com.blackducksoftware.sdk.protex.common.ComponentInfoColumn;
import com.blackducksoftware.sdk.protex.common.ComponentInfoPageFilter;
import com.blackducksoftware.sdk.protex.common.FileDiscoveryPatternColumn;
import com.blackducksoftware.sdk.protex.common.FileDiscoveryPatternPageFilter;
import com.blackducksoftware.sdk.protex.common.PageFilter;
import com.blackducksoftware.sdk.protex.common.SortType;
import com.blackducksoftware.sdk.protex.component.custom.CustomComponentColumn;
import com.blackducksoftware.sdk.protex.component.custom.CustomComponentPageFilter;
import com.blackducksoftware.sdk.protex.component.standard.StandardComponentColumn;
import com.blackducksoftware.sdk.protex.component.standard.StandardComponentPageFilter;
import com.blackducksoftware.sdk.protex.component.version.ComponentVersionInfoColumn;
import com.blackducksoftware.sdk.protex.component.version.ComponentVersionInfoPageFilter;
import com.blackducksoftware.sdk.protex.license.LicenseInfoColumn;
import com.blackducksoftware.sdk.protex.license.LicenseInfoPageFilter;
import com.blackducksoftware.sdk.protex.obligation.AssignedObligationColumn;
import com.blackducksoftware.sdk.protex.obligation.AssignedObligationPageFilter;
import com.blackducksoftware.sdk.protex.project.ProjectColumn;
import com.blackducksoftware.sdk.protex.project.ProjectInfoColumn;
import com.blackducksoftware.sdk.protex.project.ProjectInfoPageFilter;
import com.blackducksoftware.sdk.protex.project.ProjectPageFilter;
import com.blackducksoftware.sdk.protex.project.localcomponent.LocalComponentColumn;
import com.blackducksoftware.sdk.protex.project.localcomponent.LocalComponentPageFilter;
import com.blackducksoftware.sdk.protex.user.UserColumn;
import com.blackducksoftware.sdk.protex.user.UserPageFilter;

/**
 * Convenience class to create and manage PageFilter objects
 * 
 * PageFitler objects can be used to force particular Sort orders as well as to limit the number of objects returned.
 * The main purpose of limiting the number of returned objects is performance and memory management on the client side
 * as well as on the server side.
 * 
 */
public class PageFilterFactory {

    public static PageFilter getAllRows(PageFilter pageFilter) {
        pageFilter.setFirstRowIndex(0);
        pageFilter.setLastRowIndex(Integer.MAX_VALUE);
        pageFilter.setSortAscending(Boolean.TRUE);
        pageFilter.setSortType(SortType.ALPHABETICAL_CASE_SENSITIVE);

        return pageFilter;

    }

    public static ProjectPageFilter getAllRows(ProjectColumn sortColumn) {
        ProjectPageFilter pageFilter = (ProjectPageFilter) getAllRows(new ProjectPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static ProjectInfoPageFilter getAllRows(ProjectInfoColumn sortColumn) {
        ProjectInfoPageFilter pageFilter = (ProjectInfoPageFilter) getAllRows(new ProjectInfoPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static LocalComponentPageFilter getAllRows(LocalComponentColumn sortColumn) {
        LocalComponentPageFilter pageFilter = (LocalComponentPageFilter) getAllRows(new LocalComponentPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static StandardComponentPageFilter getAllRows(StandardComponentColumn sortColumn) {
        StandardComponentPageFilter pageFilter = (StandardComponentPageFilter) getAllRows(new StandardComponentPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static ComponentVersionInfoPageFilter getAllRows(ComponentVersionInfoColumn sortColumn) {
        ComponentVersionInfoPageFilter pageFilter = (ComponentVersionInfoPageFilter) getAllRows(new ComponentVersionInfoPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static CustomComponentPageFilter getAllRows(CustomComponentColumn sortColumn) {
        CustomComponentPageFilter pageFilter = (CustomComponentPageFilter) getAllRows(new CustomComponentPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static LicenseInfoPageFilter getAllRows(LicenseInfoColumn sortColumn) {
        LicenseInfoPageFilter pageFilter = (LicenseInfoPageFilter) getAllRows(new LicenseInfoPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static ComponentInfoPageFilter getAllRows(ComponentInfoColumn sortColumn) {
        ComponentInfoPageFilter pageFilter = (ComponentInfoPageFilter) getAllRows(new ComponentInfoPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static AssignedObligationPageFilter getAllRows(AssignedObligationColumn sortColumn) {
        AssignedObligationPageFilter pageFilter = (AssignedObligationPageFilter) getAllRows(new AssignedObligationPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static FileDiscoveryPatternPageFilter getAllRowsFileDiscoveryPattern(FileDiscoveryPatternColumn sortColumn) {
        return getAllRowsFileDiscoveryPattern(sortColumn, SortType.ALPHABETICAL_CASE_SENSITIVE);
    }

    public static UserPageFilter getAllRows(UserColumn sortColumn) {
        UserPageFilter pageFilter = (UserPageFilter) getAllRows(new UserPageFilter());
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    private static PageFilter getAllRows(PageFilter pageFilter, SortType sortType) {
        pageFilter.setFirstRowIndex(0);
        pageFilter.setLastRowIndex(Integer.MAX_VALUE);
        pageFilter.setSortAscending(Boolean.TRUE);
        pageFilter.setSortType(sortType);
        return pageFilter;
    }

    public static FileDiscoveryPatternPageFilter getAllRowsFileDiscoveryPattern(FileDiscoveryPatternColumn sortColumn,
            SortType sortType) {
        FileDiscoveryPatternPageFilter pageFilter = (FileDiscoveryPatternPageFilter) getAllRows(
                new FileDiscoveryPatternPageFilter(), sortType);
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    public static UserPageFilter getAllUserRows(UserColumn sortColumn,
            SortType sortType) {
        UserPageFilter pageFilter = (UserPageFilter) getAllRows(new UserPageFilter(), sortType);
        pageFilter.setSortedColumn(sortColumn);
        return pageFilter;
    }

    private static PageFilter getFirstPage(PageFilter firstPage, int pageSize, boolean sortAssending) {
        firstPage.setFirstRowIndex(1);
        firstPage.setLastRowIndex(pageSize);
        firstPage.setSortAscending(sortAssending);
        firstPage.setSortType(SortType.ALPHABETICAL_CASE_SENSITIVE);
        return firstPage;
    }

    public static LicenseInfoPageFilter getFirstPage(int pageSize, LicenseInfoColumn sortedColumn, boolean sortAssending) {
        LicenseInfoPageFilter firstPage = (LicenseInfoPageFilter) getFirstPage(new LicenseInfoPageFilter(), pageSize,
                sortAssending);
        firstPage.setSortedColumn(sortedColumn);
        return firstPage;
    }

    public static StandardComponentPageFilter getFirstPage(int pageSize, StandardComponentColumn sortedColumn, boolean sortAssending) {
        StandardComponentPageFilter firstPage = (StandardComponentPageFilter) getFirstPage(new StandardComponentPageFilter(), pageSize,
                sortAssending);
        firstPage.setSortedColumn(sortedColumn);
        return firstPage;
    }

    public static PageFilter getNextPage(PageFilter pageFilter) {
        int pageSize = 1;
        if (pageFilter.getFirstRowIndex() == 0) {
            pageSize = Math.max(1, pageFilter.getLastRowIndex() - pageFilter.getFirstRowIndex());
        } else {
            pageSize = Math.max(1, pageFilter.getLastRowIndex() - pageFilter.getFirstRowIndex() + 1);
        }
        pageFilter.setFirstRowIndex(pageFilter.getLastRowIndex() + 1);
        pageFilter.setLastRowIndex(pageFilter.getFirstRowIndex() + pageSize - 1);
        return pageFilter;
    }

}
