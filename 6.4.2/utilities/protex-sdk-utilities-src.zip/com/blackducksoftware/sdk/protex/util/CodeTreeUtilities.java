/*
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */package com.blackducksoftware.sdk.protex.util;

import java.util.ArrayList;
import java.util.List;

import com.blackducksoftware.sdk.protex.project.codetree.CodeTreeNodeType;

public class CodeTreeUtilities {

    /**
     * File Separator for CodeTree paths. This value is NOT OS dependent!
     */
    private static final String FS = "/";

    public static final Integer INFINITE_DEPTH = -1;

    public static final Integer SINGLE_NODE = 0;

    public static final Integer DIRECT_CHILDREN = 1;

    public static final List<CodeTreeNodeType> ALL_CODE_TREE_NODE_TYPES;

    static {
        ALL_CODE_TREE_NODE_TYPES = new ArrayList<CodeTreeNodeType>();

        for (CodeTreeNodeType nodeType : CodeTreeNodeType.values()) {
            ALL_CODE_TREE_NODE_TYPES.add(nodeType);
        }
    }

    /**
     * constructs a safe path, avoiding double Files separators &quot;/&quot;
     * 
     * @param parentPath
     *            the parentPath, i.e. &quot;/&quot;, &quot;/folder1&quot;
     * @param nodeName
     *            name of a file, folder or expanded Archive file
     * @return - the concatenated path
     */
    public String constructPath(String parentPath, String nodeName) {
        String p = ((parentPath.length() == 0) || (parentPath.endsWith(FS) || (nodeName.length() == 0)) ? parentPath
                : parentPath + FS)
                + nodeName;
        return p;
    }
}
