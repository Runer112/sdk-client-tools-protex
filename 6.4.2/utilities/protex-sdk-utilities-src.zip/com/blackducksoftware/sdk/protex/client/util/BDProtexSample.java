/*
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */
package com.blackducksoftware.sdk.protex.client.util;

/**
 * Black Duck Protex SDK Sample program
 */
public abstract class BDProtexSample {

    /**
     * Get the usage parameters for printing a usage command line as they are processed by this class
     * 
     * @return the String to use in a usage command line
     */
    public static String getUsageServiceParameters() {
        return "[-D" + ProtexServerProxyV6_3.PROTEX_SDK_DEBUG_PROPERTY
                + "=<logging level>] <serverUri> <username> <password>";
    }

    /**
     * Print the detailed description of usage for the parameters processed by this class
     */
    public static void printUsageServiceParameterDetails() {
        System.out
                .println("  logging level - The level of debug logging the Soap messages. "
                        + "Set to 0..4 for COMPACT_PRETTY(0), COMPACT(1), VERBOSE_SECURE(2), VERBOSE_SECURE_PRETTY(3), VERBOSE(4)");

        System.out.println("  serverUri - the base Uri for the server, i.e. http://protex.example.com:<port>/");
        System.out.println("  username  - the username for this server, i.e. tester@example.com");
        System.out.println("  password  - the passowrd for this user, i.e. simplepassword");
    }

}
