/*
 * Copyright (C) 2009, 2010 Black Duck Software Inc.
 * http://www.blackducksoftware.com/
 * All rights reserved.
 * 
 * This software is the confidential and proprietary information of
 * Black Duck Software ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Black Duck Software.
 */
package com.blackducksoftware.sdk.protex.client.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.xml.ws.soap.SOAPFaultException;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.ws.security.WSConstants;
import org.apache.ws.security.handler.WSHandlerConstants;

import com.blackducksoftware.sdk.fault.SdkFault;
import com.blackducksoftware.sdk.impl.logging.PrettyLoggingInInterceptor;
import com.blackducksoftware.sdk.impl.logging.PrettyLoggingOutInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEPasswordMaskedLoggingInInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEPasswordMaskedLoggingOutInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEPasswordMaskedPrettyLoggingInInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEPasswordMaskedPrettyLoggingOutInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEStrippedLoggingInInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEStrippedLoggingOutInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEStrippedPrettyLoggingInInterceptor;
import com.blackducksoftware.sdk.impl.logging.WSSEStrippedPrettyLoggingOutInterceptor;
import com.blackducksoftware.sdk.impl.logging.WsseLoggingLevel;
import com.blackducksoftware.sdk.protex.comparison.FileComparisonApi;
import com.blackducksoftware.sdk.protex.component.custom.CustomComponentApi;
import com.blackducksoftware.sdk.protex.component.standard.StandardComponentApi;
import com.blackducksoftware.sdk.protex.component.version.ComponentVersionApi;
import com.blackducksoftware.sdk.protex.license.LicenseApi;
import com.blackducksoftware.sdk.protex.obligation.ObligationApi;
import com.blackducksoftware.sdk.protex.policy.PolicyApi;
import com.blackducksoftware.sdk.protex.policy.externalid.ExternalIdApi;
import com.blackducksoftware.sdk.protex.project.ProjectApi;
import com.blackducksoftware.sdk.protex.project.bom.BomApi;
import com.blackducksoftware.sdk.protex.project.codetree.CodeTreeApi;
import com.blackducksoftware.sdk.protex.project.codetree.discovery.DiscoveryApi;
import com.blackducksoftware.sdk.protex.project.codetree.identification.IdentificationApi;
import com.blackducksoftware.sdk.protex.project.localcomponent.LocalComponentApi;
import com.blackducksoftware.sdk.protex.report.ReportApi;
import com.blackducksoftware.sdk.protex.role.RoleApi;
import com.blackducksoftware.sdk.protex.role.RoleName;
import com.blackducksoftware.sdk.protex.user.UserApi;

/**
 * A Proxy class making it convenient to connect to a Protex server and retrieve the various service objects
 */
public class ProtexServerProxyV6_3 {
    public static final String PROTEX_SDK_DEBUG_PROPERTY = "protex.sdk.debug";

    private static final String PROTEX_SDK_BASE_URI = "/protex-sdk";

    private static final String PROTEX_SDK_VERSION = "/v6_3";

    private static final String LICENSE_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/license";

    private static final String CUSTOM_COMPONENT_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION
            + "/customcomponent";

    private static final String LOCAL_COMPONENT_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION
            + "/localcomponent";

    private static final String STANDARD_COMPONENT_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION
            + "/standardcomponent";

    private static final String COMPONENT_VERSION_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION
            + "/componentversion";

    private static final String OBLIGATION_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/obligation";

    private static final String POLICY_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/policy";

    private static final String EXTERNAL_ID_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/externalid";

    private static final String FILE_COMPOARISON_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION
            + "/filecomparison";

    private static final String PROJECT_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/project";

    private static final String CODE_TREE_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/codetree";

    private static final String BOM_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/bom";

    private static final String DISCOVERY_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/discovery";

    private static final String IDENTIFICATION_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION
            + "/identification";

    private static final String REPORT_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/report";

    private static final String ROLE_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/role";

    private static final String USER_API_SERVICE_STUB = PROTEX_SDK_BASE_URI + PROTEX_SDK_VERSION + "/user";

    public static final Long INDEFINITE_TIMEOUT = 0L;

    private String serverUrl = null;

    private String userName = null;

    private String password = null;

    private Long defaultTimeout = INDEFINITE_TIMEOUT;

    protected WsseLoggingLevel wsseLoggingLevel = WsseLoggingLevel.COMPACT_PRETTY;

    private LicenseApi licenseApi = null;

    private CustomComponentApi customComponentApi = null;

    private LocalComponentApi localComponentApi = null;

    private StandardComponentApi standardComponentApi = null;

    private ComponentVersionApi componentVersionApi = null;

    private ObligationApi obligationApi = null;

    private PolicyApi policyApi = null;

    private ExternalIdApi externalIdApi = null;

    private FileComparisonApi fileComparisonApi = null;

    private ProjectApi projectApi = null;

    private CodeTreeApi codeTreeApi = null;

    private BomApi bomApi = null;

    private DiscoveryApi discoveryApi = null;

    private IdentificationApi identificationApi = null;

    private ReportApi reportApi = null;

    private RoleApi roleApi = null;

    private UserApi userApi = null;

    protected boolean logDebug = false;

    /**
     * Constructor for a ProtexProxyServerv5_0 object
     * 
     * @param serverUrl
     *            The base URI for the Protex server, for example http://protex.example.com:80/
     * @param userName
     *            The user name to login to the Protex server, for example: test@example.com
     * @param password
     *            The users password
     * 
     *            Use on ServerProxy per server and per user. The default timeout is 120 sec.
     */
    public ProtexServerProxyV6_3(String serverUrl, String userName, String password) {
        while ((serverUrl.length() > 0) && serverUrl.endsWith("/")) {
            serverUrl = serverUrl.substring(0, serverUrl.length() - 1);
        }
        String debugProperty = System.getProperty(PROTEX_SDK_DEBUG_PROPERTY, "false");
        if (debugProperty.equals(WsseLoggingLevel.COMPACT_PRETTY.getExternalLevel()) || debugProperty.equals("true")) {
            logDebug = true;
            wsseLoggingLevel = WsseLoggingLevel.COMPACT_PRETTY;
        } else if (debugProperty.equals(WsseLoggingLevel.COMPACT.getExternalLevel())
                || debugProperty.equals(WsseLoggingLevel.VERBOSE_SECURE.getExternalLevel())
                || debugProperty.equals(WsseLoggingLevel.VERBOSE_SECURE_PRETTY.getExternalLevel())
                || debugProperty.equals(WsseLoggingLevel.VERBOSE.getExternalLevel())) {
            logDebug = true;
            wsseLoggingLevel = WsseLoggingLevel.createFromExternalLevel(debugProperty);
        } else if ("false".equals(debugProperty)) {
            logDebug = false;
        } else {
            System.err.println("Unknown value for system property 'protex.sdk.debug=" + debugProperty
                    + "'. Expected 0, 1, 2, 3, or 4");
        }

        if (logDebug) {
            System.err.println("ServerUrl = " + serverUrl);
        }
        this.serverUrl = serverUrl;
        if (logDebug) {
            System.err.println("Authenticate with: " + userName + " :: " + getPasswordMask(password));
        }
        this.userName = userName;
        this.password = password;

    }

    /**
     * Constructor for a ProtexProxyServerv5_0 object
     * 
     * @param serverUrl
     *            The base URI for the Protex server, for example http://protex.example.com:80/
     * @param userName
     *            The user name to login to the Protex server, for example: test@example.com
     * @param password
     *            The users password
     * @param serverDefaultTimeout
     *            timeout in milliseconds, used for all get*Api calls that don't define their own timeout, use 0L to
     *            disable.
     * 
     *            Use on ServerProxy per server and per user.
     */
    public ProtexServerProxyV6_3(String serverUrl, String userName, String password, Long serverDefaultTimeout) {
        this(serverUrl, userName, password);
        setDefaultTimeout(serverDefaultTimeout);
    }

    /**
     * Gets the defautlTimeout for all get*Api calls that don't specify their own
     * 
     * @return the timeout in milliseconds
     */
    public Long getDefaultTimeout() {
        return defaultTimeout;
    }

    /**
     * Sets the defautlTimeout for all get*Api calls that don't specify their own
     * 
     * @param defaultTimeout
     *            the timeout in milliseconds
     */
    public void setDefaultTimeout(Long defaultTimeout) {
        this.defaultTimeout = defaultTimeout;
    }

    protected Map<String, Object> inProps = null;

    protected Map<String, Object> outProps = null;

    /**
     * Initialize the Authentication Properties, such as user and password
     * 
     * @param userName
     *            The user name to login to the Protex server, for example: test@example.com
     * @param password
     *            The users password
     */
    protected void initAuthProps(String userName, String password) {
        if (inProps == null) {
            inProps = new HashMap<String, Object>();
            // instrument service with authentication credentials
            inProps.put(WSHandlerConstants.ACTION, WSHandlerConstants.NO_SECURITY);
        }

        if (outProps == null) {
            outProps = new HashMap<String, Object>();
            outProps.put(WSHandlerConstants.ACTION, WSHandlerConstants.USERNAME_TOKEN);
            // Specify our username
            outProps.put(WSHandlerConstants.USER, userName);
            // Password type : plain text
            outProps.put(WSHandlerConstants.PASSWORD_TYPE, WSConstants.PW_TEXT);
            // Callback used to retrieve password for given user.
            outProps.put(WSHandlerConstants.PW_CALLBACK_REF, new ProgrammedPasswordCallback(userName, password));
            outProps.put(WSHandlerConstants.MUST_UNDERSTAND, "false");
        }
        if (logDebug) {
            System.out.println("Authenticate with: " + userName + " :: " + getPasswordMask(password));
        }
    }

    /**
     * Instrument the service port object with authentication information and the appropriate handlers
     * 
     * @param serviceApi
     *            The service port Object
     * @param userName
     *            The user name to login to the Protex server, for example: test@example.com
     * @param password
     *            The users password
     * @param timeout
     *            Optional http timeout in milliseconds, if INDEFINITE_TIMEOUT (zero) the timeout is indefinite, if
     *            null the default timeout is used
     */
    protected void instrumentService(Object serviceApi, String userName, String password, Long timeout) {
        if (logDebug) {
            System.out.println("instrument service: " + serviceApi.toString());
        }
        initAuthProps(userName, password);

        org.apache.cxf.endpoint.Client client = org.apache.cxf.frontend.ClientProxy.getClient(serviceApi);
        org.apache.cxf.endpoint.Endpoint cxfEndpoint = client.getEndpoint();

        WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(outProps);
        cxfEndpoint.getOutInterceptors().add(wssOut);
        if (logDebug) {
            AbstractPhaseInterceptor<Message> inInterceptor = null;
            AbstractPhaseInterceptor<Message> outInterceptor = null;
            AbstractPhaseInterceptor<Message> faultInterceptor = null;
            if (wsseLoggingLevel == WsseLoggingLevel.COMPACT) {
                inInterceptor = new WSSEStrippedLoggingInInterceptor();
                faultInterceptor = new WSSEStrippedLoggingInInterceptor();
                outInterceptor = new WSSEStrippedLoggingOutInterceptor();
            } else if (wsseLoggingLevel == WsseLoggingLevel.COMPACT_PRETTY) {
                inInterceptor = new WSSEStrippedPrettyLoggingInInterceptor();
                faultInterceptor = new WSSEStrippedPrettyLoggingInInterceptor();
                outInterceptor = new WSSEStrippedPrettyLoggingOutInterceptor();
            } else if (wsseLoggingLevel == WsseLoggingLevel.VERBOSE) {
                inInterceptor = new PrettyLoggingInInterceptor();
                faultInterceptor = new PrettyLoggingInInterceptor();
                outInterceptor = new PrettyLoggingOutInterceptor();
            } else if (wsseLoggingLevel == WsseLoggingLevel.VERBOSE_SECURE) {
                inInterceptor = new WSSEPasswordMaskedLoggingInInterceptor();
                faultInterceptor = new WSSEPasswordMaskedLoggingInInterceptor();
                outInterceptor = new WSSEPasswordMaskedLoggingOutInterceptor();
            } else if (wsseLoggingLevel == WsseLoggingLevel.VERBOSE_SECURE_PRETTY) {
                inInterceptor = new WSSEPasswordMaskedPrettyLoggingInInterceptor();
                faultInterceptor = new WSSEPasswordMaskedPrettyLoggingInInterceptor();
                outInterceptor = new WSSEPasswordMaskedPrettyLoggingOutInterceptor();
            }
            cxfEndpoint.getInInterceptors().add(inInterceptor);
            cxfEndpoint.getInInterceptors().add(faultInterceptor);

            cxfEndpoint.getOutInterceptors().add(outInterceptor);
        }

        /* set timeout */
        if (timeout != null) {
            setTimeout(serviceApi, timeout);
        }

        /*
         * ONLY FOR DEVELOPMENT - uncomment if you are working with a non exact match on the hostname in the SSL
         * Certificate - NOT RECOMMENDED FOR PRODUCTION USE
         */
        // HTTPConduit http = (HTTPConduit) client.getConduit();
        //
        // TLSClientParameters tlsClientParameters = new TLSClientParameters();
        // tlsClientParameters.setDisableCNCheck(true);
        // http.setTlsClientParameters(tlsClientParameters);
    }

    /**
     * Get the current Http timeout value for a service port
     * 
     * @param serviceApi
     *            The object representing the serviceApiPort
     * @return the timeout in Milliseconds
     */
    private Long getTimeout(Object serviceApi) {
        if (logDebug) {
            System.out.println("get timeout for service: " + serviceApi.toString());
        }
        org.apache.cxf.endpoint.Client client = org.apache.cxf.frontend.ClientProxy.getClient(serviceApi);
        /* get timeout */
        HTTPConduit http = (HTTPConduit) client.getConduit();

        HTTPClientPolicy httpClientPolicy = http.getClient();
        return httpClientPolicy.getConnectionTimeout();
    }

    /**
     * Set the Http timeout value for a service port
     * 
     * @param serviceApi
     *            The object representing the serviceApiPort
     * @param timeout
     *            The timeout in Milliseconds
     * 
     */
    private void setTimeout(Object serviceApi, Long timeout) {
        if (logDebug) {
            System.out.println("set timeout for service: " + serviceApi.toString());
        }
        org.apache.cxf.endpoint.Client client = org.apache.cxf.frontend.ClientProxy.getClient(serviceApi);
        /* set timeout */
        HTTPConduit http = (HTTPConduit) client.getConduit();

        HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
        httpClientPolicy.setConnectionTimeout(timeout.longValue());
        httpClientPolicy.setReceiveTimeout(timeout.longValue());

        http.setClient(httpClientPolicy);
    }

    /**
     * Validates the configured User Credentials
     * 
     * @throws RuntimeException
     *             if anything unusual happens
     * @throws ServerAuthenticationException
     *             if the credentials fail to authenticate
     */
    public void validateCredentials() throws RuntimeException, ServerAuthenticationException {
        try {
            // call the cheapest method possible on the server, as every call is sent with the credentials (according to
            // WS-I Basic profile compliance)
            getRoleApi().getRoleByName(RoleName.DEVELOPER);
        } catch (SdkFault e) {
            throw new RuntimeException(e.getMessage(), e);
        } catch (SOAPFaultException e) {
            throw new ServerAuthenticationException("Validating credentials for '" + userName + "' failed", e);
        }
    }

    /* === APIs === */

    /**
     * Get the licenseApi object with default http timeouts
     * 
     * @return The licenseApi port object
     */
    public LicenseApi getLicenseApi() {
        return this.getLicenseApi(defaultTimeout);
    }

    /**
     * Get the licenseApi object with custom http timeouts
     * 
     * @param timeout
     *            the timeout in Milliseconds
     * @return The licenseApi port object
     */
    public LicenseApi getLicenseApi(Long timeout) {
        if (licenseApi == null) {
            licenseApi = (LicenseApi) getPortFromUrl(LicenseApi.class, serverUrl + LICENSE_API_SERVICE_STUB);

            instrumentService(licenseApi, userName, password, timeout);
        } else {
            Long serviceTimeout = getTimeout(licenseApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(licenseApi, timeout);
            }
        }
        return licenseApi;
    }

    public CustomComponentApi getCustomComponentApi() {
        return getCustomComponentApi(defaultTimeout);
    }

    public CustomComponentApi getCustomComponentApi(Long timeout) {
        if (customComponentApi == null) {
            customComponentApi = (CustomComponentApi) getPortFromUrl(CustomComponentApi.class, serverUrl
                    + CUSTOM_COMPONENT_API_SERVICE_STUB);

            instrumentService(customComponentApi, userName, password, timeout);

        } else {
            Long serviceTimeout = getTimeout(customComponentApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(customComponentApi, timeout);
            }
        }
        return customComponentApi;
    }

    public StandardComponentApi getStandardComponentApi() {
        return getStandardComponentApi(defaultTimeout);
    }

    public StandardComponentApi getStandardComponentApi(Long timeout) {
        if (standardComponentApi == null) {
            standardComponentApi = (StandardComponentApi) getPortFromUrl(StandardComponentApi.class, serverUrl
                    + STANDARD_COMPONENT_API_SERVICE_STUB);

            instrumentService(standardComponentApi, userName, password, timeout);

        } else {
            Long serviceTimeout = getTimeout(standardComponentApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(standardComponentApi, timeout);
            }
        }
        return standardComponentApi;
    }

    public LocalComponentApi getLocalComponentApi() {
        return getLocalComponentApi(defaultTimeout);
    }

    public LocalComponentApi getLocalComponentApi(Long timeout) {
        if (localComponentApi == null) {
            localComponentApi = (LocalComponentApi) getPortFromUrl(LocalComponentApi.class, serverUrl
                    + LOCAL_COMPONENT_API_SERVICE_STUB);

            instrumentService(localComponentApi, userName, password, timeout);

        } else {
            Long serviceTimeout = getTimeout(localComponentApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(localComponentApi, timeout);
            }
        }
        return localComponentApi;
    }

    public ComponentVersionApi getComponentVersionApi() {
        return getComponentVersionApi(defaultTimeout);
    }

    public ComponentVersionApi getComponentVersionApi(Long timeout) {
        if (componentVersionApi == null) {
            componentVersionApi = (ComponentVersionApi) getPortFromUrl(ComponentVersionApi.class, serverUrl
                    + COMPONENT_VERSION_API_SERVICE_STUB);

            instrumentService(componentVersionApi, userName, password, timeout);

        } else {
            Long serviceTimeout = getTimeout(componentVersionApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(componentVersionApi, timeout);
            }
        }
        return componentVersionApi;
    }

    public ObligationApi getObligationApi() {
        return getObligationApi(defaultTimeout);
    }

    public ObligationApi getObligationApi(Long timeout) {
        if (obligationApi == null) {
            obligationApi = (ObligationApi) getPortFromUrl(ObligationApi.class, serverUrl + OBLIGATION_API_SERVICE_STUB);

            instrumentService(obligationApi, userName, password, timeout);

        } else {
            Long serviceTimeout = getTimeout(obligationApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(obligationApi, timeout);
            }
        }
        return obligationApi;
    }

    public PolicyApi getPolicyApi() {
        return getPolicyApi(defaultTimeout);
    }

    public PolicyApi getPolicyApi(Long timeout) {
        if (policyApi == null) {
            policyApi = (PolicyApi) getPortFromUrl(PolicyApi.class, serverUrl + POLICY_API_SERVICE_STUB);

            instrumentService(policyApi, userName, password, timeout);

        } else {
            Long serviceTimeout = getTimeout(policyApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(policyApi, timeout);
            }
        }
        return policyApi;
    }

    public ExternalIdApi getExternalIdApi() {
        return getExternalIdApi(defaultTimeout);
    }

    public ExternalIdApi getExternalIdApi(Long timeout) {
        if (externalIdApi == null) {
            externalIdApi = (ExternalIdApi) getPortFromUrl(ExternalIdApi.class, serverUrl + EXTERNAL_ID_API_SERVICE_STUB);

            instrumentService(externalIdApi, userName, password, timeout);

        } else {
            Long serviceTimeout = getTimeout(externalIdApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(externalIdApi, timeout);
            }
        }
        return externalIdApi;
    }

    public FileComparisonApi getFileComparisonApi() {
        return getFileComparisonApi(defaultTimeout);
    }

    public FileComparisonApi getFileComparisonApi(Long timeout) {
        if (fileComparisonApi == null) {
            fileComparisonApi = (FileComparisonApi) getPortFromUrl(FileComparisonApi.class, serverUrl
                    + FILE_COMPOARISON_API_SERVICE_STUB);

            instrumentService(fileComparisonApi, userName, password, timeout);

        } else {
            Long serviceTimeout = getTimeout(fileComparisonApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(fileComparisonApi, timeout);
            }
        }
        return fileComparisonApi;
    }

    public ProjectApi getProjectApi() {
        return getProjectApi(defaultTimeout);
    }

    public ProjectApi getProjectApi(Long timeout) {
        if (projectApi == null) {
            projectApi = (ProjectApi) getPortFromUrl(ProjectApi.class, serverUrl + PROJECT_API_SERVICE_STUB);

            instrumentService(projectApi, userName, password, timeout);

        } else {
            Long serviceTimeout = getTimeout(projectApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(projectApi, timeout);
            }
        }
        return projectApi;
    }

    public BomApi getBomApi() {
        return getBomApi(defaultTimeout);
    }

    public BomApi getBomApi(Long timeout) {
        if (bomApi == null) {
            bomApi = (BomApi) getPortFromUrl(BomApi.class, serverUrl + BOM_API_SERVICE_STUB);

            instrumentService(bomApi, userName, password, timeout);
        } else {
            Long serviceTimeout = getTimeout(bomApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(bomApi, timeout);
            }
        }
        return bomApi;
    }

    public CodeTreeApi getCodeTreeApi() {
        return getCodeTreeApi(defaultTimeout);
    }

    public CodeTreeApi getCodeTreeApi(Long timeout) {
        if (codeTreeApi == null) {
            codeTreeApi = (CodeTreeApi) getPortFromUrl(CodeTreeApi.class, serverUrl + CODE_TREE_API_SERVICE_STUB);

            instrumentService(codeTreeApi, userName, password, timeout);
        } else {
            Long serviceTimeout = getTimeout(codeTreeApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(codeTreeApi, timeout);
            }
        }
        return codeTreeApi;
    }

    public DiscoveryApi getDiscoveryApi() {
        return getDiscoveryApi(defaultTimeout);
    }

    public DiscoveryApi getDiscoveryApi(Long timeout) {
        if (discoveryApi == null) {
            discoveryApi = (DiscoveryApi) getPortFromUrl(DiscoveryApi.class, serverUrl + DISCOVERY_API_SERVICE_STUB);

            instrumentService(discoveryApi, userName, password, timeout);
        } else {
            Long serviceTimeout = getTimeout(discoveryApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(discoveryApi, timeout);
            }
        }
        return discoveryApi;
    }

    public IdentificationApi getIdentificationApi() {
        return getIdentificationApi(defaultTimeout);
    }

    public IdentificationApi getIdentificationApi(Long timeout) {
        if (identificationApi == null) {
            identificationApi = (IdentificationApi) getPortFromUrl(IdentificationApi.class, serverUrl
                    + IDENTIFICATION_API_SERVICE_STUB);

            instrumentService(identificationApi, userName, password, timeout);
        } else {
            Long serviceTimeout = getTimeout(identificationApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(identificationApi, timeout);
            }
        }
        return identificationApi;
    }

    public ReportApi getReportApi() {
        return getReportApi(defaultTimeout);
    }

    public ReportApi getReportApi(Long timeout) {
        if (reportApi == null) {
            reportApi = (ReportApi) getPortFromUrl(ReportApi.class, serverUrl + REPORT_API_SERVICE_STUB);

            instrumentService(reportApi, userName, password, timeout);
        } else {
            Long serviceTimeout = getTimeout(reportApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(reportApi, timeout);
            }
        }
        return reportApi;
    }

    public RoleApi getRoleApi() {
        return getRoleApi(defaultTimeout);
    }

    public RoleApi getRoleApi(Long timeout) {
        if (roleApi == null) {
            roleApi = (RoleApi) getPortFromUrl(RoleApi.class, serverUrl + ROLE_API_SERVICE_STUB);

            instrumentService(roleApi, userName, password, timeout);
        } else {
            Long serviceTimeout = getTimeout(roleApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(roleApi, timeout);
            }
        }
        return roleApi;
    }

    public UserApi getUserApi() {
        return getUserApi(defaultTimeout);
    }

    public UserApi getUserApi(Long timeout) {
        if (userApi == null) {
            userApi = (UserApi) getPortFromUrl(UserApi.class, serverUrl + USER_API_SERVICE_STUB);

            instrumentService(userApi, userName, password, timeout);
        } else {
            Long serviceTimeout = getTimeout(userApi);
            if ((timeout != null) && !timeout.equals(serviceTimeout)) {
                setTimeout(userApi, timeout);
            }
        }
        return userApi;
    }

    @SuppressWarnings({ "rawtypes" })
    private Object getPortFromUrl(Class serviceClass, String serviceUrl) {
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
        factory.setServiceClass(serviceClass);
        factory.setAddress(serviceUrl);
        if (logDebug) {
            System.out.println("getPortFromUrl: ServiceUrl = " + serviceUrl);
        }
        return factory.create();
    }

    protected String getPasswordMask(String password) {
        char[] mask = new char[password.length()];
        Arrays.fill(mask, '*');
        return new String(mask);
    }

}
