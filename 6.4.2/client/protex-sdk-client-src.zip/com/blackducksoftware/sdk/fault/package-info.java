@javax.xml.bind.annotation.XmlSchema(namespace = "urn:blackducksoftware.com:sdk:v6.3:fault")
package com.blackducksoftware.sdk.fault;
