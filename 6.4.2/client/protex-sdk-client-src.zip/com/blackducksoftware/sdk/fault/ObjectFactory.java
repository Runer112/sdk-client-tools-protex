
package com.blackducksoftware.sdk.fault;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.blackducksoftware.sdk.fault package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SdkFaultDetails_QNAME = new QName("urn:blackducksoftware.com:sdk:v6.3:fault", "sdkFaultDetails");
    private final static QName _SdkFault_QNAME = new QName("urn:blackducksoftware.com:sdk:v6.3:fault", "SdkFault");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.blackducksoftware.sdk.fault
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SdkFaultDetails }
     * 
     */
    public SdkFaultDetails createSdkFaultDetails() {
        return new SdkFaultDetails();
    }

    /**
     * Create an instance of {@link SdkError }
     * 
     */
    public SdkError createSdkError() {
        return new SdkError();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SdkFaultDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:blackducksoftware.com:sdk:v6.3:fault", name = "sdkFaultDetails")
    public JAXBElement<SdkFaultDetails> createSdkFaultDetails(SdkFaultDetails value) {
        return new JAXBElement<SdkFaultDetails>(_SdkFaultDetails_QNAME, SdkFaultDetails.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SdkFaultDetails }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:blackducksoftware.com:sdk:v6.3:fault", name = "SdkFault")
    public JAXBElement<SdkFaultDetails> createSdkFault(SdkFaultDetails value) {
        return new JAXBElement<SdkFaultDetails>(_SdkFault_QNAME, SdkFaultDetails.class, null, value);
    }

}
