
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for componentInfoPageFilter complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="componentInfoPageFilter">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v6.3:common}pageFilter">
 *       &lt;sequence>
 *         &lt;element name="sortedColumn" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}componentInfoColumn" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "componentInfoPageFilter", propOrder = {
    "sortedColumn"
})
public class ComponentInfoPageFilter
    extends PageFilter
{

    protected ComponentInfoColumn sortedColumn;

    /**
     * Gets the value of the sortedColumn property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentInfoColumn }
     *     
     */
    public ComponentInfoColumn getSortedColumn() {
        return sortedColumn;
    }

    /**
     * Sets the value of the sortedColumn property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentInfoColumn }
     *     
     */
    public void setSortedColumn(ComponentInfoColumn value) {
        this.sortedColumn = value;
    }

}
