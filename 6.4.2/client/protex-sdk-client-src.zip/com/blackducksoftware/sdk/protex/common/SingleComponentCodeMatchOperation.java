
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for singleComponentCodeMatchOperation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="singleComponentCodeMatchOperation">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v6.3:common}rapidIdOperation">
 *       &lt;sequence>
 *         &lt;element name="componentVersionPreference" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}componentVersionPreference" minOccurs="0"/>
 *         &lt;element name="minimumMatchPercentage" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "singleComponentCodeMatchOperation", propOrder = {
    "componentVersionPreference",
    "minimumMatchPercentage"
})
public class SingleComponentCodeMatchOperation
    extends RapidIdOperation
{

    protected ComponentVersionPreference componentVersionPreference;
    protected Integer minimumMatchPercentage;

    /**
     * Gets the value of the componentVersionPreference property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentVersionPreference }
     *     
     */
    public ComponentVersionPreference getComponentVersionPreference() {
        return componentVersionPreference;
    }

    /**
     * Sets the value of the componentVersionPreference property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentVersionPreference }
     *     
     */
    public void setComponentVersionPreference(ComponentVersionPreference value) {
        this.componentVersionPreference = value;
    }

    /**
     * Gets the value of the minimumMatchPercentage property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMinimumMatchPercentage() {
        return minimumMatchPercentage;
    }

    /**
     * Sets the value of the minimumMatchPercentage property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMinimumMatchPercentage(Integer value) {
        this.minimumMatchPercentage = value;
    }

}
