
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for rapidIdOperation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="rapidIdOperation">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="type" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}rapidIdOperationType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rapidIdOperation", propOrder = {
    "type"
})
@XmlSeeAlso({
    SingleComponentCodeMatchOperation.class,
    PrimaryMatchOperation.class,
    LearnedIdentificationOperation.class
})
public abstract class RapidIdOperation {

    protected RapidIdOperationType type;

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link RapidIdOperationType }
     *     
     */
    public RapidIdOperationType getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link RapidIdOperationType }
     *     
     */
    public void setType(RapidIdOperationType value) {
        this.type = value;
    }

}
