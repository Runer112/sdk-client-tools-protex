
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for fileDiscoveryPatternRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="fileDiscoveryPatternRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="binaryDependenciesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *         &lt;element name="decompressCompressedFilesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *         &lt;element name="defaultUsage" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}usageLevel" minOccurs="0"/>
 *         &lt;element name="expandArchivesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *         &lt;element name="fileMatchesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *         &lt;element name="fileType" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}fileType" minOccurs="0"/>
 *         &lt;element name="flagAsPendingIdentificationOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *         &lt;element name="generateTocForArchivesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *         &lt;element name="javaImportOrCIncludeDependenciesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *         &lt;element name="javaPackageStatementDependenciesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *         &lt;element name="pattern" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="snippetMatchesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *         &lt;element name="stringSearchesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *         &lt;element name="uploadSourceCodeOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}guardedBooleanOption" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "fileDiscoveryPatternRequest", propOrder = {
    "binaryDependenciesOption",
    "decompressCompressedFilesOption",
    "defaultUsage",
    "expandArchivesOption",
    "fileMatchesOption",
    "fileType",
    "flagAsPendingIdentificationOption",
    "generateTocForArchivesOption",
    "javaImportOrCIncludeDependenciesOption",
    "javaPackageStatementDependenciesOption",
    "pattern",
    "snippetMatchesOption",
    "stringSearchesOption",
    "uploadSourceCodeOption"
})
@XmlSeeAlso({
    FileDiscoveryPattern.class
})
public class FileDiscoveryPatternRequest {

    protected GuardedBooleanOption binaryDependenciesOption;
    protected GuardedBooleanOption decompressCompressedFilesOption;
    protected UsageLevel defaultUsage;
    protected GuardedBooleanOption expandArchivesOption;
    protected GuardedBooleanOption fileMatchesOption;
    protected FileType fileType;
    protected GuardedBooleanOption flagAsPendingIdentificationOption;
    protected GuardedBooleanOption generateTocForArchivesOption;
    protected GuardedBooleanOption javaImportOrCIncludeDependenciesOption;
    protected GuardedBooleanOption javaPackageStatementDependenciesOption;
    protected String pattern;
    protected GuardedBooleanOption snippetMatchesOption;
    protected GuardedBooleanOption stringSearchesOption;
    protected GuardedBooleanOption uploadSourceCodeOption;

    /**
     * Gets the value of the binaryDependenciesOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getBinaryDependenciesOption() {
        return binaryDependenciesOption;
    }

    /**
     * Sets the value of the binaryDependenciesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setBinaryDependenciesOption(GuardedBooleanOption value) {
        this.binaryDependenciesOption = value;
    }

    /**
     * Gets the value of the decompressCompressedFilesOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getDecompressCompressedFilesOption() {
        return decompressCompressedFilesOption;
    }

    /**
     * Sets the value of the decompressCompressedFilesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setDecompressCompressedFilesOption(GuardedBooleanOption value) {
        this.decompressCompressedFilesOption = value;
    }

    /**
     * Gets the value of the defaultUsage property.
     * 
     * @return
     *     possible object is
     *     {@link UsageLevel }
     *     
     */
    public UsageLevel getDefaultUsage() {
        return defaultUsage;
    }

    /**
     * Sets the value of the defaultUsage property.
     * 
     * @param value
     *     allowed object is
     *     {@link UsageLevel }
     *     
     */
    public void setDefaultUsage(UsageLevel value) {
        this.defaultUsage = value;
    }

    /**
     * Gets the value of the expandArchivesOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getExpandArchivesOption() {
        return expandArchivesOption;
    }

    /**
     * Sets the value of the expandArchivesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setExpandArchivesOption(GuardedBooleanOption value) {
        this.expandArchivesOption = value;
    }

    /**
     * Gets the value of the fileMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getFileMatchesOption() {
        return fileMatchesOption;
    }

    /**
     * Sets the value of the fileMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setFileMatchesOption(GuardedBooleanOption value) {
        this.fileMatchesOption = value;
    }

    /**
     * Gets the value of the fileType property.
     * 
     * @return
     *     possible object is
     *     {@link FileType }
     *     
     */
    public FileType getFileType() {
        return fileType;
    }

    /**
     * Sets the value of the fileType property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileType }
     *     
     */
    public void setFileType(FileType value) {
        this.fileType = value;
    }

    /**
     * Gets the value of the flagAsPendingIdentificationOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getFlagAsPendingIdentificationOption() {
        return flagAsPendingIdentificationOption;
    }

    /**
     * Sets the value of the flagAsPendingIdentificationOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setFlagAsPendingIdentificationOption(GuardedBooleanOption value) {
        this.flagAsPendingIdentificationOption = value;
    }

    /**
     * Gets the value of the generateTocForArchivesOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getGenerateTocForArchivesOption() {
        return generateTocForArchivesOption;
    }

    /**
     * Sets the value of the generateTocForArchivesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setGenerateTocForArchivesOption(GuardedBooleanOption value) {
        this.generateTocForArchivesOption = value;
    }

    /**
     * Gets the value of the javaImportOrCIncludeDependenciesOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getJavaImportOrCIncludeDependenciesOption() {
        return javaImportOrCIncludeDependenciesOption;
    }

    /**
     * Sets the value of the javaImportOrCIncludeDependenciesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setJavaImportOrCIncludeDependenciesOption(GuardedBooleanOption value) {
        this.javaImportOrCIncludeDependenciesOption = value;
    }

    /**
     * Gets the value of the javaPackageStatementDependenciesOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getJavaPackageStatementDependenciesOption() {
        return javaPackageStatementDependenciesOption;
    }

    /**
     * Sets the value of the javaPackageStatementDependenciesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setJavaPackageStatementDependenciesOption(GuardedBooleanOption value) {
        this.javaPackageStatementDependenciesOption = value;
    }

    /**
     * Gets the value of the pattern property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPattern() {
        return pattern;
    }

    /**
     * Sets the value of the pattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPattern(String value) {
        this.pattern = value;
    }

    /**
     * Gets the value of the snippetMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getSnippetMatchesOption() {
        return snippetMatchesOption;
    }

    /**
     * Sets the value of the snippetMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setSnippetMatchesOption(GuardedBooleanOption value) {
        this.snippetMatchesOption = value;
    }

    /**
     * Gets the value of the stringSearchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getStringSearchesOption() {
        return stringSearchesOption;
    }

    /**
     * Sets the value of the stringSearchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setStringSearchesOption(GuardedBooleanOption value) {
        this.stringSearchesOption = value;
    }

    /**
     * Gets the value of the uploadSourceCodeOption property.
     * 
     * @return
     *     possible object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public GuardedBooleanOption getUploadSourceCodeOption() {
        return uploadSourceCodeOption;
    }

    /**
     * Sets the value of the uploadSourceCodeOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link GuardedBooleanOption }
     *     
     */
    public void setUploadSourceCodeOption(GuardedBooleanOption value) {
        this.uploadSourceCodeOption = value;
    }

}
