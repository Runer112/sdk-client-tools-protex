
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.project.codetree.identification.CodeMatchIdentificationDirective;
import com.blackducksoftware.sdk.protex.project.codetree.identification.IdentificationType;


/**
 * <p>Java class for learnedCodeMatchIdentification complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="learnedCodeMatchIdentification">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v6.3:common}learnedIdentification">
 *       &lt;sequence>
 *         &lt;element name="codeMatchIdentificationDirective" type="{urn:protex.blackducksoftware.com:sdk:v6.3:identification}codeMatchIdentificationDirective" minOccurs="0"/>
 *         &lt;element name="discoveredComponentId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="discoveredVersionId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="firstLine" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="lastLine" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="path" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="type" type="{urn:protex.blackducksoftware.com:sdk:v6.3:identification}identificationType" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "learnedCodeMatchIdentification", propOrder = {
    "codeMatchIdentificationDirective",
    "discoveredComponentId",
    "discoveredVersionId",
    "firstLine",
    "lastLine",
    "path",
    "type"
})
public class LearnedCodeMatchIdentification
    extends LearnedIdentification
{

    protected CodeMatchIdentificationDirective codeMatchIdentificationDirective;
    protected String discoveredComponentId;
    protected String discoveredVersionId;
    protected Integer firstLine;
    protected Integer lastLine;
    protected String path;
    protected IdentificationType type;

    /**
     * Gets the value of the codeMatchIdentificationDirective property.
     * 
     * @return
     *     possible object is
     *     {@link CodeMatchIdentificationDirective }
     *     
     */
    public CodeMatchIdentificationDirective getCodeMatchIdentificationDirective() {
        return codeMatchIdentificationDirective;
    }

    /**
     * Sets the value of the codeMatchIdentificationDirective property.
     * 
     * @param value
     *     allowed object is
     *     {@link CodeMatchIdentificationDirective }
     *     
     */
    public void setCodeMatchIdentificationDirective(CodeMatchIdentificationDirective value) {
        this.codeMatchIdentificationDirective = value;
    }

    /**
     * Gets the value of the discoveredComponentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiscoveredComponentId() {
        return discoveredComponentId;
    }

    /**
     * Sets the value of the discoveredComponentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiscoveredComponentId(String value) {
        this.discoveredComponentId = value;
    }

    /**
     * Gets the value of the discoveredVersionId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDiscoveredVersionId() {
        return discoveredVersionId;
    }

    /**
     * Sets the value of the discoveredVersionId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDiscoveredVersionId(String value) {
        this.discoveredVersionId = value;
    }

    /**
     * Gets the value of the firstLine property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFirstLine() {
        return firstLine;
    }

    /**
     * Sets the value of the firstLine property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFirstLine(Integer value) {
        this.firstLine = value;
    }

    /**
     * Gets the value of the lastLine property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getLastLine() {
        return lastLine;
    }

    /**
     * Sets the value of the lastLine property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setLastLine(Integer value) {
        this.lastLine = value;
    }

    /**
     * Gets the value of the path property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPath() {
        return path;
    }

    /**
     * Sets the value of the path property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPath(String value) {
        this.path = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationType }
     *     
     */
    public IdentificationType getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationType }
     *     
     */
    public void setType(IdentificationType value) {
        this.type = value;
    }

}
