
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for codeLabelOption complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="codeLabelOption">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="furnishedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="openSourceReferenceLocation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "codeLabelOption", propOrder = {
    "furnishedBy",
    "openSourceReferenceLocation"
})
public class CodeLabelOption {

    protected String furnishedBy;
    protected String openSourceReferenceLocation;

    /**
     * Gets the value of the furnishedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFurnishedBy() {
        return furnishedBy;
    }

    /**
     * Sets the value of the furnishedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFurnishedBy(String value) {
        this.furnishedBy = value;
    }

    /**
     * Gets the value of the openSourceReferenceLocation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOpenSourceReferenceLocation() {
        return openSourceReferenceLocation;
    }

    /**
     * Sets the value of the openSourceReferenceLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOpenSourceReferenceLocation(String value) {
        this.openSourceReferenceLocation = value;
    }

}
