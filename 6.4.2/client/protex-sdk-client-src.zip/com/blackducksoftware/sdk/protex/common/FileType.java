
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for fileType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="fileType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="TEXT"/>
 *     &lt;enumeration value="BINARY"/>
 *     &lt;enumeration value="BINARY_JAVA_CLASS"/>
 *     &lt;enumeration value="BINARY_ELF"/>
 *     &lt;enumeration value="BINARY_MICROSOFT_DLL"/>
 *     &lt;enumeration value="BINARY_MICROSOFT_PORTABLE_EXECUTABLE"/>
 *     &lt;enumeration value="JAVA_SOURCE"/>
 *     &lt;enumeration value="C_SOURCE"/>
 *     &lt;enumeration value="ARCHIVE"/>
 *     &lt;enumeration value="ARCHIVE_TAR"/>
 *     &lt;enumeration value="ARCHIVE_JAR_WAR"/>
 *     &lt;enumeration value="ARCHIVE_ZIP"/>
 *     &lt;enumeration value="COMPRESSED_GZIP"/>
 *     &lt;enumeration value="COMPRESSED_BZIP2"/>
 *     &lt;enumeration value="OTHER"/>
 *     &lt;enumeration value="IGNORED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "fileType")
@XmlEnum
public enum FileType {

    TEXT("TEXT"),
    BINARY("BINARY"),
    BINARY_JAVA_CLASS("BINARY_JAVA_CLASS"),
    BINARY_ELF("BINARY_ELF"),
    BINARY_MICROSOFT_DLL("BINARY_MICROSOFT_DLL"),
    BINARY_MICROSOFT_PORTABLE_EXECUTABLE("BINARY_MICROSOFT_PORTABLE_EXECUTABLE"),
    JAVA_SOURCE("JAVA_SOURCE"),
    C_SOURCE("C_SOURCE"),
    ARCHIVE("ARCHIVE"),
    ARCHIVE_TAR("ARCHIVE_TAR"),
    ARCHIVE_JAR_WAR("ARCHIVE_JAR_WAR"),
    ARCHIVE_ZIP("ARCHIVE_ZIP"),
    COMPRESSED_GZIP("COMPRESSED_GZIP"),
    @XmlEnumValue("COMPRESSED_BZIP2")
    COMPRESSED_BZIP_2("COMPRESSED_BZIP2"),
    OTHER("OTHER"),
    IGNORED("IGNORED");
    private final String value;

    FileType(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static FileType fromValue(String v) {
        for (FileType c: FileType.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
