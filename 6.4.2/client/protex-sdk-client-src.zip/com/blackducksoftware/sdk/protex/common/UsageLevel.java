
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for usageLevel.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="usageLevel">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="FILE"/>
 *     &lt;enumeration value="SNIPPET"/>
 *     &lt;enumeration value="COMPONENT_MERELY_AGGREGATED"/>
 *     &lt;enumeration value="COMPONENT_DYNAMIC_LIBRARY"/>
 *     &lt;enumeration value="COMPONENT_SEPARATE_WORK"/>
 *     &lt;enumeration value="COMPONENT_MODULE"/>
 *     &lt;enumeration value="COMPONENT"/>
 *     &lt;enumeration value="PREREQUISITE"/>
 *     &lt;enumeration value="PREREQUISITE_SERVICE"/>
 *     &lt;enumeration value="PREREQUISITE_MERLY_AGGREGATED"/>
 *     &lt;enumeration value="PREREQUISITE_SEPARATE_WORK"/>
 *     &lt;enumeration value="PREREQUISITE_DYNAMIC_LIBRARY"/>
 *     &lt;enumeration value="PREREQUISITE_MODULE"/>
 *     &lt;enumeration value="IMPLEMENTATION_OF_STANDARD"/>
 *     &lt;enumeration value="DEVELOPMENT_TOOL"/>
 *     &lt;enumeration value="ORIGINAL_CODE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "usageLevel")
@XmlEnum
public enum UsageLevel {

    FILE,
    SNIPPET,
    COMPONENT_MERELY_AGGREGATED,
    COMPONENT_DYNAMIC_LIBRARY,
    COMPONENT_SEPARATE_WORK,
    COMPONENT_MODULE,
    COMPONENT,
    PREREQUISITE,
    PREREQUISITE_SERVICE,
    PREREQUISITE_MERLY_AGGREGATED,
    PREREQUISITE_SEPARATE_WORK,
    PREREQUISITE_DYNAMIC_LIBRARY,
    PREREQUISITE_MODULE,
    IMPLEMENTATION_OF_STANDARD,
    DEVELOPMENT_TOOL,
    ORIGINAL_CODE;

    public String value() {
        return name();
    }

    public static UsageLevel fromValue(String v) {
        return valueOf(v);
    }

}
