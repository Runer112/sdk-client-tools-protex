
package com.blackducksoftware.sdk.protex.common;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.blackducksoftware.sdk.protex.project.Adapter1;


/**
 * <p>Java class for analysisStatus complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="analysisStatus">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="analysisPendingBytes" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="analysisPendingFileCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="analysisPhase" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}analysisPhase" minOccurs="0"/>
 *         &lt;element name="analyzedBytes" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="analyzedFileCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="currentFile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="currentPhasePercentCompleted" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="elapsedTime" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="endTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="finished" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="startTime" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="startedBy" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="totalBytes" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *         &lt;element name="totalFileCount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "analysisStatus", propOrder = {
    "analysisPendingBytes",
    "analysisPendingFileCount",
    "analysisPhase",
    "analyzedBytes",
    "analyzedFileCount",
    "currentFile",
    "currentPhasePercentCompleted",
    "elapsedTime",
    "endTime",
    "finished",
    "startTime",
    "startedBy",
    "totalBytes",
    "totalFileCount"
})
public class AnalysisStatus {

    protected Long analysisPendingBytes;
    protected Integer analysisPendingFileCount;
    protected AnalysisPhase analysisPhase;
    protected Long analyzedBytes;
    protected Integer analyzedFileCount;
    protected String currentFile;
    protected Integer currentPhasePercentCompleted;
    protected Long elapsedTime;
    @XmlElement(type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date endTime;
    protected Boolean finished;
    @XmlElement(type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date startTime;
    protected String startedBy;
    protected Long totalBytes;
    protected Integer totalFileCount;

    /**
     * Gets the value of the analysisPendingBytes property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAnalysisPendingBytes() {
        return analysisPendingBytes;
    }

    /**
     * Sets the value of the analysisPendingBytes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAnalysisPendingBytes(Long value) {
        this.analysisPendingBytes = value;
    }

    /**
     * Gets the value of the analysisPendingFileCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAnalysisPendingFileCount() {
        return analysisPendingFileCount;
    }

    /**
     * Sets the value of the analysisPendingFileCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAnalysisPendingFileCount(Integer value) {
        this.analysisPendingFileCount = value;
    }

    /**
     * Gets the value of the analysisPhase property.
     * 
     * @return
     *     possible object is
     *     {@link AnalysisPhase }
     *     
     */
    public AnalysisPhase getAnalysisPhase() {
        return analysisPhase;
    }

    /**
     * Sets the value of the analysisPhase property.
     * 
     * @param value
     *     allowed object is
     *     {@link AnalysisPhase }
     *     
     */
    public void setAnalysisPhase(AnalysisPhase value) {
        this.analysisPhase = value;
    }

    /**
     * Gets the value of the analyzedBytes property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getAnalyzedBytes() {
        return analyzedBytes;
    }

    /**
     * Sets the value of the analyzedBytes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setAnalyzedBytes(Long value) {
        this.analyzedBytes = value;
    }

    /**
     * Gets the value of the analyzedFileCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getAnalyzedFileCount() {
        return analyzedFileCount;
    }

    /**
     * Sets the value of the analyzedFileCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setAnalyzedFileCount(Integer value) {
        this.analyzedFileCount = value;
    }

    /**
     * Gets the value of the currentFile property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrentFile() {
        return currentFile;
    }

    /**
     * Sets the value of the currentFile property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrentFile(String value) {
        this.currentFile = value;
    }

    /**
     * Gets the value of the currentPhasePercentCompleted property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCurrentPhasePercentCompleted() {
        return currentPhasePercentCompleted;
    }

    /**
     * Sets the value of the currentPhasePercentCompleted property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCurrentPhasePercentCompleted(Integer value) {
        this.currentPhasePercentCompleted = value;
    }

    /**
     * Gets the value of the elapsedTime property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getElapsedTime() {
        return elapsedTime;
    }

    /**
     * Sets the value of the elapsedTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setElapsedTime(Long value) {
        this.elapsedTime = value;
    }

    /**
     * Gets the value of the endTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * Sets the value of the endTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndTime(Date value) {
        this.endTime = value;
    }

    /**
     * Gets the value of the finished property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFinished() {
        return finished;
    }

    /**
     * Sets the value of the finished property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFinished(Boolean value) {
        this.finished = value;
    }

    /**
     * Gets the value of the startTime property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getStartTime() {
        return startTime;
    }

    /**
     * Sets the value of the startTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartTime(Date value) {
        this.startTime = value;
    }

    /**
     * Gets the value of the startedBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartedBy() {
        return startedBy;
    }

    /**
     * Sets the value of the startedBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartedBy(String value) {
        this.startedBy = value;
    }

    /**
     * Gets the value of the totalBytes property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getTotalBytes() {
        return totalBytes;
    }

    /**
     * Sets the value of the totalBytes property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setTotalBytes(Long value) {
        this.totalBytes = value;
    }

    /**
     * Gets the value of the totalFileCount property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getTotalFileCount() {
        return totalFileCount;
    }

    /**
     * Sets the value of the totalFileCount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setTotalFileCount(Integer value) {
        this.totalFileCount = value;
    }

}
