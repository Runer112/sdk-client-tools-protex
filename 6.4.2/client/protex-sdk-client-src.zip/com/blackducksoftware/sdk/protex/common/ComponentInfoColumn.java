
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for componentInfoColumn.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="componentInfoColumn">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="COMPONENT_ID"/>
 *     &lt;enumeration value="COMPONENT_NAME"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "componentInfoColumn")
@XmlEnum
public enum ComponentInfoColumn {

    COMPONENT_ID,
    COMPONENT_NAME;

    public String value() {
        return name();
    }

    public static ComponentInfoColumn fromValue(String v) {
        return valueOf(v);
    }

}
