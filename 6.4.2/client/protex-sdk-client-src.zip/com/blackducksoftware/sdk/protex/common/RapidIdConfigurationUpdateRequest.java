
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for rapidIdConfigurationUpdateRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="rapidIdConfigurationUpdateRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v6.3:common}rapidIdConfigurationRequest">
 *       &lt;sequence>
 *         &lt;element name="configurationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rapidIdConfigurationUpdateRequest", propOrder = {
    "configurationId"
})
@XmlSeeAlso({
    RapidIdConfiguration.class
})
public class RapidIdConfigurationUpdateRequest
    extends RapidIdConfigurationRequest
{

    protected Long configurationId;

    /**
     * Gets the value of the configurationId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getConfigurationId() {
        return configurationId;
    }

    /**
     * Sets the value of the configurationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setConfigurationId(Long value) {
        this.configurationId = value;
    }

}
