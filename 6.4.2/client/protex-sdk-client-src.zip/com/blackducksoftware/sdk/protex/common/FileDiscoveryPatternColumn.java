
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for fileDiscoveryPatternColumn.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="fileDiscoveryPatternColumn">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PATTERN"/>
 *     &lt;enumeration value="FILE_TYPE"/>
 *     &lt;enumeration value="SNIPPET_MATCHES_OPTION"/>
 *     &lt;enumeration value="FILE_MATCHES_OPTION"/>
 *     &lt;enumeration value="STRING_SEARCHES_OPTION"/>
 *     &lt;enumeration value="JAVA_IMPORTS_OR_C_INCLUDE_DEPENDENCIES_OPTION"/>
 *     &lt;enumeration value="BINARY_DEPENDENCIES_OPTION"/>
 *     &lt;enumeration value="DECOMPRESS_COMPRESSED_FILES_OPTION"/>
 *     &lt;enumeration value="EXPAND_ARCHIVES_OPTION"/>
 *     &lt;enumeration value="FLAG_AS_PENDING_ID_OPTION"/>
 *     &lt;enumeration value="UPLOAD_SOURCE_CODE_OPTION"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "fileDiscoveryPatternColumn")
@XmlEnum
public enum FileDiscoveryPatternColumn {

    PATTERN,
    FILE_TYPE,
    SNIPPET_MATCHES_OPTION,
    FILE_MATCHES_OPTION,
    STRING_SEARCHES_OPTION,
    JAVA_IMPORTS_OR_C_INCLUDE_DEPENDENCIES_OPTION,
    BINARY_DEPENDENCIES_OPTION,
    DECOMPRESS_COMPRESSED_FILES_OPTION,
    EXPAND_ARCHIVES_OPTION,
    FLAG_AS_PENDING_ID_OPTION,
    UPLOAD_SOURCE_CODE_OPTION;

    public String value() {
        return name();
    }

    public static FileDiscoveryPatternColumn fromValue(String v) {
        return valueOf(v);
    }

}
