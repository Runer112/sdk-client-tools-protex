
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for expandArchivesOption.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="expandArchivesOption">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="EXPAND_NONE"/>
 *     &lt;enumeration value="EXPAND_ALL"/>
 *     &lt;enumeration value="EXPAND_UNMATCHED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "expandArchivesOption")
@XmlEnum
public enum ExpandArchivesOption {

    EXPAND_NONE,
    EXPAND_ALL,
    EXPAND_UNMATCHED;

    public String value() {
        return name();
    }

    public static ExpandArchivesOption fromValue(String v) {
        return valueOf(v);
    }

}
