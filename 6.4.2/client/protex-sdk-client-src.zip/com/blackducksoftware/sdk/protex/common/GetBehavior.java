
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getBehavior.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="getBehavior">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CONTINUE_IF_NOT_FOUND"/>
 *     &lt;enumeration value="ERROR_IF_NOT_FOUND"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "getBehavior")
@XmlEnum
public enum GetBehavior {

    CONTINUE_IF_NOT_FOUND,
    ERROR_IF_NOT_FOUND;

    public String value() {
        return name();
    }

    public static GetBehavior fromValue(String v) {
        return valueOf(v);
    }

}
