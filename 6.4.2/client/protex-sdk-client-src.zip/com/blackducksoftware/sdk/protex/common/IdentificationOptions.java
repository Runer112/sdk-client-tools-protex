
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for identificationOptions complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="identificationOptions">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="auditTrailOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="requireIdOfCodeMatchesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="requireIdOfDependenciesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}forcibleBooleanOption" minOccurs="0"/>
 *         &lt;element name="requireIdOfFileDiscoveryPatternMatchesOption" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}forcibleBooleanOption" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "identificationOptions", propOrder = {
    "auditTrailOption",
    "requireIdOfCodeMatchesOption",
    "requireIdOfDependenciesOption",
    "requireIdOfFileDiscoveryPatternMatchesOption"
})
public class IdentificationOptions {

    protected ForcibleBooleanOption auditTrailOption;
    protected ForcibleBooleanOption requireIdOfCodeMatchesOption;
    protected ForcibleBooleanOption requireIdOfDependenciesOption;
    protected ForcibleBooleanOption requireIdOfFileDiscoveryPatternMatchesOption;

    /**
     * Gets the value of the auditTrailOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getAuditTrailOption() {
        return auditTrailOption;
    }

    /**
     * Sets the value of the auditTrailOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setAuditTrailOption(ForcibleBooleanOption value) {
        this.auditTrailOption = value;
    }

    /**
     * Gets the value of the requireIdOfCodeMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getRequireIdOfCodeMatchesOption() {
        return requireIdOfCodeMatchesOption;
    }

    /**
     * Sets the value of the requireIdOfCodeMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setRequireIdOfCodeMatchesOption(ForcibleBooleanOption value) {
        this.requireIdOfCodeMatchesOption = value;
    }

    /**
     * Gets the value of the requireIdOfDependenciesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getRequireIdOfDependenciesOption() {
        return requireIdOfDependenciesOption;
    }

    /**
     * Sets the value of the requireIdOfDependenciesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setRequireIdOfDependenciesOption(ForcibleBooleanOption value) {
        this.requireIdOfDependenciesOption = value;
    }

    /**
     * Gets the value of the requireIdOfFileDiscoveryPatternMatchesOption property.
     * 
     * @return
     *     possible object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public ForcibleBooleanOption getRequireIdOfFileDiscoveryPatternMatchesOption() {
        return requireIdOfFileDiscoveryPatternMatchesOption;
    }

    /**
     * Sets the value of the requireIdOfFileDiscoveryPatternMatchesOption property.
     * 
     * @param value
     *     allowed object is
     *     {@link ForcibleBooleanOption }
     *     
     */
    public void setRequireIdOfFileDiscoveryPatternMatchesOption(ForcibleBooleanOption value) {
        this.requireIdOfFileDiscoveryPatternMatchesOption = value;
    }

}
