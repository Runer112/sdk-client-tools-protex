
package com.blackducksoftware.sdk.protex.common;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for patternOriginType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="patternOriginType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="STANDARD"/>
 *     &lt;enumeration value="GLOBAL_CUSTOM"/>
 *     &lt;enumeration value="MODIFIED"/>
 *     &lt;enumeration value="LOCAL_CUSTOM"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "patternOriginType")
@XmlEnum
public enum PatternOriginType {

    STANDARD,
    GLOBAL_CUSTOM,
    MODIFIED,
    LOCAL_CUSTOM;

    public String value() {
        return name();
    }

    public static PatternOriginType fromValue(String v) {
        return valueOf(v);
    }

}
