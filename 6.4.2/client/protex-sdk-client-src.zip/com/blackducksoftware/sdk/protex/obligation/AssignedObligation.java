
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for assignedObligation complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="assignedObligation">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v6.3:obligation}obligationUpdateRequest">
 *       &lt;sequence>
 *         &lt;element name="fulfilled" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="fulfillmentInherited" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="originObjectId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="originType" type="{urn:protex.blackducksoftware.com:sdk:v6.3:obligation}obligationOriginType" minOccurs="0"/>
 *         &lt;element name="reviewAndReport" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="reviewAndReportInherited" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "assignedObligation", propOrder = {
    "fulfilled",
    "fulfillmentInherited",
    "originObjectId",
    "originType",
    "reviewAndReport",
    "reviewAndReportInherited"
})
public class AssignedObligation
    extends ObligationUpdateRequest
{

    protected Boolean fulfilled;
    protected Boolean fulfillmentInherited;
    protected String originObjectId;
    protected ObligationOriginType originType;
    protected Boolean reviewAndReport;
    protected Boolean reviewAndReportInherited;

    /**
     * Gets the value of the fulfilled property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFulfilled() {
        return fulfilled;
    }

    /**
     * Sets the value of the fulfilled property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFulfilled(Boolean value) {
        this.fulfilled = value;
    }

    /**
     * Gets the value of the fulfillmentInherited property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isFulfillmentInherited() {
        return fulfillmentInherited;
    }

    /**
     * Sets the value of the fulfillmentInherited property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setFulfillmentInherited(Boolean value) {
        this.fulfillmentInherited = value;
    }

    /**
     * Gets the value of the originObjectId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginObjectId() {
        return originObjectId;
    }

    /**
     * Sets the value of the originObjectId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginObjectId(String value) {
        this.originObjectId = value;
    }

    /**
     * Gets the value of the originType property.
     * 
     * @return
     *     possible object is
     *     {@link ObligationOriginType }
     *     
     */
    public ObligationOriginType getOriginType() {
        return originType;
    }

    /**
     * Sets the value of the originType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObligationOriginType }
     *     
     */
    public void setOriginType(ObligationOriginType value) {
        this.originType = value;
    }

    /**
     * Gets the value of the reviewAndReport property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReviewAndReport() {
        return reviewAndReport;
    }

    /**
     * Sets the value of the reviewAndReport property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReviewAndReport(Boolean value) {
        this.reviewAndReport = value;
    }

    /**
     * Gets the value of the reviewAndReportInherited property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isReviewAndReportInherited() {
        return reviewAndReportInherited;
    }

    /**
     * Sets the value of the reviewAndReportInherited property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setReviewAndReportInherited(Boolean value) {
        this.reviewAndReportInherited = value;
    }

}
