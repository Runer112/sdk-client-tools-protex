
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateObligationCategory complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateObligationCategory">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="obligationCategoryUpdateRequest" type="{urn:protex.blackducksoftware.com:sdk:v6.3:obligation}obligationCategoryUpdateRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateObligationCategory", propOrder = {
    "obligationCategoryUpdateRequest"
})
public class UpdateObligationCategory {

    protected ObligationCategoryUpdateRequest obligationCategoryUpdateRequest;

    /**
     * Gets the value of the obligationCategoryUpdateRequest property.
     * 
     * @return
     *     possible object is
     *     {@link ObligationCategoryUpdateRequest }
     *     
     */
    public ObligationCategoryUpdateRequest getObligationCategoryUpdateRequest() {
        return obligationCategoryUpdateRequest;
    }

    /**
     * Sets the value of the obligationCategoryUpdateRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObligationCategoryUpdateRequest }
     *     
     */
    public void setObligationCategoryUpdateRequest(ObligationCategoryUpdateRequest value) {
        this.obligationCategoryUpdateRequest = value;
    }

}
