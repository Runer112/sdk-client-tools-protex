
package com.blackducksoftware.sdk.protex.obligation;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for obligationCategoryUpdateRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="obligationCategoryUpdateRequest">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v6.3:obligation}obligationCategoryRequest">
 *       &lt;sequence>
 *         &lt;element name="obligationCategoryId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="resetFullfillmentOnClone" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "obligationCategoryUpdateRequest", propOrder = {
    "obligationCategoryId",
    "resetFullfillmentOnClone"
})
@XmlSeeAlso({
    ObligationCategory.class
})
public class ObligationCategoryUpdateRequest
    extends ObligationCategoryRequest
{

    protected String obligationCategoryId;
    protected Boolean resetFullfillmentOnClone;

    /**
     * Gets the value of the obligationCategoryId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getObligationCategoryId() {
        return obligationCategoryId;
    }

    /**
     * Sets the value of the obligationCategoryId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setObligationCategoryId(String value) {
        this.obligationCategoryId = value;
    }

    /**
     * Gets the value of the resetFullfillmentOnClone property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isResetFullfillmentOnClone() {
        return resetFullfillmentOnClone;
    }

    /**
     * Sets the value of the resetFullfillmentOnClone property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setResetFullfillmentOnClone(Boolean value) {
        this.resetFullfillmentOnClone = value;
    }

}
