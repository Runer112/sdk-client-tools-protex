@javax.xml.bind.annotation.XmlSchema(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:obligation")
package com.blackducksoftware.sdk.protex.obligation;
