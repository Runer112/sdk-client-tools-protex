@javax.xml.bind.annotation.XmlSchema(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:comparison")
package com.blackducksoftware.sdk.protex.comparison;
