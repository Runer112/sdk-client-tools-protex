
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for licenseExtensionLevel.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="licenseExtensionLevel">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="NON"/>
 *     &lt;enumeration value="FILE_PER_MPL"/>
 *     &lt;enumeration value="MODULE_PER_EPL_CPL"/>
 *     &lt;enumeration value="DYNAMIC_LIBRARY_PER_LGPL"/>
 *     &lt;enumeration value="WORK_BASED_ON_PER_GPL"/>
 *     &lt;enumeration value="ACCOMPANYING_SOFTWARE_USING_PER_SLEEPY_CAT"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "licenseExtensionLevel")
@XmlEnum
public enum LicenseExtensionLevel {

    NON,
    FILE_PER_MPL,
    MODULE_PER_EPL_CPL,
    DYNAMIC_LIBRARY_PER_LGPL,
    WORK_BASED_ON_PER_GPL,
    ACCOMPANYING_SOFTWARE_USING_PER_SLEEPY_CAT;

    public String value() {
        return name();
    }

    public static LicenseExtensionLevel fromValue(String v) {
        return valueOf(v);
    }

}
