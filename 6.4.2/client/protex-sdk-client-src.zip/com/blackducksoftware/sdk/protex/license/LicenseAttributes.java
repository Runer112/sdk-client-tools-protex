
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for licenseAttributes complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="licenseAttributes">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="antiDrmProvision" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="carriesDistributionObligations" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="changeNoticeRequired" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="chargingFees" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}permittedOrRequired" minOccurs="0"/>
 *         &lt;element name="discriminatoryRestrictions" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}restrictionType" minOccurs="0"/>
 *         &lt;element name="expressPatentLicense" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="grantRecipientRightToCopy" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}permittedOrRequired" minOccurs="0"/>
 *         &lt;element name="grantRecipientRightToModify" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}permittedOrRequired" minOccurs="0"/>
 *         &lt;element name="grantRecipientRightToReverseEngineer" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}permittedOrRequired" minOccurs="0"/>
 *         &lt;element name="includeLicense" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="indemnificationRequired" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="integrationLevelForLicenseApplication" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}licenseExtensionLevel" minOccurs="0"/>
 *         &lt;element name="licenseBackRequired" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="limitationOfLiabilityRequired" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="notice" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="patentRetaliation" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="promotionRestriction" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="rightToDistributeBinaryForMaximumUsage" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}rightToDistributeBinaryForMaximumUsage" minOccurs="0"/>
 *         &lt;element name="shareAlikeReciprocity" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="sourceCodeDistribution" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}permittedOrRequired" minOccurs="0"/>
 *         &lt;element name="warrantyDisclaimerRequired" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "licenseAttributes", propOrder = {
    "antiDrmProvision",
    "carriesDistributionObligations",
    "changeNoticeRequired",
    "chargingFees",
    "discriminatoryRestrictions",
    "expressPatentLicense",
    "grantRecipientRightToCopy",
    "grantRecipientRightToModify",
    "grantRecipientRightToReverseEngineer",
    "includeLicense",
    "indemnificationRequired",
    "integrationLevelForLicenseApplication",
    "licenseBackRequired",
    "limitationOfLiabilityRequired",
    "notice",
    "patentRetaliation",
    "promotionRestriction",
    "rightToDistributeBinaryForMaximumUsage",
    "shareAlikeReciprocity",
    "sourceCodeDistribution",
    "warrantyDisclaimerRequired"
})
public class LicenseAttributes {

    protected Boolean antiDrmProvision;
    protected Boolean carriesDistributionObligations;
    protected Boolean changeNoticeRequired;
    protected PermittedOrRequired chargingFees;
    protected RestrictionType discriminatoryRestrictions;
    protected Boolean expressPatentLicense;
    protected PermittedOrRequired grantRecipientRightToCopy;
    protected PermittedOrRequired grantRecipientRightToModify;
    protected PermittedOrRequired grantRecipientRightToReverseEngineer;
    protected Boolean includeLicense;
    protected Boolean indemnificationRequired;
    protected LicenseExtensionLevel integrationLevelForLicenseApplication;
    protected Boolean licenseBackRequired;
    protected Boolean limitationOfLiabilityRequired;
    protected Boolean notice;
    protected Boolean patentRetaliation;
    protected Boolean promotionRestriction;
    protected RightToDistributeBinaryForMaximumUsage rightToDistributeBinaryForMaximumUsage;
    protected Boolean shareAlikeReciprocity;
    protected PermittedOrRequired sourceCodeDistribution;
    protected Boolean warrantyDisclaimerRequired;

    /**
     * Gets the value of the antiDrmProvision property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isAntiDrmProvision() {
        return antiDrmProvision;
    }

    /**
     * Sets the value of the antiDrmProvision property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setAntiDrmProvision(Boolean value) {
        this.antiDrmProvision = value;
    }

    /**
     * Gets the value of the carriesDistributionObligations property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isCarriesDistributionObligations() {
        return carriesDistributionObligations;
    }

    /**
     * Sets the value of the carriesDistributionObligations property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setCarriesDistributionObligations(Boolean value) {
        this.carriesDistributionObligations = value;
    }

    /**
     * Gets the value of the changeNoticeRequired property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isChangeNoticeRequired() {
        return changeNoticeRequired;
    }

    /**
     * Sets the value of the changeNoticeRequired property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setChangeNoticeRequired(Boolean value) {
        this.changeNoticeRequired = value;
    }

    /**
     * Gets the value of the chargingFees property.
     * 
     * @return
     *     possible object is
     *     {@link PermittedOrRequired }
     *     
     */
    public PermittedOrRequired getChargingFees() {
        return chargingFees;
    }

    /**
     * Sets the value of the chargingFees property.
     * 
     * @param value
     *     allowed object is
     *     {@link PermittedOrRequired }
     *     
     */
    public void setChargingFees(PermittedOrRequired value) {
        this.chargingFees = value;
    }

    /**
     * Gets the value of the discriminatoryRestrictions property.
     * 
     * @return
     *     possible object is
     *     {@link RestrictionType }
     *     
     */
    public RestrictionType getDiscriminatoryRestrictions() {
        return discriminatoryRestrictions;
    }

    /**
     * Sets the value of the discriminatoryRestrictions property.
     * 
     * @param value
     *     allowed object is
     *     {@link RestrictionType }
     *     
     */
    public void setDiscriminatoryRestrictions(RestrictionType value) {
        this.discriminatoryRestrictions = value;
    }

    /**
     * Gets the value of the expressPatentLicense property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isExpressPatentLicense() {
        return expressPatentLicense;
    }

    /**
     * Sets the value of the expressPatentLicense property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setExpressPatentLicense(Boolean value) {
        this.expressPatentLicense = value;
    }

    /**
     * Gets the value of the grantRecipientRightToCopy property.
     * 
     * @return
     *     possible object is
     *     {@link PermittedOrRequired }
     *     
     */
    public PermittedOrRequired getGrantRecipientRightToCopy() {
        return grantRecipientRightToCopy;
    }

    /**
     * Sets the value of the grantRecipientRightToCopy property.
     * 
     * @param value
     *     allowed object is
     *     {@link PermittedOrRequired }
     *     
     */
    public void setGrantRecipientRightToCopy(PermittedOrRequired value) {
        this.grantRecipientRightToCopy = value;
    }

    /**
     * Gets the value of the grantRecipientRightToModify property.
     * 
     * @return
     *     possible object is
     *     {@link PermittedOrRequired }
     *     
     */
    public PermittedOrRequired getGrantRecipientRightToModify() {
        return grantRecipientRightToModify;
    }

    /**
     * Sets the value of the grantRecipientRightToModify property.
     * 
     * @param value
     *     allowed object is
     *     {@link PermittedOrRequired }
     *     
     */
    public void setGrantRecipientRightToModify(PermittedOrRequired value) {
        this.grantRecipientRightToModify = value;
    }

    /**
     * Gets the value of the grantRecipientRightToReverseEngineer property.
     * 
     * @return
     *     possible object is
     *     {@link PermittedOrRequired }
     *     
     */
    public PermittedOrRequired getGrantRecipientRightToReverseEngineer() {
        return grantRecipientRightToReverseEngineer;
    }

    /**
     * Sets the value of the grantRecipientRightToReverseEngineer property.
     * 
     * @param value
     *     allowed object is
     *     {@link PermittedOrRequired }
     *     
     */
    public void setGrantRecipientRightToReverseEngineer(PermittedOrRequired value) {
        this.grantRecipientRightToReverseEngineer = value;
    }

    /**
     * Gets the value of the includeLicense property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeLicense() {
        return includeLicense;
    }

    /**
     * Sets the value of the includeLicense property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeLicense(Boolean value) {
        this.includeLicense = value;
    }

    /**
     * Gets the value of the indemnificationRequired property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIndemnificationRequired() {
        return indemnificationRequired;
    }

    /**
     * Sets the value of the indemnificationRequired property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIndemnificationRequired(Boolean value) {
        this.indemnificationRequired = value;
    }

    /**
     * Gets the value of the integrationLevelForLicenseApplication property.
     * 
     * @return
     *     possible object is
     *     {@link LicenseExtensionLevel }
     *     
     */
    public LicenseExtensionLevel getIntegrationLevelForLicenseApplication() {
        return integrationLevelForLicenseApplication;
    }

    /**
     * Sets the value of the integrationLevelForLicenseApplication property.
     * 
     * @param value
     *     allowed object is
     *     {@link LicenseExtensionLevel }
     *     
     */
    public void setIntegrationLevelForLicenseApplication(LicenseExtensionLevel value) {
        this.integrationLevelForLicenseApplication = value;
    }

    /**
     * Gets the value of the licenseBackRequired property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLicenseBackRequired() {
        return licenseBackRequired;
    }

    /**
     * Sets the value of the licenseBackRequired property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLicenseBackRequired(Boolean value) {
        this.licenseBackRequired = value;
    }

    /**
     * Gets the value of the limitationOfLiabilityRequired property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isLimitationOfLiabilityRequired() {
        return limitationOfLiabilityRequired;
    }

    /**
     * Sets the value of the limitationOfLiabilityRequired property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setLimitationOfLiabilityRequired(Boolean value) {
        this.limitationOfLiabilityRequired = value;
    }

    /**
     * Gets the value of the notice property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isNotice() {
        return notice;
    }

    /**
     * Sets the value of the notice property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setNotice(Boolean value) {
        this.notice = value;
    }

    /**
     * Gets the value of the patentRetaliation property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPatentRetaliation() {
        return patentRetaliation;
    }

    /**
     * Sets the value of the patentRetaliation property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPatentRetaliation(Boolean value) {
        this.patentRetaliation = value;
    }

    /**
     * Gets the value of the promotionRestriction property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPromotionRestriction() {
        return promotionRestriction;
    }

    /**
     * Sets the value of the promotionRestriction property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPromotionRestriction(Boolean value) {
        this.promotionRestriction = value;
    }

    /**
     * Gets the value of the rightToDistributeBinaryForMaximumUsage property.
     * 
     * @return
     *     possible object is
     *     {@link RightToDistributeBinaryForMaximumUsage }
     *     
     */
    public RightToDistributeBinaryForMaximumUsage getRightToDistributeBinaryForMaximumUsage() {
        return rightToDistributeBinaryForMaximumUsage;
    }

    /**
     * Sets the value of the rightToDistributeBinaryForMaximumUsage property.
     * 
     * @param value
     *     allowed object is
     *     {@link RightToDistributeBinaryForMaximumUsage }
     *     
     */
    public void setRightToDistributeBinaryForMaximumUsage(RightToDistributeBinaryForMaximumUsage value) {
        this.rightToDistributeBinaryForMaximumUsage = value;
    }

    /**
     * Gets the value of the shareAlikeReciprocity property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isShareAlikeReciprocity() {
        return shareAlikeReciprocity;
    }

    /**
     * Sets the value of the shareAlikeReciprocity property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setShareAlikeReciprocity(Boolean value) {
        this.shareAlikeReciprocity = value;
    }

    /**
     * Gets the value of the sourceCodeDistribution property.
     * 
     * @return
     *     possible object is
     *     {@link PermittedOrRequired }
     *     
     */
    public PermittedOrRequired getSourceCodeDistribution() {
        return sourceCodeDistribution;
    }

    /**
     * Sets the value of the sourceCodeDistribution property.
     * 
     * @param value
     *     allowed object is
     *     {@link PermittedOrRequired }
     *     
     */
    public void setSourceCodeDistribution(PermittedOrRequired value) {
        this.sourceCodeDistribution = value;
    }

    /**
     * Gets the value of the warrantyDisclaimerRequired property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isWarrantyDisclaimerRequired() {
        return warrantyDisclaimerRequired;
    }

    /**
     * Sets the value of the warrantyDisclaimerRequired property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setWarrantyDisclaimerRequired(Boolean value) {
        this.warrantyDisclaimerRequired = value;
    }

}
