
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.project.localcomponent.LocalLicense;


/**
 * <p>Java class for license complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="license">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="attributes" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}licenseAttributes" minOccurs="0"/>
 *         &lt;element name="licenseId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="licenseOriginType" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}licenseOriginType" minOccurs="0"/>
 *         &lt;element name="name" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="text" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "license", propOrder = {
    "attributes",
    "licenseId",
    "licenseOriginType",
    "name",
    "text"
})
@XmlSeeAlso({
    GlobalLicense.class,
    LocalLicense.class
})
public class License {

    protected LicenseAttributes attributes;
    protected String licenseId;
    protected LicenseOriginType licenseOriginType;
    protected String name;
    protected byte[] text;

    /**
     * Gets the value of the attributes property.
     * 
     * @return
     *     possible object is
     *     {@link LicenseAttributes }
     *     
     */
    public LicenseAttributes getAttributes() {
        return attributes;
    }

    /**
     * Sets the value of the attributes property.
     * 
     * @param value
     *     allowed object is
     *     {@link LicenseAttributes }
     *     
     */
    public void setAttributes(LicenseAttributes value) {
        this.attributes = value;
    }

    /**
     * Gets the value of the licenseId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLicenseId() {
        return licenseId;
    }

    /**
     * Sets the value of the licenseId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLicenseId(String value) {
        this.licenseId = value;
    }

    /**
     * Gets the value of the licenseOriginType property.
     * 
     * @return
     *     possible object is
     *     {@link LicenseOriginType }
     *     
     */
    public LicenseOriginType getLicenseOriginType() {
        return licenseOriginType;
    }

    /**
     * Sets the value of the licenseOriginType property.
     * 
     * @param value
     *     allowed object is
     *     {@link LicenseOriginType }
     *     
     */
    public void setLicenseOriginType(LicenseOriginType value) {
        this.licenseOriginType = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the text property.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getText() {
        return text;
    }

    /**
     * Sets the value of the text property.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setText(byte[] value) {
        this.text = value;
    }

}
