
package com.blackducksoftware.sdk.protex.license;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for licenseOriginType.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="licenseOriginType">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="STANDARD"/>
 *     &lt;enumeration value="MODIFIED_STANDARD"/>
 *     &lt;enumeration value="TEMPLATE"/>
 *     &lt;enumeration value="CUSTOM"/>
 *     &lt;enumeration value="PROJECT_LOCAL"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "licenseOriginType")
@XmlEnum
public enum LicenseOriginType {

    STANDARD,
    MODIFIED_STANDARD,
    TEMPLATE,
    CUSTOM,
    PROJECT_LOCAL;

    public String value() {
        return name();
    }

    public static LicenseOriginType fromValue(String v) {
        return valueOf(v);
    }

}
