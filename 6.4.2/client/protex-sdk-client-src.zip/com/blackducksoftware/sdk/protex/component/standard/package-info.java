@javax.xml.bind.annotation.XmlSchema(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:standardcomponent")
package com.blackducksoftware.sdk.protex.component.standard;
