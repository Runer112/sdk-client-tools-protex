
package com.blackducksoftware.sdk.protex.component.version;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for modifyComponentVersionLocally complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="modifyComponentVersionLocally">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="componentVersionModificationRequest" type="{urn:protex.blackducksoftware.com:sdk:v6.3:componentversion}componentVersionModificationRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "modifyComponentVersionLocally", propOrder = {
    "componentVersionModificationRequest"
})
public class ModifyComponentVersionLocally {

    protected ComponentVersionModificationRequest componentVersionModificationRequest;

    /**
     * Gets the value of the componentVersionModificationRequest property.
     * 
     * @return
     *     possible object is
     *     {@link ComponentVersionModificationRequest }
     *     
     */
    public ComponentVersionModificationRequest getComponentVersionModificationRequest() {
        return componentVersionModificationRequest;
    }

    /**
     * Sets the value of the componentVersionModificationRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ComponentVersionModificationRequest }
     *     
     */
    public void setComponentVersionModificationRequest(ComponentVersionModificationRequest value) {
        this.componentVersionModificationRequest = value;
    }

}
