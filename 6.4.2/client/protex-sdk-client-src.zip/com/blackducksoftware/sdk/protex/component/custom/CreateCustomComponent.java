
package com.blackducksoftware.sdk.protex.component.custom;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createCustomComponent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createCustomComponent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="componentRequest" type="{urn:protex.blackducksoftware.com:sdk:v6.3:customcomponent}customComponentRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createCustomComponent", propOrder = {
    "componentRequest"
})
public class CreateCustomComponent {

    protected CustomComponentRequest componentRequest;

    /**
     * Gets the value of the componentRequest property.
     * 
     * @return
     *     possible object is
     *     {@link CustomComponentRequest }
     *     
     */
    public CustomComponentRequest getComponentRequest() {
        return componentRequest;
    }

    /**
     * Sets the value of the componentRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomComponentRequest }
     *     
     */
    public void setComponentRequest(CustomComponentRequest value) {
        this.componentRequest = value;
    }

}
