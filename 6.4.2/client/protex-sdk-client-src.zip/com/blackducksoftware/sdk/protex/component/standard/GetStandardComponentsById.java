
package com.blackducksoftware.sdk.protex.component.standard;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.GetBehavior;


/**
 * <p>Java class for getStandardComponentsById complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getStandardComponentsById">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="componentIds" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="getBehavior" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}getBehavior" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getStandardComponentsById", propOrder = {
    "componentIds",
    "getBehavior"
})
public class GetStandardComponentsById {

    protected List<String> componentIds;
    protected GetBehavior getBehavior;

    /**
     * Gets the value of the componentIds property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the componentIds property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getComponentIds().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getComponentIds() {
        if (componentIds == null) {
            componentIds = new ArrayList<String>();
        }
        return this.componentIds;
    }

    /**
     * Gets the value of the getBehavior property.
     * 
     * @return
     *     possible object is
     *     {@link GetBehavior }
     *     
     */
    public GetBehavior getGetBehavior() {
        return getBehavior;
    }

    /**
     * Sets the value of the getBehavior property.
     * 
     * @param value
     *     allowed object is
     *     {@link GetBehavior }
     *     
     */
    public void setGetBehavior(GetBehavior value) {
        this.getBehavior = value;
    }

}
