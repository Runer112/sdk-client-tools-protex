
package com.blackducksoftware.sdk.protex.component.version;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.blackducksoftware.sdk.protex.component.version package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SuggestComponentVersions_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "suggestComponentVersions");
    private final static QName _RestoreComponentVersion_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "restoreComponentVersion");
    private final static QName _GetComponentVersionByNameResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "getComponentVersionByNameResponse");
    private final static QName _ModifyComponentVersionLocallyResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "modifyComponentVersionLocallyResponse");
    private final static QName _GetComponentVersionByIdResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "getComponentVersionByIdResponse");
    private final static QName _GetComponentVersionsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "getComponentVersionsResponse");
    private final static QName _RestoreComponentVersionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "restoreComponentVersionResponse");
    private final static QName _GetComponentVersions_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "getComponentVersions");
    private final static QName _ModifyComponentVersionLocally_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "modifyComponentVersionLocally");
    private final static QName _GetComponentVersionByName_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "getComponentVersionByName");
    private final static QName _SuggestComponentVersionsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "suggestComponentVersionsResponse");
    private final static QName _GetComponentVersionById_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", "getComponentVersionById");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.blackducksoftware.sdk.protex.component.version
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetComponentVersionById }
     * 
     */
    public GetComponentVersionById createGetComponentVersionById() {
        return new GetComponentVersionById();
    }

    /**
     * Create an instance of {@link RestoreComponentVersionResponse }
     * 
     */
    public RestoreComponentVersionResponse createRestoreComponentVersionResponse() {
        return new RestoreComponentVersionResponse();
    }

    /**
     * Create an instance of {@link GetComponentVersions }
     * 
     */
    public GetComponentVersions createGetComponentVersions() {
        return new GetComponentVersions();
    }

    /**
     * Create an instance of {@link SuggestComponentVersionsResponse }
     * 
     */
    public SuggestComponentVersionsResponse createSuggestComponentVersionsResponse() {
        return new SuggestComponentVersionsResponse();
    }

    /**
     * Create an instance of {@link ModifyComponentVersionLocally }
     * 
     */
    public ModifyComponentVersionLocally createModifyComponentVersionLocally() {
        return new ModifyComponentVersionLocally();
    }

    /**
     * Create an instance of {@link GetComponentVersionsResponse }
     * 
     */
    public GetComponentVersionsResponse createGetComponentVersionsResponse() {
        return new GetComponentVersionsResponse();
    }

    /**
     * Create an instance of {@link GetComponentVersionByName }
     * 
     */
    public GetComponentVersionByName createGetComponentVersionByName() {
        return new GetComponentVersionByName();
    }

    /**
     * Create an instance of {@link GetComponentVersionByIdResponse }
     * 
     */
    public GetComponentVersionByIdResponse createGetComponentVersionByIdResponse() {
        return new GetComponentVersionByIdResponse();
    }

    /**
     * Create an instance of {@link SuggestComponentVersions }
     * 
     */
    public SuggestComponentVersions createSuggestComponentVersions() {
        return new SuggestComponentVersions();
    }

    /**
     * Create an instance of {@link RestoreComponentVersion }
     * 
     */
    public RestoreComponentVersion createRestoreComponentVersion() {
        return new RestoreComponentVersion();
    }

    /**
     * Create an instance of {@link GetComponentVersionByNameResponse }
     * 
     */
    public GetComponentVersionByNameResponse createGetComponentVersionByNameResponse() {
        return new GetComponentVersionByNameResponse();
    }

    /**
     * Create an instance of {@link ModifyComponentVersionLocallyResponse }
     * 
     */
    public ModifyComponentVersionLocallyResponse createModifyComponentVersionLocallyResponse() {
        return new ModifyComponentVersionLocallyResponse();
    }

    /**
     * Create an instance of {@link ComponentVersionModificationRequest }
     * 
     */
    public ComponentVersionModificationRequest createComponentVersionModificationRequest() {
        return new ComponentVersionModificationRequest();
    }

    /**
     * Create an instance of {@link ComponentVersionInfoPageFilter }
     * 
     */
    public ComponentVersionInfoPageFilter createComponentVersionInfoPageFilter() {
        return new ComponentVersionInfoPageFilter();
    }

    /**
     * Create an instance of {@link ComponentVersion }
     * 
     */
    public ComponentVersion createComponentVersion() {
        return new ComponentVersion();
    }

    /**
     * Create an instance of {@link ComponentVersionInfo }
     * 
     */
    public ComponentVersionInfo createComponentVersionInfo() {
        return new ComponentVersionInfo();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuggestComponentVersions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "suggestComponentVersions")
    public JAXBElement<SuggestComponentVersions> createSuggestComponentVersions(SuggestComponentVersions value) {
        return new JAXBElement<SuggestComponentVersions>(_SuggestComponentVersions_QNAME, SuggestComponentVersions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RestoreComponentVersion }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "restoreComponentVersion")
    public JAXBElement<RestoreComponentVersion> createRestoreComponentVersion(RestoreComponentVersion value) {
        return new JAXBElement<RestoreComponentVersion>(_RestoreComponentVersion_QNAME, RestoreComponentVersion.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentVersionByNameResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "getComponentVersionByNameResponse")
    public JAXBElement<GetComponentVersionByNameResponse> createGetComponentVersionByNameResponse(GetComponentVersionByNameResponse value) {
        return new JAXBElement<GetComponentVersionByNameResponse>(_GetComponentVersionByNameResponse_QNAME, GetComponentVersionByNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModifyComponentVersionLocallyResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "modifyComponentVersionLocallyResponse")
    public JAXBElement<ModifyComponentVersionLocallyResponse> createModifyComponentVersionLocallyResponse(ModifyComponentVersionLocallyResponse value) {
        return new JAXBElement<ModifyComponentVersionLocallyResponse>(_ModifyComponentVersionLocallyResponse_QNAME, ModifyComponentVersionLocallyResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentVersionByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "getComponentVersionByIdResponse")
    public JAXBElement<GetComponentVersionByIdResponse> createGetComponentVersionByIdResponse(GetComponentVersionByIdResponse value) {
        return new JAXBElement<GetComponentVersionByIdResponse>(_GetComponentVersionByIdResponse_QNAME, GetComponentVersionByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentVersionsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "getComponentVersionsResponse")
    public JAXBElement<GetComponentVersionsResponse> createGetComponentVersionsResponse(GetComponentVersionsResponse value) {
        return new JAXBElement<GetComponentVersionsResponse>(_GetComponentVersionsResponse_QNAME, GetComponentVersionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RestoreComponentVersionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "restoreComponentVersionResponse")
    public JAXBElement<RestoreComponentVersionResponse> createRestoreComponentVersionResponse(RestoreComponentVersionResponse value) {
        return new JAXBElement<RestoreComponentVersionResponse>(_RestoreComponentVersionResponse_QNAME, RestoreComponentVersionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentVersions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "getComponentVersions")
    public JAXBElement<GetComponentVersions> createGetComponentVersions(GetComponentVersions value) {
        return new JAXBElement<GetComponentVersions>(_GetComponentVersions_QNAME, GetComponentVersions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ModifyComponentVersionLocally }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "modifyComponentVersionLocally")
    public JAXBElement<ModifyComponentVersionLocally> createModifyComponentVersionLocally(ModifyComponentVersionLocally value) {
        return new JAXBElement<ModifyComponentVersionLocally>(_ModifyComponentVersionLocally_QNAME, ModifyComponentVersionLocally.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentVersionByName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "getComponentVersionByName")
    public JAXBElement<GetComponentVersionByName> createGetComponentVersionByName(GetComponentVersionByName value) {
        return new JAXBElement<GetComponentVersionByName>(_GetComponentVersionByName_QNAME, GetComponentVersionByName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuggestComponentVersionsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "suggestComponentVersionsResponse")
    public JAXBElement<SuggestComponentVersionsResponse> createSuggestComponentVersionsResponse(SuggestComponentVersionsResponse value) {
        return new JAXBElement<SuggestComponentVersionsResponse>(_SuggestComponentVersionsResponse_QNAME, SuggestComponentVersionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetComponentVersionById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:componentversion", name = "getComponentVersionById")
    public JAXBElement<GetComponentVersionById> createGetComponentVersionById(GetComponentVersionById value) {
        return new JAXBElement<GetComponentVersionById>(_GetComponentVersionById_QNAME, GetComponentVersionById.class, null, value);
    }

}
