
package com.blackducksoftware.sdk.protex.component.custom;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for updateCustomComponent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateCustomComponent">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="component" type="{urn:protex.blackducksoftware.com:sdk:v6.3:customcomponent}customComponent" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateCustomComponent", propOrder = {
    "component"
})
public class UpdateCustomComponent {

    protected CustomComponent component;

    /**
     * Gets the value of the component property.
     * 
     * @return
     *     possible object is
     *     {@link CustomComponent }
     *     
     */
    public CustomComponent getComponent() {
        return component;
    }

    /**
     * Sets the value of the component property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomComponent }
     *     
     */
    public void setComponent(CustomComponent value) {
        this.component = value;
    }

}
