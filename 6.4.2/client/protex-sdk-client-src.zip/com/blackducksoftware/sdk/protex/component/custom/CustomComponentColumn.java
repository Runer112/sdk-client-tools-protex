
package com.blackducksoftware.sdk.protex.component.custom;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for customComponentColumn.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="customComponentColumn">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="COMPONENT_ID"/>
 *     &lt;enumeration value="COMPONENT_NAME"/>
 *     &lt;enumeration value="COMPONENT_LICENSE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "customComponentColumn")
@XmlEnum
public enum CustomComponentColumn {

    COMPONENT_ID,
    COMPONENT_NAME,
    COMPONENT_LICENSE;

    public String value() {
        return name();
    }

    public static CustomComponentColumn fromValue(String v) {
        return valueOf(v);
    }

}
