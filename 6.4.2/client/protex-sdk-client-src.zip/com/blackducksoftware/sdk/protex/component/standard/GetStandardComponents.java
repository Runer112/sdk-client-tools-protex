
package com.blackducksoftware.sdk.protex.component.standard;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for getStandardComponents complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getStandardComponents">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="modifiedOnly" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="includeDeprecated" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="pageFilter" type="{urn:protex.blackducksoftware.com:sdk:v6.3:standardcomponent}standardComponentPageFilter" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getStandardComponents", propOrder = {
    "modifiedOnly",
    "includeDeprecated",
    "pageFilter"
})
public class GetStandardComponents {

    protected Boolean modifiedOnly;
    protected Boolean includeDeprecated;
    protected StandardComponentPageFilter pageFilter;

    /**
     * Gets the value of the modifiedOnly property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isModifiedOnly() {
        return modifiedOnly;
    }

    /**
     * Sets the value of the modifiedOnly property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setModifiedOnly(Boolean value) {
        this.modifiedOnly = value;
    }

    /**
     * Gets the value of the includeDeprecated property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIncludeDeprecated() {
        return includeDeprecated;
    }

    /**
     * Sets the value of the includeDeprecated property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIncludeDeprecated(Boolean value) {
        this.includeDeprecated = value;
    }

    /**
     * Gets the value of the pageFilter property.
     * 
     * @return
     *     possible object is
     *     {@link StandardComponentPageFilter }
     *     
     */
    public StandardComponentPageFilter getPageFilter() {
        return pageFilter;
    }

    /**
     * Sets the value of the pageFilter property.
     * 
     * @param value
     *     allowed object is
     *     {@link StandardComponentPageFilter }
     *     
     */
    public void setPageFilter(StandardComponentPageFilter value) {
        this.pageFilter = value;
    }

}
