
package com.blackducksoftware.sdk.protex.component.standard;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.blackducksoftware.sdk.protex.common.ApprovalInfo;
import com.blackducksoftware.sdk.protex.common.Component;
import com.blackducksoftware.sdk.protex.common.FileComparisonRepository;
import com.blackducksoftware.sdk.protex.license.LicenseInfo;
import com.blackducksoftware.sdk.protex.project.Adapter1;


/**
 * <p>Java class for standardComponent complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="standardComponent">
 *   &lt;complexContent>
 *     &lt;extension base="{urn:protex.blackducksoftware.com:sdk:v6.3:common}component">
 *       &lt;sequence>
 *         &lt;element name="approvalInfo" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}approvalInfo" minOccurs="0"/>
 *         &lt;element name="deprecated" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fileComparisonRepository" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}fileComparisonRepository" minOccurs="0"/>
 *         &lt;element name="homePage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="licenseCitation" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="licenses" type="{urn:protex.blackducksoftware.com:sdk:v6.3:license}licenseInfo" maxOccurs="unbounded" minOccurs="0"/>
 *         &lt;element name="releaseDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="startDate" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *         &lt;element name="suffix" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "standardComponent", propOrder = {
    "approvalInfo",
    "deprecated",
    "description",
    "fileComparisonRepository",
    "homePage",
    "licenseCitation",
    "licenses",
    "releaseDate",
    "startDate",
    "suffix"
})
public class StandardComponent
    extends Component
{

    protected ApprovalInfo approvalInfo;
    protected Boolean deprecated;
    protected String description;
    protected FileComparisonRepository fileComparisonRepository;
    protected String homePage;
    protected String licenseCitation;
    @XmlElement(nillable = true)
    protected List<LicenseInfo> licenses;
    @XmlElement(type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date releaseDate;
    @XmlElement(type = String.class)
    @XmlJavaTypeAdapter(Adapter1 .class)
    @XmlSchemaType(name = "dateTime")
    protected Date startDate;
    protected String suffix;

    /**
     * Gets the value of the approvalInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ApprovalInfo }
     *     
     */
    public ApprovalInfo getApprovalInfo() {
        return approvalInfo;
    }

    /**
     * Sets the value of the approvalInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ApprovalInfo }
     *     
     */
    public void setApprovalInfo(ApprovalInfo value) {
        this.approvalInfo = value;
    }

    /**
     * Gets the value of the deprecated property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isDeprecated() {
        return deprecated;
    }

    /**
     * Sets the value of the deprecated property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setDeprecated(Boolean value) {
        this.deprecated = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the fileComparisonRepository property.
     * 
     * @return
     *     possible object is
     *     {@link FileComparisonRepository }
     *     
     */
    public FileComparisonRepository getFileComparisonRepository() {
        return fileComparisonRepository;
    }

    /**
     * Sets the value of the fileComparisonRepository property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileComparisonRepository }
     *     
     */
    public void setFileComparisonRepository(FileComparisonRepository value) {
        this.fileComparisonRepository = value;
    }

    /**
     * Gets the value of the homePage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getHomePage() {
        return homePage;
    }

    /**
     * Sets the value of the homePage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setHomePage(String value) {
        this.homePage = value;
    }

    /**
     * Gets the value of the licenseCitation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLicenseCitation() {
        return licenseCitation;
    }

    /**
     * Sets the value of the licenseCitation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLicenseCitation(String value) {
        this.licenseCitation = value;
    }

    /**
     * Gets the value of the licenses property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the licenses property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLicenses().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LicenseInfo }
     * 
     * 
     */
    public List<LicenseInfo> getLicenses() {
        if (licenses == null) {
            licenses = new ArrayList<LicenseInfo>();
        }
        return this.licenses;
    }

    /**
     * Gets the value of the releaseDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getReleaseDate() {
        return releaseDate;
    }

    /**
     * Sets the value of the releaseDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setReleaseDate(Date value) {
        this.releaseDate = value;
    }

    /**
     * Gets the value of the startDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public Date getStartDate() {
        return startDate;
    }

    /**
     * Sets the value of the startDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartDate(Date value) {
        this.startDate = value;
    }

    /**
     * Gets the value of the suffix property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuffix() {
        return suffix;
    }

    /**
     * Sets the value of the suffix property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuffix(String value) {
        this.suffix = value;
    }

}
