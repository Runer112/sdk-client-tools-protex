
package com.blackducksoftware.sdk.protex.project;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.FileDiscoveryPatternRequest;


/**
 * <p>Java class for addFileDiscoveryPattern complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="addFileDiscoveryPattern">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="projectId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="fileDiscoveryPattern" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}fileDiscoveryPatternRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "addFileDiscoveryPattern", propOrder = {
    "projectId",
    "fileDiscoveryPattern"
})
public class AddFileDiscoveryPattern {

    protected String projectId;
    protected FileDiscoveryPatternRequest fileDiscoveryPattern;

    /**
     * Gets the value of the projectId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProjectId() {
        return projectId;
    }

    /**
     * Sets the value of the projectId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProjectId(String value) {
        this.projectId = value;
    }

    /**
     * Gets the value of the fileDiscoveryPattern property.
     * 
     * @return
     *     possible object is
     *     {@link FileDiscoveryPatternRequest }
     *     
     */
    public FileDiscoveryPatternRequest getFileDiscoveryPattern() {
        return fileDiscoveryPattern;
    }

    /**
     * Sets the value of the fileDiscoveryPattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link FileDiscoveryPatternRequest }
     *     
     */
    public void setFileDiscoveryPattern(FileDiscoveryPatternRequest value) {
        this.fileDiscoveryPattern = value;
    }

}
