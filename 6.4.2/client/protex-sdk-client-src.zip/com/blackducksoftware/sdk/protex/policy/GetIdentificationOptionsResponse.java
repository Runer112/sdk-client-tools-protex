
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.IdentificationOptions;


/**
 * <p>Java class for getIdentificationOptionsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="getIdentificationOptionsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="return" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}identificationOptions" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getIdentificationOptionsResponse", propOrder = {
    "_return"
})
public class GetIdentificationOptionsResponse {

    @XmlElement(name = "return")
    protected IdentificationOptions _return;

    /**
     * Gets the value of the return property.
     * 
     * @return
     *     possible object is
     *     {@link IdentificationOptions }
     *     
     */
    public IdentificationOptions getReturn() {
        return _return;
    }

    /**
     * Sets the value of the return property.
     * 
     * @param value
     *     allowed object is
     *     {@link IdentificationOptions }
     *     
     */
    public void setReturn(IdentificationOptions value) {
        this._return = value;
    }

}
