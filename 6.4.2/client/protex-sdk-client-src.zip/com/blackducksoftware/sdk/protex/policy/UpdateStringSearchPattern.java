
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.StringSearchPattern;


/**
 * <p>Java class for updateStringSearchPattern complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="updateStringSearchPattern">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="stringSearchPattern" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}stringSearchPattern" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "updateStringSearchPattern", propOrder = {
    "stringSearchPattern"
})
public class UpdateStringSearchPattern {

    protected StringSearchPattern stringSearchPattern;

    /**
     * Gets the value of the stringSearchPattern property.
     * 
     * @return
     *     possible object is
     *     {@link StringSearchPattern }
     *     
     */
    public StringSearchPattern getStringSearchPattern() {
        return stringSearchPattern;
    }

    /**
     * Sets the value of the stringSearchPattern property.
     * 
     * @param value
     *     allowed object is
     *     {@link StringSearchPattern }
     *     
     */
    public void setStringSearchPattern(StringSearchPattern value) {
        this.stringSearchPattern = value;
    }

}
