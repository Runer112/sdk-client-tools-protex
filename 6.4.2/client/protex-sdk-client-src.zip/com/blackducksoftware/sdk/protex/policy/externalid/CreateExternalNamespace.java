
package com.blackducksoftware.sdk.protex.policy.externalid;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for createExternalNamespace complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createExternalNamespace">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="namespaceRequest" type="{urn:protex.blackducksoftware.com:sdk:v6.3:externalid}externalNamespaceRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createExternalNamespace", propOrder = {
    "namespaceRequest"
})
public class CreateExternalNamespace {

    protected ExternalNamespaceRequest namespaceRequest;

    /**
     * Gets the value of the namespaceRequest property.
     * 
     * @return
     *     possible object is
     *     {@link ExternalNamespaceRequest }
     *     
     */
    public ExternalNamespaceRequest getNamespaceRequest() {
        return namespaceRequest;
    }

    /**
     * Sets the value of the namespaceRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ExternalNamespaceRequest }
     *     
     */
    public void setNamespaceRequest(ExternalNamespaceRequest value) {
        this.namespaceRequest = value;
    }

}
