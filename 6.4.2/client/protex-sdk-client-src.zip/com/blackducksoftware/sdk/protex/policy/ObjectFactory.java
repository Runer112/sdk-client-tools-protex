
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.blackducksoftware.sdk.protex.policy package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _CreateRapidIdConfiguration_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "createRapidIdConfiguration");
    private final static QName _GetRapidIdConfigurationAssociations_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRapidIdConfigurationAssociations");
    private final static QName _UpdateIdentificationOptionsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateIdentificationOptionsResponse");
    private final static QName _UpdateFileDiscoveryPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateFileDiscoveryPatternResponse");
    private final static QName _UpdateCaptureOptionsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateCaptureOptionsResponse");
    private final static QName _UpdateCaptureOptions_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateCaptureOptions");
    private final static QName _GetRapidIdConfigurationAssociationsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRapidIdConfigurationAssociationsResponse");
    private final static QName _UpdateRapidIdentificationOption_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateRapidIdentificationOption");
    private final static QName _UpdateFileDiscoveryPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateFileDiscoveryPattern");
    private final static QName _GetProjectSynchronizationOptionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getProjectSynchronizationOptionResponse");
    private final static QName _GetRapidIdConfigurationById_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRapidIdConfigurationById");
    private final static QName _GetRapidIdConfigurationByName_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRapidIdConfigurationByName");
    private final static QName _GetFileDiscoveryPatternById_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getFileDiscoveryPatternById");
    private final static QName _GetIdentificationOptions_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getIdentificationOptions");
    private final static QName _GetFileDiscoveryPatternByIdResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getFileDiscoveryPatternByIdResponse");
    private final static QName _DeleteRapidIdConfiguration_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "deleteRapidIdConfiguration");
    private final static QName _GetRapidIdConfigurations_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRapidIdConfigurations");
    private final static QName _GetAnonymousAccessPolicy_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getAnonymousAccessPolicy");
    private final static QName _GetAnalysisDatabaseOptionsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getAnalysisDatabaseOptionsResponse");
    private final static QName _RemoveLearnedIdentificationResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "removeLearnedIdentificationResponse");
    private final static QName _SuggestFileDiscoveryPatternsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "suggestFileDiscoveryPatternsResponse");
    private final static QName _UpdateAnalysisDatabaseOptionsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateAnalysisDatabaseOptionsResponse");
    private final static QName _GetStringSearchPatternsByTypeResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getStringSearchPatternsByTypeResponse");
    private final static QName _GetDefaultOpenSourceLicense_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getDefaultOpenSourceLicense");
    private final static QName _GetDefaultOpenSourceLicenseResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getDefaultOpenSourceLicenseResponse");
    private final static QName _UpdateAnalysisDatabaseOptions_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateAnalysisDatabaseOptions");
    private final static QName _AssociateRapidIdConfigurationResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "associateRapidIdConfigurationResponse");
    private final static QName _CreateFileDiscoveryPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "createFileDiscoveryPattern");
    private final static QName _UpdateRapidIdentificationOptionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateRapidIdentificationOptionResponse");
    private final static QName _DeleteFileDiscoveryPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "deleteFileDiscoveryPatternResponse");
    private final static QName _UpdateRegistrationLinkOptionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateRegistrationLinkOptionResponse");
    private final static QName _UpdateRegistrationLinkOption_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateRegistrationLinkOption");
    private final static QName _GetAnonymousAccessPolicyResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getAnonymousAccessPolicyResponse");
    private final static QName _CreateStringSearchPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "createStringSearchPatternResponse");
    private final static QName _UpdateIdentificationOptions_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateIdentificationOptions");
    private final static QName _GetProjectSynchronizationOption_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getProjectSynchronizationOption");
    private final static QName _GetFileDiscoveryPatternsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getFileDiscoveryPatternsResponse");
    private final static QName _GetLearnedIdentificationsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getLearnedIdentificationsResponse");
    private final static QName _UpdateAnonymousAccessPolicyResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateAnonymousAccessPolicyResponse");
    private final static QName _DeleteStringSearchPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "deleteStringSearchPattern");
    private final static QName _UpdateCodeLabelOption_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateCodeLabelOption");
    private final static QName _UpdateRapidIdConfiguration_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateRapidIdConfiguration");
    private final static QName _ResetFileDiscoveryPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "resetFileDiscoveryPattern");
    private final static QName _CreateRapidIdConfigurationResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "createRapidIdConfigurationResponse");
    private final static QName _GetStringSearchPatternByName_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getStringSearchPatternByName");
    private final static QName _GetRapidIdentificationOptionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRapidIdentificationOptionResponse");
    private final static QName _SetDefaultOpenSourceLicenseResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "setDefaultOpenSourceLicenseResponse");
    private final static QName _GetFileDiscoveryPatternByPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getFileDiscoveryPatternByPattern");
    private final static QName _GetRapidIdentificationOption_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRapidIdentificationOption");
    private final static QName _UpdateProjectSynchronizationOptionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateProjectSynchronizationOptionResponse");
    private final static QName _AssociateRapidIdConfiguration_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "associateRapidIdConfiguration");
    private final static QName _UpdateCodeLabelOptionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateCodeLabelOptionResponse");
    private final static QName _DissociateRapidIdConfigurationResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "dissociateRapidIdConfigurationResponse");
    private final static QName _GetAnalysisDatabaseOptions_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getAnalysisDatabaseOptions");
    private final static QName _GetLearnedIdentifications_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getLearnedIdentifications");
    private final static QName _GetRapidIdConfigurationsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRapidIdConfigurationsResponse");
    private final static QName _GetRapidIdConfigurationByIdResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRapidIdConfigurationByIdResponse");
    private final static QName _ResetFileDiscoveryPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "resetFileDiscoveryPatternResponse");
    private final static QName _GetDefaultProprietaryLicenseResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getDefaultProprietaryLicenseResponse");
    private final static QName _SetDefaultProprietaryLicenseResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "setDefaultProprietaryLicenseResponse");
    private final static QName _SuggestStringSearchPatternsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "suggestStringSearchPatternsResponse");
    private final static QName _GetDefaultProprietaryLicense_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getDefaultProprietaryLicense");
    private final static QName _GetServerFileAccessOption_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getServerFileAccessOption");
    private final static QName _GetCodeLabelOptionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getCodeLabelOptionResponse");
    private final static QName _SetDefaultProprietaryLicense_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "setDefaultProprietaryLicense");
    private final static QName _UpdateServerFileAccessOption_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateServerFileAccessOption");
    private final static QName _CreateStringSearchPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "createStringSearchPattern");
    private final static QName _DeleteStringSearchPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "deleteStringSearchPatternResponse");
    private final static QName _GetRapidIdConfigurationByNameResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRapidIdConfigurationByNameResponse");
    private final static QName _GetIdentificationOptionsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getIdentificationOptionsResponse");
    private final static QName _GetRegistrationLinkOption_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRegistrationLinkOption");
    private final static QName _GetCaptureOptions_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getCaptureOptions");
    private final static QName _GetRegistrationLinkOptionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getRegistrationLinkOptionResponse");
    private final static QName _GetSystemInformation_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getSystemInformation");
    private final static QName _UpdateAnonymousAccessPolicy_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateAnonymousAccessPolicy");
    private final static QName _DeleteFileDiscoveryPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "deleteFileDiscoveryPattern");
    private final static QName _UpdateProjectSynchronizationOption_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateProjectSynchronizationOption");
    private final static QName _SuggestFileDiscoveryPatterns_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "suggestFileDiscoveryPatterns");
    private final static QName _UpdateServerFileAccessOptionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateServerFileAccessOptionResponse");
    private final static QName _RemoveLearnedIdentification_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "removeLearnedIdentification");
    private final static QName _GetFileDiscoveryPatternByPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getFileDiscoveryPatternByPatternResponse");
    private final static QName _GetSystemInformationResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getSystemInformationResponse");
    private final static QName _GetStringSearchPatternByNameResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getStringSearchPatternByNameResponse");
    private final static QName _GetServerFileAccessOptionResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getServerFileAccessOptionResponse");
    private final static QName _GetCodeLabelOption_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getCodeLabelOption");
    private final static QName _GetFileDiscoveryPatterns_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getFileDiscoveryPatterns");
    private final static QName _SuggestStringSearchPatterns_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "suggestStringSearchPatterns");
    private final static QName _CreateFileDiscoveryPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "createFileDiscoveryPatternResponse");
    private final static QName _SetDefaultOpenSourceLicense_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "setDefaultOpenSourceLicense");
    private final static QName _UpdateStringSearchPattern_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateStringSearchPattern");
    private final static QName _GetStringSearchPatternsByType_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getStringSearchPatternsByType");
    private final static QName _DissociateRapidIdConfiguration_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "dissociateRapidIdConfiguration");
    private final static QName _UpdateRapidIdConfigurationResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateRapidIdConfigurationResponse");
    private final static QName _UpdateStringSearchPatternResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "updateStringSearchPatternResponse");
    private final static QName _GetCaptureOptionsResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getCaptureOptionsResponse");
    private final static QName _DeleteRapidIdConfigurationResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "deleteRapidIdConfigurationResponse");
    private final static QName _GetStringSearchPatternById_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getStringSearchPatternById");
    private final static QName _GetStringSearchPatternByIdResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:policy", "getStringSearchPatternByIdResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.blackducksoftware.sdk.protex.policy
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link UpdateCodeLabelOptionResponse }
     * 
     */
    public UpdateCodeLabelOptionResponse createUpdateCodeLabelOptionResponse() {
        return new UpdateCodeLabelOptionResponse();
    }

    /**
     * Create an instance of {@link DissociateRapidIdConfigurationResponse }
     * 
     */
    public DissociateRapidIdConfigurationResponse createDissociateRapidIdConfigurationResponse() {
        return new DissociateRapidIdConfigurationResponse();
    }

    /**
     * Create an instance of {@link GetLearnedIdentifications }
     * 
     */
    public GetLearnedIdentifications createGetLearnedIdentifications() {
        return new GetLearnedIdentifications();
    }

    /**
     * Create an instance of {@link GetAnalysisDatabaseOptions }
     * 
     */
    public GetAnalysisDatabaseOptions createGetAnalysisDatabaseOptions() {
        return new GetAnalysisDatabaseOptions();
    }

    /**
     * Create an instance of {@link GetRapidIdConfigurationByIdResponse }
     * 
     */
    public GetRapidIdConfigurationByIdResponse createGetRapidIdConfigurationByIdResponse() {
        return new GetRapidIdConfigurationByIdResponse();
    }

    /**
     * Create an instance of {@link GetRapidIdConfigurationsResponse }
     * 
     */
    public GetRapidIdConfigurationsResponse createGetRapidIdConfigurationsResponse() {
        return new GetRapidIdConfigurationsResponse();
    }

    /**
     * Create an instance of {@link SetDefaultOpenSourceLicenseResponse }
     * 
     */
    public SetDefaultOpenSourceLicenseResponse createSetDefaultOpenSourceLicenseResponse() {
        return new SetDefaultOpenSourceLicenseResponse();
    }

    /**
     * Create an instance of {@link GetRapidIdentificationOption }
     * 
     */
    public GetRapidIdentificationOption createGetRapidIdentificationOption() {
        return new GetRapidIdentificationOption();
    }

    /**
     * Create an instance of {@link GetFileDiscoveryPatternByPattern }
     * 
     */
    public GetFileDiscoveryPatternByPattern createGetFileDiscoveryPatternByPattern() {
        return new GetFileDiscoveryPatternByPattern();
    }

    /**
     * Create an instance of {@link AssociateRapidIdConfiguration }
     * 
     */
    public AssociateRapidIdConfiguration createAssociateRapidIdConfiguration() {
        return new AssociateRapidIdConfiguration();
    }

    /**
     * Create an instance of {@link UpdateProjectSynchronizationOptionResponse }
     * 
     */
    public UpdateProjectSynchronizationOptionResponse createUpdateProjectSynchronizationOptionResponse() {
        return new UpdateProjectSynchronizationOptionResponse();
    }

    /**
     * Create an instance of {@link GetStringSearchPatternByName }
     * 
     */
    public GetStringSearchPatternByName createGetStringSearchPatternByName() {
        return new GetStringSearchPatternByName();
    }

    /**
     * Create an instance of {@link GetRapidIdentificationOptionResponse }
     * 
     */
    public GetRapidIdentificationOptionResponse createGetRapidIdentificationOptionResponse() {
        return new GetRapidIdentificationOptionResponse();
    }

    /**
     * Create an instance of {@link GetLearnedIdentificationsResponse }
     * 
     */
    public GetLearnedIdentificationsResponse createGetLearnedIdentificationsResponse() {
        return new GetLearnedIdentificationsResponse();
    }

    /**
     * Create an instance of {@link UpdateAnonymousAccessPolicyResponse }
     * 
     */
    public UpdateAnonymousAccessPolicyResponse createUpdateAnonymousAccessPolicyResponse() {
        return new UpdateAnonymousAccessPolicyResponse();
    }

    /**
     * Create an instance of {@link GetFileDiscoveryPatternsResponse }
     * 
     */
    public GetFileDiscoveryPatternsResponse createGetFileDiscoveryPatternsResponse() {
        return new GetFileDiscoveryPatternsResponse();
    }

    /**
     * Create an instance of {@link DeleteStringSearchPattern }
     * 
     */
    public DeleteStringSearchPattern createDeleteStringSearchPattern() {
        return new DeleteStringSearchPattern();
    }

    /**
     * Create an instance of {@link UpdateRapidIdConfiguration }
     * 
     */
    public UpdateRapidIdConfiguration createUpdateRapidIdConfiguration() {
        return new UpdateRapidIdConfiguration();
    }

    /**
     * Create an instance of {@link UpdateCodeLabelOption }
     * 
     */
    public UpdateCodeLabelOption createUpdateCodeLabelOption() {
        return new UpdateCodeLabelOption();
    }

    /**
     * Create an instance of {@link CreateRapidIdConfigurationResponse }
     * 
     */
    public CreateRapidIdConfigurationResponse createCreateRapidIdConfigurationResponse() {
        return new CreateRapidIdConfigurationResponse();
    }

    /**
     * Create an instance of {@link ResetFileDiscoveryPattern }
     * 
     */
    public ResetFileDiscoveryPattern createResetFileDiscoveryPattern() {
        return new ResetFileDiscoveryPattern();
    }

    /**
     * Create an instance of {@link UpdateRegistrationLinkOptionResponse }
     * 
     */
    public UpdateRegistrationLinkOptionResponse createUpdateRegistrationLinkOptionResponse() {
        return new UpdateRegistrationLinkOptionResponse();
    }

    /**
     * Create an instance of {@link UpdateRegistrationLinkOption }
     * 
     */
    public UpdateRegistrationLinkOption createUpdateRegistrationLinkOption() {
        return new UpdateRegistrationLinkOption();
    }

    /**
     * Create an instance of {@link GetAnonymousAccessPolicyResponse }
     * 
     */
    public GetAnonymousAccessPolicyResponse createGetAnonymousAccessPolicyResponse() {
        return new GetAnonymousAccessPolicyResponse();
    }

    /**
     * Create an instance of {@link CreateStringSearchPatternResponse }
     * 
     */
    public CreateStringSearchPatternResponse createCreateStringSearchPatternResponse() {
        return new CreateStringSearchPatternResponse();
    }

    /**
     * Create an instance of {@link GetProjectSynchronizationOption }
     * 
     */
    public GetProjectSynchronizationOption createGetProjectSynchronizationOption() {
        return new GetProjectSynchronizationOption();
    }

    /**
     * Create an instance of {@link UpdateIdentificationOptions }
     * 
     */
    public UpdateIdentificationOptions createUpdateIdentificationOptions() {
        return new UpdateIdentificationOptions();
    }

    /**
     * Create an instance of {@link SuggestFileDiscoveryPatternsResponse }
     * 
     */
    public SuggestFileDiscoveryPatternsResponse createSuggestFileDiscoveryPatternsResponse() {
        return new SuggestFileDiscoveryPatternsResponse();
    }

    /**
     * Create an instance of {@link RemoveLearnedIdentificationResponse }
     * 
     */
    public RemoveLearnedIdentificationResponse createRemoveLearnedIdentificationResponse() {
        return new RemoveLearnedIdentificationResponse();
    }

    /**
     * Create an instance of {@link GetDefaultOpenSourceLicenseResponse }
     * 
     */
    public GetDefaultOpenSourceLicenseResponse createGetDefaultOpenSourceLicenseResponse() {
        return new GetDefaultOpenSourceLicenseResponse();
    }

    /**
     * Create an instance of {@link GetDefaultOpenSourceLicense }
     * 
     */
    public GetDefaultOpenSourceLicense createGetDefaultOpenSourceLicense() {
        return new GetDefaultOpenSourceLicense();
    }

    /**
     * Create an instance of {@link GetStringSearchPatternsByTypeResponse }
     * 
     */
    public GetStringSearchPatternsByTypeResponse createGetStringSearchPatternsByTypeResponse() {
        return new GetStringSearchPatternsByTypeResponse();
    }

    /**
     * Create an instance of {@link UpdateAnalysisDatabaseOptionsResponse }
     * 
     */
    public UpdateAnalysisDatabaseOptionsResponse createUpdateAnalysisDatabaseOptionsResponse() {
        return new UpdateAnalysisDatabaseOptionsResponse();
    }

    /**
     * Create an instance of {@link UpdateAnalysisDatabaseOptions }
     * 
     */
    public UpdateAnalysisDatabaseOptions createUpdateAnalysisDatabaseOptions() {
        return new UpdateAnalysisDatabaseOptions();
    }

    /**
     * Create an instance of {@link CreateFileDiscoveryPattern }
     * 
     */
    public CreateFileDiscoveryPattern createCreateFileDiscoveryPattern() {
        return new CreateFileDiscoveryPattern();
    }

    /**
     * Create an instance of {@link AssociateRapidIdConfigurationResponse }
     * 
     */
    public AssociateRapidIdConfigurationResponse createAssociateRapidIdConfigurationResponse() {
        return new AssociateRapidIdConfigurationResponse();
    }

    /**
     * Create an instance of {@link DeleteFileDiscoveryPatternResponse }
     * 
     */
    public DeleteFileDiscoveryPatternResponse createDeleteFileDiscoveryPatternResponse() {
        return new DeleteFileDiscoveryPatternResponse();
    }

    /**
     * Create an instance of {@link UpdateRapidIdentificationOptionResponse }
     * 
     */
    public UpdateRapidIdentificationOptionResponse createUpdateRapidIdentificationOptionResponse() {
        return new UpdateRapidIdentificationOptionResponse();
    }

    /**
     * Create an instance of {@link UpdateFileDiscoveryPattern }
     * 
     */
    public UpdateFileDiscoveryPattern createUpdateFileDiscoveryPattern() {
        return new UpdateFileDiscoveryPattern();
    }

    /**
     * Create an instance of {@link GetRapidIdConfigurationById }
     * 
     */
    public GetRapidIdConfigurationById createGetRapidIdConfigurationById() {
        return new GetRapidIdConfigurationById();
    }

    /**
     * Create an instance of {@link GetProjectSynchronizationOptionResponse }
     * 
     */
    public GetProjectSynchronizationOptionResponse createGetProjectSynchronizationOptionResponse() {
        return new GetProjectSynchronizationOptionResponse();
    }

    /**
     * Create an instance of {@link GetFileDiscoveryPatternById }
     * 
     */
    public GetFileDiscoveryPatternById createGetFileDiscoveryPatternById() {
        return new GetFileDiscoveryPatternById();
    }

    /**
     * Create an instance of {@link GetRapidIdConfigurationByName }
     * 
     */
    public GetRapidIdConfigurationByName createGetRapidIdConfigurationByName() {
        return new GetRapidIdConfigurationByName();
    }

    /**
     * Create an instance of {@link GetIdentificationOptions }
     * 
     */
    public GetIdentificationOptions createGetIdentificationOptions() {
        return new GetIdentificationOptions();
    }

    /**
     * Create an instance of {@link GetRapidIdConfigurations }
     * 
     */
    public GetRapidIdConfigurations createGetRapidIdConfigurations() {
        return new GetRapidIdConfigurations();
    }

    /**
     * Create an instance of {@link GetFileDiscoveryPatternByIdResponse }
     * 
     */
    public GetFileDiscoveryPatternByIdResponse createGetFileDiscoveryPatternByIdResponse() {
        return new GetFileDiscoveryPatternByIdResponse();
    }

    /**
     * Create an instance of {@link DeleteRapidIdConfiguration }
     * 
     */
    public DeleteRapidIdConfiguration createDeleteRapidIdConfiguration() {
        return new DeleteRapidIdConfiguration();
    }

    /**
     * Create an instance of {@link GetAnalysisDatabaseOptionsResponse }
     * 
     */
    public GetAnalysisDatabaseOptionsResponse createGetAnalysisDatabaseOptionsResponse() {
        return new GetAnalysisDatabaseOptionsResponse();
    }

    /**
     * Create an instance of {@link GetAnonymousAccessPolicy }
     * 
     */
    public GetAnonymousAccessPolicy createGetAnonymousAccessPolicy() {
        return new GetAnonymousAccessPolicy();
    }

    /**
     * Create an instance of {@link CreateRapidIdConfiguration }
     * 
     */
    public CreateRapidIdConfiguration createCreateRapidIdConfiguration() {
        return new CreateRapidIdConfiguration();
    }

    /**
     * Create an instance of {@link UpdateIdentificationOptionsResponse }
     * 
     */
    public UpdateIdentificationOptionsResponse createUpdateIdentificationOptionsResponse() {
        return new UpdateIdentificationOptionsResponse();
    }

    /**
     * Create an instance of {@link GetRapidIdConfigurationAssociations }
     * 
     */
    public GetRapidIdConfigurationAssociations createGetRapidIdConfigurationAssociations() {
        return new GetRapidIdConfigurationAssociations();
    }

    /**
     * Create an instance of {@link UpdateFileDiscoveryPatternResponse }
     * 
     */
    public UpdateFileDiscoveryPatternResponse createUpdateFileDiscoveryPatternResponse() {
        return new UpdateFileDiscoveryPatternResponse();
    }

    /**
     * Create an instance of {@link UpdateCaptureOptions }
     * 
     */
    public UpdateCaptureOptions createUpdateCaptureOptions() {
        return new UpdateCaptureOptions();
    }

    /**
     * Create an instance of {@link UpdateCaptureOptionsResponse }
     * 
     */
    public UpdateCaptureOptionsResponse createUpdateCaptureOptionsResponse() {
        return new UpdateCaptureOptionsResponse();
    }

    /**
     * Create an instance of {@link UpdateRapidIdentificationOption }
     * 
     */
    public UpdateRapidIdentificationOption createUpdateRapidIdentificationOption() {
        return new UpdateRapidIdentificationOption();
    }

    /**
     * Create an instance of {@link GetRapidIdConfigurationAssociationsResponse }
     * 
     */
    public GetRapidIdConfigurationAssociationsResponse createGetRapidIdConfigurationAssociationsResponse() {
        return new GetRapidIdConfigurationAssociationsResponse();
    }

    /**
     * Create an instance of {@link UpdateRapidIdConfigurationResponse }
     * 
     */
    public UpdateRapidIdConfigurationResponse createUpdateRapidIdConfigurationResponse() {
        return new UpdateRapidIdConfigurationResponse();
    }

    /**
     * Create an instance of {@link GetCaptureOptionsResponse }
     * 
     */
    public GetCaptureOptionsResponse createGetCaptureOptionsResponse() {
        return new GetCaptureOptionsResponse();
    }

    /**
     * Create an instance of {@link UpdateStringSearchPatternResponse }
     * 
     */
    public UpdateStringSearchPatternResponse createUpdateStringSearchPatternResponse() {
        return new UpdateStringSearchPatternResponse();
    }

    /**
     * Create an instance of {@link GetStringSearchPatternById }
     * 
     */
    public GetStringSearchPatternById createGetStringSearchPatternById() {
        return new GetStringSearchPatternById();
    }

    /**
     * Create an instance of {@link DeleteRapidIdConfigurationResponse }
     * 
     */
    public DeleteRapidIdConfigurationResponse createDeleteRapidIdConfigurationResponse() {
        return new DeleteRapidIdConfigurationResponse();
    }

    /**
     * Create an instance of {@link GetStringSearchPatternByIdResponse }
     * 
     */
    public GetStringSearchPatternByIdResponse createGetStringSearchPatternByIdResponse() {
        return new GetStringSearchPatternByIdResponse();
    }

    /**
     * Create an instance of {@link SetDefaultOpenSourceLicense }
     * 
     */
    public SetDefaultOpenSourceLicense createSetDefaultOpenSourceLicense() {
        return new SetDefaultOpenSourceLicense();
    }

    /**
     * Create an instance of {@link UpdateStringSearchPattern }
     * 
     */
    public UpdateStringSearchPattern createUpdateStringSearchPattern() {
        return new UpdateStringSearchPattern();
    }

    /**
     * Create an instance of {@link GetStringSearchPatternsByType }
     * 
     */
    public GetStringSearchPatternsByType createGetStringSearchPatternsByType() {
        return new GetStringSearchPatternsByType();
    }

    /**
     * Create an instance of {@link DissociateRapidIdConfiguration }
     * 
     */
    public DissociateRapidIdConfiguration createDissociateRapidIdConfiguration() {
        return new DissociateRapidIdConfiguration();
    }

    /**
     * Create an instance of {@link GetStringSearchPatternByNameResponse }
     * 
     */
    public GetStringSearchPatternByNameResponse createGetStringSearchPatternByNameResponse() {
        return new GetStringSearchPatternByNameResponse();
    }

    /**
     * Create an instance of {@link GetServerFileAccessOptionResponse }
     * 
     */
    public GetServerFileAccessOptionResponse createGetServerFileAccessOptionResponse() {
        return new GetServerFileAccessOptionResponse();
    }

    /**
     * Create an instance of {@link GetCodeLabelOption }
     * 
     */
    public GetCodeLabelOption createGetCodeLabelOption() {
        return new GetCodeLabelOption();
    }

    /**
     * Create an instance of {@link GetFileDiscoveryPatterns }
     * 
     */
    public GetFileDiscoveryPatterns createGetFileDiscoveryPatterns() {
        return new GetFileDiscoveryPatterns();
    }

    /**
     * Create an instance of {@link SuggestStringSearchPatterns }
     * 
     */
    public SuggestStringSearchPatterns createSuggestStringSearchPatterns() {
        return new SuggestStringSearchPatterns();
    }

    /**
     * Create an instance of {@link CreateFileDiscoveryPatternResponse }
     * 
     */
    public CreateFileDiscoveryPatternResponse createCreateFileDiscoveryPatternResponse() {
        return new CreateFileDiscoveryPatternResponse();
    }

    /**
     * Create an instance of {@link UpdateServerFileAccessOptionResponse }
     * 
     */
    public UpdateServerFileAccessOptionResponse createUpdateServerFileAccessOptionResponse() {
        return new UpdateServerFileAccessOptionResponse();
    }

    /**
     * Create an instance of {@link SuggestFileDiscoveryPatterns }
     * 
     */
    public SuggestFileDiscoveryPatterns createSuggestFileDiscoveryPatterns() {
        return new SuggestFileDiscoveryPatterns();
    }

    /**
     * Create an instance of {@link RemoveLearnedIdentification }
     * 
     */
    public RemoveLearnedIdentification createRemoveLearnedIdentification() {
        return new RemoveLearnedIdentification();
    }

    /**
     * Create an instance of {@link GetSystemInformationResponse }
     * 
     */
    public GetSystemInformationResponse createGetSystemInformationResponse() {
        return new GetSystemInformationResponse();
    }

    /**
     * Create an instance of {@link GetFileDiscoveryPatternByPatternResponse }
     * 
     */
    public GetFileDiscoveryPatternByPatternResponse createGetFileDiscoveryPatternByPatternResponse() {
        return new GetFileDiscoveryPatternByPatternResponse();
    }

    /**
     * Create an instance of {@link GetCaptureOptions }
     * 
     */
    public GetCaptureOptions createGetCaptureOptions() {
        return new GetCaptureOptions();
    }

    /**
     * Create an instance of {@link GetRegistrationLinkOption }
     * 
     */
    public GetRegistrationLinkOption createGetRegistrationLinkOption() {
        return new GetRegistrationLinkOption();
    }

    /**
     * Create an instance of {@link GetRegistrationLinkOptionResponse }
     * 
     */
    public GetRegistrationLinkOptionResponse createGetRegistrationLinkOptionResponse() {
        return new GetRegistrationLinkOptionResponse();
    }

    /**
     * Create an instance of {@link GetSystemInformation }
     * 
     */
    public GetSystemInformation createGetSystemInformation() {
        return new GetSystemInformation();
    }

    /**
     * Create an instance of {@link UpdateAnonymousAccessPolicy }
     * 
     */
    public UpdateAnonymousAccessPolicy createUpdateAnonymousAccessPolicy() {
        return new UpdateAnonymousAccessPolicy();
    }

    /**
     * Create an instance of {@link DeleteFileDiscoveryPattern }
     * 
     */
    public DeleteFileDiscoveryPattern createDeleteFileDiscoveryPattern() {
        return new DeleteFileDiscoveryPattern();
    }

    /**
     * Create an instance of {@link UpdateProjectSynchronizationOption }
     * 
     */
    public UpdateProjectSynchronizationOption createUpdateProjectSynchronizationOption() {
        return new UpdateProjectSynchronizationOption();
    }

    /**
     * Create an instance of {@link CreateStringSearchPattern }
     * 
     */
    public CreateStringSearchPattern createCreateStringSearchPattern() {
        return new CreateStringSearchPattern();
    }

    /**
     * Create an instance of {@link DeleteStringSearchPatternResponse }
     * 
     */
    public DeleteStringSearchPatternResponse createDeleteStringSearchPatternResponse() {
        return new DeleteStringSearchPatternResponse();
    }

    /**
     * Create an instance of {@link UpdateServerFileAccessOption }
     * 
     */
    public UpdateServerFileAccessOption createUpdateServerFileAccessOption() {
        return new UpdateServerFileAccessOption();
    }

    /**
     * Create an instance of {@link GetRapidIdConfigurationByNameResponse }
     * 
     */
    public GetRapidIdConfigurationByNameResponse createGetRapidIdConfigurationByNameResponse() {
        return new GetRapidIdConfigurationByNameResponse();
    }

    /**
     * Create an instance of {@link GetIdentificationOptionsResponse }
     * 
     */
    public GetIdentificationOptionsResponse createGetIdentificationOptionsResponse() {
        return new GetIdentificationOptionsResponse();
    }

    /**
     * Create an instance of {@link GetCodeLabelOptionResponse }
     * 
     */
    public GetCodeLabelOptionResponse createGetCodeLabelOptionResponse() {
        return new GetCodeLabelOptionResponse();
    }

    /**
     * Create an instance of {@link SetDefaultProprietaryLicense }
     * 
     */
    public SetDefaultProprietaryLicense createSetDefaultProprietaryLicense() {
        return new SetDefaultProprietaryLicense();
    }

    /**
     * Create an instance of {@link ResetFileDiscoveryPatternResponse }
     * 
     */
    public ResetFileDiscoveryPatternResponse createResetFileDiscoveryPatternResponse() {
        return new ResetFileDiscoveryPatternResponse();
    }

    /**
     * Create an instance of {@link GetDefaultProprietaryLicenseResponse }
     * 
     */
    public GetDefaultProprietaryLicenseResponse createGetDefaultProprietaryLicenseResponse() {
        return new GetDefaultProprietaryLicenseResponse();
    }

    /**
     * Create an instance of {@link GetDefaultProprietaryLicense }
     * 
     */
    public GetDefaultProprietaryLicense createGetDefaultProprietaryLicense() {
        return new GetDefaultProprietaryLicense();
    }

    /**
     * Create an instance of {@link SuggestStringSearchPatternsResponse }
     * 
     */
    public SuggestStringSearchPatternsResponse createSuggestStringSearchPatternsResponse() {
        return new SuggestStringSearchPatternsResponse();
    }

    /**
     * Create an instance of {@link SetDefaultProprietaryLicenseResponse }
     * 
     */
    public SetDefaultProprietaryLicenseResponse createSetDefaultProprietaryLicenseResponse() {
        return new SetDefaultProprietaryLicenseResponse();
    }

    /**
     * Create an instance of {@link GetServerFileAccessOption }
     * 
     */
    public GetServerFileAccessOption createGetServerFileAccessOption() {
        return new GetServerFileAccessOption();
    }

    /**
     * Create an instance of {@link ProtexSystemInformation }
     * 
     */
    public ProtexSystemInformation createProtexSystemInformation() {
        return new ProtexSystemInformation();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateRapidIdConfiguration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "createRapidIdConfiguration")
    public JAXBElement<CreateRapidIdConfiguration> createCreateRapidIdConfiguration(CreateRapidIdConfiguration value) {
        return new JAXBElement<CreateRapidIdConfiguration>(_CreateRapidIdConfiguration_QNAME, CreateRapidIdConfiguration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRapidIdConfigurationAssociations }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRapidIdConfigurationAssociations")
    public JAXBElement<GetRapidIdConfigurationAssociations> createGetRapidIdConfigurationAssociations(GetRapidIdConfigurationAssociations value) {
        return new JAXBElement<GetRapidIdConfigurationAssociations>(_GetRapidIdConfigurationAssociations_QNAME, GetRapidIdConfigurationAssociations.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateIdentificationOptionsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateIdentificationOptionsResponse")
    public JAXBElement<UpdateIdentificationOptionsResponse> createUpdateIdentificationOptionsResponse(UpdateIdentificationOptionsResponse value) {
        return new JAXBElement<UpdateIdentificationOptionsResponse>(_UpdateIdentificationOptionsResponse_QNAME, UpdateIdentificationOptionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateFileDiscoveryPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateFileDiscoveryPatternResponse")
    public JAXBElement<UpdateFileDiscoveryPatternResponse> createUpdateFileDiscoveryPatternResponse(UpdateFileDiscoveryPatternResponse value) {
        return new JAXBElement<UpdateFileDiscoveryPatternResponse>(_UpdateFileDiscoveryPatternResponse_QNAME, UpdateFileDiscoveryPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateCaptureOptionsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateCaptureOptionsResponse")
    public JAXBElement<UpdateCaptureOptionsResponse> createUpdateCaptureOptionsResponse(UpdateCaptureOptionsResponse value) {
        return new JAXBElement<UpdateCaptureOptionsResponse>(_UpdateCaptureOptionsResponse_QNAME, UpdateCaptureOptionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateCaptureOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateCaptureOptions")
    public JAXBElement<UpdateCaptureOptions> createUpdateCaptureOptions(UpdateCaptureOptions value) {
        return new JAXBElement<UpdateCaptureOptions>(_UpdateCaptureOptions_QNAME, UpdateCaptureOptions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRapidIdConfigurationAssociationsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRapidIdConfigurationAssociationsResponse")
    public JAXBElement<GetRapidIdConfigurationAssociationsResponse> createGetRapidIdConfigurationAssociationsResponse(GetRapidIdConfigurationAssociationsResponse value) {
        return new JAXBElement<GetRapidIdConfigurationAssociationsResponse>(_GetRapidIdConfigurationAssociationsResponse_QNAME, GetRapidIdConfigurationAssociationsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateRapidIdentificationOption }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateRapidIdentificationOption")
    public JAXBElement<UpdateRapidIdentificationOption> createUpdateRapidIdentificationOption(UpdateRapidIdentificationOption value) {
        return new JAXBElement<UpdateRapidIdentificationOption>(_UpdateRapidIdentificationOption_QNAME, UpdateRapidIdentificationOption.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateFileDiscoveryPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateFileDiscoveryPattern")
    public JAXBElement<UpdateFileDiscoveryPattern> createUpdateFileDiscoveryPattern(UpdateFileDiscoveryPattern value) {
        return new JAXBElement<UpdateFileDiscoveryPattern>(_UpdateFileDiscoveryPattern_QNAME, UpdateFileDiscoveryPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetProjectSynchronizationOptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getProjectSynchronizationOptionResponse")
    public JAXBElement<GetProjectSynchronizationOptionResponse> createGetProjectSynchronizationOptionResponse(GetProjectSynchronizationOptionResponse value) {
        return new JAXBElement<GetProjectSynchronizationOptionResponse>(_GetProjectSynchronizationOptionResponse_QNAME, GetProjectSynchronizationOptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRapidIdConfigurationById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRapidIdConfigurationById")
    public JAXBElement<GetRapidIdConfigurationById> createGetRapidIdConfigurationById(GetRapidIdConfigurationById value) {
        return new JAXBElement<GetRapidIdConfigurationById>(_GetRapidIdConfigurationById_QNAME, GetRapidIdConfigurationById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRapidIdConfigurationByName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRapidIdConfigurationByName")
    public JAXBElement<GetRapidIdConfigurationByName> createGetRapidIdConfigurationByName(GetRapidIdConfigurationByName value) {
        return new JAXBElement<GetRapidIdConfigurationByName>(_GetRapidIdConfigurationByName_QNAME, GetRapidIdConfigurationByName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileDiscoveryPatternById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getFileDiscoveryPatternById")
    public JAXBElement<GetFileDiscoveryPatternById> createGetFileDiscoveryPatternById(GetFileDiscoveryPatternById value) {
        return new JAXBElement<GetFileDiscoveryPatternById>(_GetFileDiscoveryPatternById_QNAME, GetFileDiscoveryPatternById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetIdentificationOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getIdentificationOptions")
    public JAXBElement<GetIdentificationOptions> createGetIdentificationOptions(GetIdentificationOptions value) {
        return new JAXBElement<GetIdentificationOptions>(_GetIdentificationOptions_QNAME, GetIdentificationOptions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileDiscoveryPatternByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getFileDiscoveryPatternByIdResponse")
    public JAXBElement<GetFileDiscoveryPatternByIdResponse> createGetFileDiscoveryPatternByIdResponse(GetFileDiscoveryPatternByIdResponse value) {
        return new JAXBElement<GetFileDiscoveryPatternByIdResponse>(_GetFileDiscoveryPatternByIdResponse_QNAME, GetFileDiscoveryPatternByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteRapidIdConfiguration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "deleteRapidIdConfiguration")
    public JAXBElement<DeleteRapidIdConfiguration> createDeleteRapidIdConfiguration(DeleteRapidIdConfiguration value) {
        return new JAXBElement<DeleteRapidIdConfiguration>(_DeleteRapidIdConfiguration_QNAME, DeleteRapidIdConfiguration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRapidIdConfigurations }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRapidIdConfigurations")
    public JAXBElement<GetRapidIdConfigurations> createGetRapidIdConfigurations(GetRapidIdConfigurations value) {
        return new JAXBElement<GetRapidIdConfigurations>(_GetRapidIdConfigurations_QNAME, GetRapidIdConfigurations.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAnonymousAccessPolicy }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getAnonymousAccessPolicy")
    public JAXBElement<GetAnonymousAccessPolicy> createGetAnonymousAccessPolicy(GetAnonymousAccessPolicy value) {
        return new JAXBElement<GetAnonymousAccessPolicy>(_GetAnonymousAccessPolicy_QNAME, GetAnonymousAccessPolicy.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAnalysisDatabaseOptionsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getAnalysisDatabaseOptionsResponse")
    public JAXBElement<GetAnalysisDatabaseOptionsResponse> createGetAnalysisDatabaseOptionsResponse(GetAnalysisDatabaseOptionsResponse value) {
        return new JAXBElement<GetAnalysisDatabaseOptionsResponse>(_GetAnalysisDatabaseOptionsResponse_QNAME, GetAnalysisDatabaseOptionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveLearnedIdentificationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "removeLearnedIdentificationResponse")
    public JAXBElement<RemoveLearnedIdentificationResponse> createRemoveLearnedIdentificationResponse(RemoveLearnedIdentificationResponse value) {
        return new JAXBElement<RemoveLearnedIdentificationResponse>(_RemoveLearnedIdentificationResponse_QNAME, RemoveLearnedIdentificationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuggestFileDiscoveryPatternsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "suggestFileDiscoveryPatternsResponse")
    public JAXBElement<SuggestFileDiscoveryPatternsResponse> createSuggestFileDiscoveryPatternsResponse(SuggestFileDiscoveryPatternsResponse value) {
        return new JAXBElement<SuggestFileDiscoveryPatternsResponse>(_SuggestFileDiscoveryPatternsResponse_QNAME, SuggestFileDiscoveryPatternsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAnalysisDatabaseOptionsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateAnalysisDatabaseOptionsResponse")
    public JAXBElement<UpdateAnalysisDatabaseOptionsResponse> createUpdateAnalysisDatabaseOptionsResponse(UpdateAnalysisDatabaseOptionsResponse value) {
        return new JAXBElement<UpdateAnalysisDatabaseOptionsResponse>(_UpdateAnalysisDatabaseOptionsResponse_QNAME, UpdateAnalysisDatabaseOptionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStringSearchPatternsByTypeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getStringSearchPatternsByTypeResponse")
    public JAXBElement<GetStringSearchPatternsByTypeResponse> createGetStringSearchPatternsByTypeResponse(GetStringSearchPatternsByTypeResponse value) {
        return new JAXBElement<GetStringSearchPatternsByTypeResponse>(_GetStringSearchPatternsByTypeResponse_QNAME, GetStringSearchPatternsByTypeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDefaultOpenSourceLicense }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getDefaultOpenSourceLicense")
    public JAXBElement<GetDefaultOpenSourceLicense> createGetDefaultOpenSourceLicense(GetDefaultOpenSourceLicense value) {
        return new JAXBElement<GetDefaultOpenSourceLicense>(_GetDefaultOpenSourceLicense_QNAME, GetDefaultOpenSourceLicense.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDefaultOpenSourceLicenseResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getDefaultOpenSourceLicenseResponse")
    public JAXBElement<GetDefaultOpenSourceLicenseResponse> createGetDefaultOpenSourceLicenseResponse(GetDefaultOpenSourceLicenseResponse value) {
        return new JAXBElement<GetDefaultOpenSourceLicenseResponse>(_GetDefaultOpenSourceLicenseResponse_QNAME, GetDefaultOpenSourceLicenseResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAnalysisDatabaseOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateAnalysisDatabaseOptions")
    public JAXBElement<UpdateAnalysisDatabaseOptions> createUpdateAnalysisDatabaseOptions(UpdateAnalysisDatabaseOptions value) {
        return new JAXBElement<UpdateAnalysisDatabaseOptions>(_UpdateAnalysisDatabaseOptions_QNAME, UpdateAnalysisDatabaseOptions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssociateRapidIdConfigurationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "associateRapidIdConfigurationResponse")
    public JAXBElement<AssociateRapidIdConfigurationResponse> createAssociateRapidIdConfigurationResponse(AssociateRapidIdConfigurationResponse value) {
        return new JAXBElement<AssociateRapidIdConfigurationResponse>(_AssociateRapidIdConfigurationResponse_QNAME, AssociateRapidIdConfigurationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateFileDiscoveryPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "createFileDiscoveryPattern")
    public JAXBElement<CreateFileDiscoveryPattern> createCreateFileDiscoveryPattern(CreateFileDiscoveryPattern value) {
        return new JAXBElement<CreateFileDiscoveryPattern>(_CreateFileDiscoveryPattern_QNAME, CreateFileDiscoveryPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateRapidIdentificationOptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateRapidIdentificationOptionResponse")
    public JAXBElement<UpdateRapidIdentificationOptionResponse> createUpdateRapidIdentificationOptionResponse(UpdateRapidIdentificationOptionResponse value) {
        return new JAXBElement<UpdateRapidIdentificationOptionResponse>(_UpdateRapidIdentificationOptionResponse_QNAME, UpdateRapidIdentificationOptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteFileDiscoveryPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "deleteFileDiscoveryPatternResponse")
    public JAXBElement<DeleteFileDiscoveryPatternResponse> createDeleteFileDiscoveryPatternResponse(DeleteFileDiscoveryPatternResponse value) {
        return new JAXBElement<DeleteFileDiscoveryPatternResponse>(_DeleteFileDiscoveryPatternResponse_QNAME, DeleteFileDiscoveryPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateRegistrationLinkOptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateRegistrationLinkOptionResponse")
    public JAXBElement<UpdateRegistrationLinkOptionResponse> createUpdateRegistrationLinkOptionResponse(UpdateRegistrationLinkOptionResponse value) {
        return new JAXBElement<UpdateRegistrationLinkOptionResponse>(_UpdateRegistrationLinkOptionResponse_QNAME, UpdateRegistrationLinkOptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateRegistrationLinkOption }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateRegistrationLinkOption")
    public JAXBElement<UpdateRegistrationLinkOption> createUpdateRegistrationLinkOption(UpdateRegistrationLinkOption value) {
        return new JAXBElement<UpdateRegistrationLinkOption>(_UpdateRegistrationLinkOption_QNAME, UpdateRegistrationLinkOption.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAnonymousAccessPolicyResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getAnonymousAccessPolicyResponse")
    public JAXBElement<GetAnonymousAccessPolicyResponse> createGetAnonymousAccessPolicyResponse(GetAnonymousAccessPolicyResponse value) {
        return new JAXBElement<GetAnonymousAccessPolicyResponse>(_GetAnonymousAccessPolicyResponse_QNAME, GetAnonymousAccessPolicyResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateStringSearchPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "createStringSearchPatternResponse")
    public JAXBElement<CreateStringSearchPatternResponse> createCreateStringSearchPatternResponse(CreateStringSearchPatternResponse value) {
        return new JAXBElement<CreateStringSearchPatternResponse>(_CreateStringSearchPatternResponse_QNAME, CreateStringSearchPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateIdentificationOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateIdentificationOptions")
    public JAXBElement<UpdateIdentificationOptions> createUpdateIdentificationOptions(UpdateIdentificationOptions value) {
        return new JAXBElement<UpdateIdentificationOptions>(_UpdateIdentificationOptions_QNAME, UpdateIdentificationOptions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetProjectSynchronizationOption }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getProjectSynchronizationOption")
    public JAXBElement<GetProjectSynchronizationOption> createGetProjectSynchronizationOption(GetProjectSynchronizationOption value) {
        return new JAXBElement<GetProjectSynchronizationOption>(_GetProjectSynchronizationOption_QNAME, GetProjectSynchronizationOption.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileDiscoveryPatternsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getFileDiscoveryPatternsResponse")
    public JAXBElement<GetFileDiscoveryPatternsResponse> createGetFileDiscoveryPatternsResponse(GetFileDiscoveryPatternsResponse value) {
        return new JAXBElement<GetFileDiscoveryPatternsResponse>(_GetFileDiscoveryPatternsResponse_QNAME, GetFileDiscoveryPatternsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLearnedIdentificationsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getLearnedIdentificationsResponse")
    public JAXBElement<GetLearnedIdentificationsResponse> createGetLearnedIdentificationsResponse(GetLearnedIdentificationsResponse value) {
        return new JAXBElement<GetLearnedIdentificationsResponse>(_GetLearnedIdentificationsResponse_QNAME, GetLearnedIdentificationsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAnonymousAccessPolicyResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateAnonymousAccessPolicyResponse")
    public JAXBElement<UpdateAnonymousAccessPolicyResponse> createUpdateAnonymousAccessPolicyResponse(UpdateAnonymousAccessPolicyResponse value) {
        return new JAXBElement<UpdateAnonymousAccessPolicyResponse>(_UpdateAnonymousAccessPolicyResponse_QNAME, UpdateAnonymousAccessPolicyResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteStringSearchPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "deleteStringSearchPattern")
    public JAXBElement<DeleteStringSearchPattern> createDeleteStringSearchPattern(DeleteStringSearchPattern value) {
        return new JAXBElement<DeleteStringSearchPattern>(_DeleteStringSearchPattern_QNAME, DeleteStringSearchPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateCodeLabelOption }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateCodeLabelOption")
    public JAXBElement<UpdateCodeLabelOption> createUpdateCodeLabelOption(UpdateCodeLabelOption value) {
        return new JAXBElement<UpdateCodeLabelOption>(_UpdateCodeLabelOption_QNAME, UpdateCodeLabelOption.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateRapidIdConfiguration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateRapidIdConfiguration")
    public JAXBElement<UpdateRapidIdConfiguration> createUpdateRapidIdConfiguration(UpdateRapidIdConfiguration value) {
        return new JAXBElement<UpdateRapidIdConfiguration>(_UpdateRapidIdConfiguration_QNAME, UpdateRapidIdConfiguration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResetFileDiscoveryPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "resetFileDiscoveryPattern")
    public JAXBElement<ResetFileDiscoveryPattern> createResetFileDiscoveryPattern(ResetFileDiscoveryPattern value) {
        return new JAXBElement<ResetFileDiscoveryPattern>(_ResetFileDiscoveryPattern_QNAME, ResetFileDiscoveryPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateRapidIdConfigurationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "createRapidIdConfigurationResponse")
    public JAXBElement<CreateRapidIdConfigurationResponse> createCreateRapidIdConfigurationResponse(CreateRapidIdConfigurationResponse value) {
        return new JAXBElement<CreateRapidIdConfigurationResponse>(_CreateRapidIdConfigurationResponse_QNAME, CreateRapidIdConfigurationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStringSearchPatternByName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getStringSearchPatternByName")
    public JAXBElement<GetStringSearchPatternByName> createGetStringSearchPatternByName(GetStringSearchPatternByName value) {
        return new JAXBElement<GetStringSearchPatternByName>(_GetStringSearchPatternByName_QNAME, GetStringSearchPatternByName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRapidIdentificationOptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRapidIdentificationOptionResponse")
    public JAXBElement<GetRapidIdentificationOptionResponse> createGetRapidIdentificationOptionResponse(GetRapidIdentificationOptionResponse value) {
        return new JAXBElement<GetRapidIdentificationOptionResponse>(_GetRapidIdentificationOptionResponse_QNAME, GetRapidIdentificationOptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetDefaultOpenSourceLicenseResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "setDefaultOpenSourceLicenseResponse")
    public JAXBElement<SetDefaultOpenSourceLicenseResponse> createSetDefaultOpenSourceLicenseResponse(SetDefaultOpenSourceLicenseResponse value) {
        return new JAXBElement<SetDefaultOpenSourceLicenseResponse>(_SetDefaultOpenSourceLicenseResponse_QNAME, SetDefaultOpenSourceLicenseResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileDiscoveryPatternByPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getFileDiscoveryPatternByPattern")
    public JAXBElement<GetFileDiscoveryPatternByPattern> createGetFileDiscoveryPatternByPattern(GetFileDiscoveryPatternByPattern value) {
        return new JAXBElement<GetFileDiscoveryPatternByPattern>(_GetFileDiscoveryPatternByPattern_QNAME, GetFileDiscoveryPatternByPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRapidIdentificationOption }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRapidIdentificationOption")
    public JAXBElement<GetRapidIdentificationOption> createGetRapidIdentificationOption(GetRapidIdentificationOption value) {
        return new JAXBElement<GetRapidIdentificationOption>(_GetRapidIdentificationOption_QNAME, GetRapidIdentificationOption.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateProjectSynchronizationOptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateProjectSynchronizationOptionResponse")
    public JAXBElement<UpdateProjectSynchronizationOptionResponse> createUpdateProjectSynchronizationOptionResponse(UpdateProjectSynchronizationOptionResponse value) {
        return new JAXBElement<UpdateProjectSynchronizationOptionResponse>(_UpdateProjectSynchronizationOptionResponse_QNAME, UpdateProjectSynchronizationOptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AssociateRapidIdConfiguration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "associateRapidIdConfiguration")
    public JAXBElement<AssociateRapidIdConfiguration> createAssociateRapidIdConfiguration(AssociateRapidIdConfiguration value) {
        return new JAXBElement<AssociateRapidIdConfiguration>(_AssociateRapidIdConfiguration_QNAME, AssociateRapidIdConfiguration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateCodeLabelOptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateCodeLabelOptionResponse")
    public JAXBElement<UpdateCodeLabelOptionResponse> createUpdateCodeLabelOptionResponse(UpdateCodeLabelOptionResponse value) {
        return new JAXBElement<UpdateCodeLabelOptionResponse>(_UpdateCodeLabelOptionResponse_QNAME, UpdateCodeLabelOptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DissociateRapidIdConfigurationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "dissociateRapidIdConfigurationResponse")
    public JAXBElement<DissociateRapidIdConfigurationResponse> createDissociateRapidIdConfigurationResponse(DissociateRapidIdConfigurationResponse value) {
        return new JAXBElement<DissociateRapidIdConfigurationResponse>(_DissociateRapidIdConfigurationResponse_QNAME, DissociateRapidIdConfigurationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetAnalysisDatabaseOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getAnalysisDatabaseOptions")
    public JAXBElement<GetAnalysisDatabaseOptions> createGetAnalysisDatabaseOptions(GetAnalysisDatabaseOptions value) {
        return new JAXBElement<GetAnalysisDatabaseOptions>(_GetAnalysisDatabaseOptions_QNAME, GetAnalysisDatabaseOptions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetLearnedIdentifications }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getLearnedIdentifications")
    public JAXBElement<GetLearnedIdentifications> createGetLearnedIdentifications(GetLearnedIdentifications value) {
        return new JAXBElement<GetLearnedIdentifications>(_GetLearnedIdentifications_QNAME, GetLearnedIdentifications.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRapidIdConfigurationsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRapidIdConfigurationsResponse")
    public JAXBElement<GetRapidIdConfigurationsResponse> createGetRapidIdConfigurationsResponse(GetRapidIdConfigurationsResponse value) {
        return new JAXBElement<GetRapidIdConfigurationsResponse>(_GetRapidIdConfigurationsResponse_QNAME, GetRapidIdConfigurationsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRapidIdConfigurationByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRapidIdConfigurationByIdResponse")
    public JAXBElement<GetRapidIdConfigurationByIdResponse> createGetRapidIdConfigurationByIdResponse(GetRapidIdConfigurationByIdResponse value) {
        return new JAXBElement<GetRapidIdConfigurationByIdResponse>(_GetRapidIdConfigurationByIdResponse_QNAME, GetRapidIdConfigurationByIdResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ResetFileDiscoveryPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "resetFileDiscoveryPatternResponse")
    public JAXBElement<ResetFileDiscoveryPatternResponse> createResetFileDiscoveryPatternResponse(ResetFileDiscoveryPatternResponse value) {
        return new JAXBElement<ResetFileDiscoveryPatternResponse>(_ResetFileDiscoveryPatternResponse_QNAME, ResetFileDiscoveryPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDefaultProprietaryLicenseResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getDefaultProprietaryLicenseResponse")
    public JAXBElement<GetDefaultProprietaryLicenseResponse> createGetDefaultProprietaryLicenseResponse(GetDefaultProprietaryLicenseResponse value) {
        return new JAXBElement<GetDefaultProprietaryLicenseResponse>(_GetDefaultProprietaryLicenseResponse_QNAME, GetDefaultProprietaryLicenseResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetDefaultProprietaryLicenseResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "setDefaultProprietaryLicenseResponse")
    public JAXBElement<SetDefaultProprietaryLicenseResponse> createSetDefaultProprietaryLicenseResponse(SetDefaultProprietaryLicenseResponse value) {
        return new JAXBElement<SetDefaultProprietaryLicenseResponse>(_SetDefaultProprietaryLicenseResponse_QNAME, SetDefaultProprietaryLicenseResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuggestStringSearchPatternsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "suggestStringSearchPatternsResponse")
    public JAXBElement<SuggestStringSearchPatternsResponse> createSuggestStringSearchPatternsResponse(SuggestStringSearchPatternsResponse value) {
        return new JAXBElement<SuggestStringSearchPatternsResponse>(_SuggestStringSearchPatternsResponse_QNAME, SuggestStringSearchPatternsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetDefaultProprietaryLicense }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getDefaultProprietaryLicense")
    public JAXBElement<GetDefaultProprietaryLicense> createGetDefaultProprietaryLicense(GetDefaultProprietaryLicense value) {
        return new JAXBElement<GetDefaultProprietaryLicense>(_GetDefaultProprietaryLicense_QNAME, GetDefaultProprietaryLicense.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetServerFileAccessOption }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getServerFileAccessOption")
    public JAXBElement<GetServerFileAccessOption> createGetServerFileAccessOption(GetServerFileAccessOption value) {
        return new JAXBElement<GetServerFileAccessOption>(_GetServerFileAccessOption_QNAME, GetServerFileAccessOption.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCodeLabelOptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getCodeLabelOptionResponse")
    public JAXBElement<GetCodeLabelOptionResponse> createGetCodeLabelOptionResponse(GetCodeLabelOptionResponse value) {
        return new JAXBElement<GetCodeLabelOptionResponse>(_GetCodeLabelOptionResponse_QNAME, GetCodeLabelOptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetDefaultProprietaryLicense }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "setDefaultProprietaryLicense")
    public JAXBElement<SetDefaultProprietaryLicense> createSetDefaultProprietaryLicense(SetDefaultProprietaryLicense value) {
        return new JAXBElement<SetDefaultProprietaryLicense>(_SetDefaultProprietaryLicense_QNAME, SetDefaultProprietaryLicense.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateServerFileAccessOption }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateServerFileAccessOption")
    public JAXBElement<UpdateServerFileAccessOption> createUpdateServerFileAccessOption(UpdateServerFileAccessOption value) {
        return new JAXBElement<UpdateServerFileAccessOption>(_UpdateServerFileAccessOption_QNAME, UpdateServerFileAccessOption.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateStringSearchPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "createStringSearchPattern")
    public JAXBElement<CreateStringSearchPattern> createCreateStringSearchPattern(CreateStringSearchPattern value) {
        return new JAXBElement<CreateStringSearchPattern>(_CreateStringSearchPattern_QNAME, CreateStringSearchPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteStringSearchPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "deleteStringSearchPatternResponse")
    public JAXBElement<DeleteStringSearchPatternResponse> createDeleteStringSearchPatternResponse(DeleteStringSearchPatternResponse value) {
        return new JAXBElement<DeleteStringSearchPatternResponse>(_DeleteStringSearchPatternResponse_QNAME, DeleteStringSearchPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRapidIdConfigurationByNameResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRapidIdConfigurationByNameResponse")
    public JAXBElement<GetRapidIdConfigurationByNameResponse> createGetRapidIdConfigurationByNameResponse(GetRapidIdConfigurationByNameResponse value) {
        return new JAXBElement<GetRapidIdConfigurationByNameResponse>(_GetRapidIdConfigurationByNameResponse_QNAME, GetRapidIdConfigurationByNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetIdentificationOptionsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getIdentificationOptionsResponse")
    public JAXBElement<GetIdentificationOptionsResponse> createGetIdentificationOptionsResponse(GetIdentificationOptionsResponse value) {
        return new JAXBElement<GetIdentificationOptionsResponse>(_GetIdentificationOptionsResponse_QNAME, GetIdentificationOptionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRegistrationLinkOption }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRegistrationLinkOption")
    public JAXBElement<GetRegistrationLinkOption> createGetRegistrationLinkOption(GetRegistrationLinkOption value) {
        return new JAXBElement<GetRegistrationLinkOption>(_GetRegistrationLinkOption_QNAME, GetRegistrationLinkOption.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaptureOptions }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getCaptureOptions")
    public JAXBElement<GetCaptureOptions> createGetCaptureOptions(GetCaptureOptions value) {
        return new JAXBElement<GetCaptureOptions>(_GetCaptureOptions_QNAME, GetCaptureOptions.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetRegistrationLinkOptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getRegistrationLinkOptionResponse")
    public JAXBElement<GetRegistrationLinkOptionResponse> createGetRegistrationLinkOptionResponse(GetRegistrationLinkOptionResponse value) {
        return new JAXBElement<GetRegistrationLinkOptionResponse>(_GetRegistrationLinkOptionResponse_QNAME, GetRegistrationLinkOptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSystemInformation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getSystemInformation")
    public JAXBElement<GetSystemInformation> createGetSystemInformation(GetSystemInformation value) {
        return new JAXBElement<GetSystemInformation>(_GetSystemInformation_QNAME, GetSystemInformation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateAnonymousAccessPolicy }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateAnonymousAccessPolicy")
    public JAXBElement<UpdateAnonymousAccessPolicy> createUpdateAnonymousAccessPolicy(UpdateAnonymousAccessPolicy value) {
        return new JAXBElement<UpdateAnonymousAccessPolicy>(_UpdateAnonymousAccessPolicy_QNAME, UpdateAnonymousAccessPolicy.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteFileDiscoveryPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "deleteFileDiscoveryPattern")
    public JAXBElement<DeleteFileDiscoveryPattern> createDeleteFileDiscoveryPattern(DeleteFileDiscoveryPattern value) {
        return new JAXBElement<DeleteFileDiscoveryPattern>(_DeleteFileDiscoveryPattern_QNAME, DeleteFileDiscoveryPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateProjectSynchronizationOption }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateProjectSynchronizationOption")
    public JAXBElement<UpdateProjectSynchronizationOption> createUpdateProjectSynchronizationOption(UpdateProjectSynchronizationOption value) {
        return new JAXBElement<UpdateProjectSynchronizationOption>(_UpdateProjectSynchronizationOption_QNAME, UpdateProjectSynchronizationOption.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuggestFileDiscoveryPatterns }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "suggestFileDiscoveryPatterns")
    public JAXBElement<SuggestFileDiscoveryPatterns> createSuggestFileDiscoveryPatterns(SuggestFileDiscoveryPatterns value) {
        return new JAXBElement<SuggestFileDiscoveryPatterns>(_SuggestFileDiscoveryPatterns_QNAME, SuggestFileDiscoveryPatterns.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateServerFileAccessOptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateServerFileAccessOptionResponse")
    public JAXBElement<UpdateServerFileAccessOptionResponse> createUpdateServerFileAccessOptionResponse(UpdateServerFileAccessOptionResponse value) {
        return new JAXBElement<UpdateServerFileAccessOptionResponse>(_UpdateServerFileAccessOptionResponse_QNAME, UpdateServerFileAccessOptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RemoveLearnedIdentification }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "removeLearnedIdentification")
    public JAXBElement<RemoveLearnedIdentification> createRemoveLearnedIdentification(RemoveLearnedIdentification value) {
        return new JAXBElement<RemoveLearnedIdentification>(_RemoveLearnedIdentification_QNAME, RemoveLearnedIdentification.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileDiscoveryPatternByPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getFileDiscoveryPatternByPatternResponse")
    public JAXBElement<GetFileDiscoveryPatternByPatternResponse> createGetFileDiscoveryPatternByPatternResponse(GetFileDiscoveryPatternByPatternResponse value) {
        return new JAXBElement<GetFileDiscoveryPatternByPatternResponse>(_GetFileDiscoveryPatternByPatternResponse_QNAME, GetFileDiscoveryPatternByPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetSystemInformationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getSystemInformationResponse")
    public JAXBElement<GetSystemInformationResponse> createGetSystemInformationResponse(GetSystemInformationResponse value) {
        return new JAXBElement<GetSystemInformationResponse>(_GetSystemInformationResponse_QNAME, GetSystemInformationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStringSearchPatternByNameResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getStringSearchPatternByNameResponse")
    public JAXBElement<GetStringSearchPatternByNameResponse> createGetStringSearchPatternByNameResponse(GetStringSearchPatternByNameResponse value) {
        return new JAXBElement<GetStringSearchPatternByNameResponse>(_GetStringSearchPatternByNameResponse_QNAME, GetStringSearchPatternByNameResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetServerFileAccessOptionResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getServerFileAccessOptionResponse")
    public JAXBElement<GetServerFileAccessOptionResponse> createGetServerFileAccessOptionResponse(GetServerFileAccessOptionResponse value) {
        return new JAXBElement<GetServerFileAccessOptionResponse>(_GetServerFileAccessOptionResponse_QNAME, GetServerFileAccessOptionResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCodeLabelOption }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getCodeLabelOption")
    public JAXBElement<GetCodeLabelOption> createGetCodeLabelOption(GetCodeLabelOption value) {
        return new JAXBElement<GetCodeLabelOption>(_GetCodeLabelOption_QNAME, GetCodeLabelOption.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetFileDiscoveryPatterns }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getFileDiscoveryPatterns")
    public JAXBElement<GetFileDiscoveryPatterns> createGetFileDiscoveryPatterns(GetFileDiscoveryPatterns value) {
        return new JAXBElement<GetFileDiscoveryPatterns>(_GetFileDiscoveryPatterns_QNAME, GetFileDiscoveryPatterns.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SuggestStringSearchPatterns }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "suggestStringSearchPatterns")
    public JAXBElement<SuggestStringSearchPatterns> createSuggestStringSearchPatterns(SuggestStringSearchPatterns value) {
        return new JAXBElement<SuggestStringSearchPatterns>(_SuggestStringSearchPatterns_QNAME, SuggestStringSearchPatterns.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateFileDiscoveryPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "createFileDiscoveryPatternResponse")
    public JAXBElement<CreateFileDiscoveryPatternResponse> createCreateFileDiscoveryPatternResponse(CreateFileDiscoveryPatternResponse value) {
        return new JAXBElement<CreateFileDiscoveryPatternResponse>(_CreateFileDiscoveryPatternResponse_QNAME, CreateFileDiscoveryPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SetDefaultOpenSourceLicense }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "setDefaultOpenSourceLicense")
    public JAXBElement<SetDefaultOpenSourceLicense> createSetDefaultOpenSourceLicense(SetDefaultOpenSourceLicense value) {
        return new JAXBElement<SetDefaultOpenSourceLicense>(_SetDefaultOpenSourceLicense_QNAME, SetDefaultOpenSourceLicense.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateStringSearchPattern }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateStringSearchPattern")
    public JAXBElement<UpdateStringSearchPattern> createUpdateStringSearchPattern(UpdateStringSearchPattern value) {
        return new JAXBElement<UpdateStringSearchPattern>(_UpdateStringSearchPattern_QNAME, UpdateStringSearchPattern.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStringSearchPatternsByType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getStringSearchPatternsByType")
    public JAXBElement<GetStringSearchPatternsByType> createGetStringSearchPatternsByType(GetStringSearchPatternsByType value) {
        return new JAXBElement<GetStringSearchPatternsByType>(_GetStringSearchPatternsByType_QNAME, GetStringSearchPatternsByType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DissociateRapidIdConfiguration }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "dissociateRapidIdConfiguration")
    public JAXBElement<DissociateRapidIdConfiguration> createDissociateRapidIdConfiguration(DissociateRapidIdConfiguration value) {
        return new JAXBElement<DissociateRapidIdConfiguration>(_DissociateRapidIdConfiguration_QNAME, DissociateRapidIdConfiguration.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateRapidIdConfigurationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateRapidIdConfigurationResponse")
    public JAXBElement<UpdateRapidIdConfigurationResponse> createUpdateRapidIdConfigurationResponse(UpdateRapidIdConfigurationResponse value) {
        return new JAXBElement<UpdateRapidIdConfigurationResponse>(_UpdateRapidIdConfigurationResponse_QNAME, UpdateRapidIdConfigurationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateStringSearchPatternResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "updateStringSearchPatternResponse")
    public JAXBElement<UpdateStringSearchPatternResponse> createUpdateStringSearchPatternResponse(UpdateStringSearchPatternResponse value) {
        return new JAXBElement<UpdateStringSearchPatternResponse>(_UpdateStringSearchPatternResponse_QNAME, UpdateStringSearchPatternResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetCaptureOptionsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getCaptureOptionsResponse")
    public JAXBElement<GetCaptureOptionsResponse> createGetCaptureOptionsResponse(GetCaptureOptionsResponse value) {
        return new JAXBElement<GetCaptureOptionsResponse>(_GetCaptureOptionsResponse_QNAME, GetCaptureOptionsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteRapidIdConfigurationResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "deleteRapidIdConfigurationResponse")
    public JAXBElement<DeleteRapidIdConfigurationResponse> createDeleteRapidIdConfigurationResponse(DeleteRapidIdConfigurationResponse value) {
        return new JAXBElement<DeleteRapidIdConfigurationResponse>(_DeleteRapidIdConfigurationResponse_QNAME, DeleteRapidIdConfigurationResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStringSearchPatternById }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getStringSearchPatternById")
    public JAXBElement<GetStringSearchPatternById> createGetStringSearchPatternById(GetStringSearchPatternById value) {
        return new JAXBElement<GetStringSearchPatternById>(_GetStringSearchPatternById_QNAME, GetStringSearchPatternById.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetStringSearchPatternByIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:policy", name = "getStringSearchPatternByIdResponse")
    public JAXBElement<GetStringSearchPatternByIdResponse> createGetStringSearchPatternByIdResponse(GetStringSearchPatternByIdResponse value) {
        return new JAXBElement<GetStringSearchPatternByIdResponse>(_GetStringSearchPatternByIdResponse_QNAME, GetStringSearchPatternByIdResponse.class, null, value);
    }

}
