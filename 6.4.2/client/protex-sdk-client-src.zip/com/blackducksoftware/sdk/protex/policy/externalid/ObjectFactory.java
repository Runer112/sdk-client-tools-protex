
package com.blackducksoftware.sdk.protex.policy.externalid;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.blackducksoftware.sdk.protex.policy.externalid package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetExternalNamespaceResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "getExternalNamespaceResponse");
    private final static QName _GetObjectIdByExternalId_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "getObjectIdByExternalId");
    private final static QName _CreateExternalIdMapping_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "createExternalIdMapping");
    private final static QName _DeleteExternalNamespaceResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "deleteExternalNamespaceResponse");
    private final static QName _CreateExternalNamespaceResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "createExternalNamespaceResponse");
    private final static QName _DeleteExternalIdMappingResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "deleteExternalIdMappingResponse");
    private final static QName _DeleteExternalIdMapping_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "deleteExternalIdMapping");
    private final static QName _CreateExternalNamespace_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "createExternalNamespace");
    private final static QName _DeleteExternalNamespace_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "deleteExternalNamespace");
    private final static QName _GetExternalNamespace_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "getExternalNamespace");
    private final static QName _CreateExternalIdMappingResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "createExternalIdMappingResponse");
    private final static QName _UpdateExternalNamespaceResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "updateExternalNamespaceResponse");
    private final static QName _UpdateExternalNamespace_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "updateExternalNamespace");
    private final static QName _GetObjectIdByExternalIdResponse_QNAME = new QName("urn:protex.blackducksoftware.com:sdk:v6.3:externalid", "getObjectIdByExternalIdResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.blackducksoftware.sdk.protex.policy.externalid
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DeleteExternalIdMappingResponse }
     * 
     */
    public DeleteExternalIdMappingResponse createDeleteExternalIdMappingResponse() {
        return new DeleteExternalIdMappingResponse();
    }

    /**
     * Create an instance of {@link DeleteExternalNamespaceResponse }
     * 
     */
    public DeleteExternalNamespaceResponse createDeleteExternalNamespaceResponse() {
        return new DeleteExternalNamespaceResponse();
    }

    /**
     * Create an instance of {@link CreateExternalNamespaceResponse }
     * 
     */
    public CreateExternalNamespaceResponse createCreateExternalNamespaceResponse() {
        return new CreateExternalNamespaceResponse();
    }

    /**
     * Create an instance of {@link DeleteExternalNamespace }
     * 
     */
    public DeleteExternalNamespace createDeleteExternalNamespace() {
        return new DeleteExternalNamespace();
    }

    /**
     * Create an instance of {@link DeleteExternalIdMapping }
     * 
     */
    public DeleteExternalIdMapping createDeleteExternalIdMapping() {
        return new DeleteExternalIdMapping();
    }

    /**
     * Create an instance of {@link CreateExternalNamespace }
     * 
     */
    public CreateExternalNamespace createCreateExternalNamespace() {
        return new CreateExternalNamespace();
    }

    /**
     * Create an instance of {@link GetExternalNamespaceResponse }
     * 
     */
    public GetExternalNamespaceResponse createGetExternalNamespaceResponse() {
        return new GetExternalNamespaceResponse();
    }

    /**
     * Create an instance of {@link GetObjectIdByExternalId }
     * 
     */
    public GetObjectIdByExternalId createGetObjectIdByExternalId() {
        return new GetObjectIdByExternalId();
    }

    /**
     * Create an instance of {@link CreateExternalIdMapping }
     * 
     */
    public CreateExternalIdMapping createCreateExternalIdMapping() {
        return new CreateExternalIdMapping();
    }

    /**
     * Create an instance of {@link UpdateExternalNamespaceResponse }
     * 
     */
    public UpdateExternalNamespaceResponse createUpdateExternalNamespaceResponse() {
        return new UpdateExternalNamespaceResponse();
    }

    /**
     * Create an instance of {@link UpdateExternalNamespace }
     * 
     */
    public UpdateExternalNamespace createUpdateExternalNamespace() {
        return new UpdateExternalNamespace();
    }

    /**
     * Create an instance of {@link CreateExternalIdMappingResponse }
     * 
     */
    public CreateExternalIdMappingResponse createCreateExternalIdMappingResponse() {
        return new CreateExternalIdMappingResponse();
    }

    /**
     * Create an instance of {@link GetObjectIdByExternalIdResponse }
     * 
     */
    public GetObjectIdByExternalIdResponse createGetObjectIdByExternalIdResponse() {
        return new GetObjectIdByExternalIdResponse();
    }

    /**
     * Create an instance of {@link GetExternalNamespace }
     * 
     */
    public GetExternalNamespace createGetExternalNamespace() {
        return new GetExternalNamespace();
    }

    /**
     * Create an instance of {@link ExternalIdMapping }
     * 
     */
    public ExternalIdMapping createExternalIdMapping() {
        return new ExternalIdMapping();
    }

    /**
     * Create an instance of {@link ExternalNamespaceUpdateRequest }
     * 
     */
    public ExternalNamespaceUpdateRequest createExternalNamespaceUpdateRequest() {
        return new ExternalNamespaceUpdateRequest();
    }

    /**
     * Create an instance of {@link ExternalNamespaceRequest }
     * 
     */
    public ExternalNamespaceRequest createExternalNamespaceRequest() {
        return new ExternalNamespaceRequest();
    }

    /**
     * Create an instance of {@link ProjectObjectKey }
     * 
     */
    public ProjectObjectKey createProjectObjectKey() {
        return new ProjectObjectKey();
    }

    /**
     * Create an instance of {@link ExternalNamespace }
     * 
     */
    public ExternalNamespace createExternalNamespace() {
        return new ExternalNamespace();
    }

    /**
     * Create an instance of {@link ComponentObjectKey }
     * 
     */
    public ComponentObjectKey createComponentObjectKey() {
        return new ComponentObjectKey();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetExternalNamespaceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "getExternalNamespaceResponse")
    public JAXBElement<GetExternalNamespaceResponse> createGetExternalNamespaceResponse(GetExternalNamespaceResponse value) {
        return new JAXBElement<GetExternalNamespaceResponse>(_GetExternalNamespaceResponse_QNAME, GetExternalNamespaceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetObjectIdByExternalId }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "getObjectIdByExternalId")
    public JAXBElement<GetObjectIdByExternalId> createGetObjectIdByExternalId(GetObjectIdByExternalId value) {
        return new JAXBElement<GetObjectIdByExternalId>(_GetObjectIdByExternalId_QNAME, GetObjectIdByExternalId.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateExternalIdMapping }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "createExternalIdMapping")
    public JAXBElement<CreateExternalIdMapping> createCreateExternalIdMapping(CreateExternalIdMapping value) {
        return new JAXBElement<CreateExternalIdMapping>(_CreateExternalIdMapping_QNAME, CreateExternalIdMapping.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteExternalNamespaceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "deleteExternalNamespaceResponse")
    public JAXBElement<DeleteExternalNamespaceResponse> createDeleteExternalNamespaceResponse(DeleteExternalNamespaceResponse value) {
        return new JAXBElement<DeleteExternalNamespaceResponse>(_DeleteExternalNamespaceResponse_QNAME, DeleteExternalNamespaceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateExternalNamespaceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "createExternalNamespaceResponse")
    public JAXBElement<CreateExternalNamespaceResponse> createCreateExternalNamespaceResponse(CreateExternalNamespaceResponse value) {
        return new JAXBElement<CreateExternalNamespaceResponse>(_CreateExternalNamespaceResponse_QNAME, CreateExternalNamespaceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteExternalIdMappingResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "deleteExternalIdMappingResponse")
    public JAXBElement<DeleteExternalIdMappingResponse> createDeleteExternalIdMappingResponse(DeleteExternalIdMappingResponse value) {
        return new JAXBElement<DeleteExternalIdMappingResponse>(_DeleteExternalIdMappingResponse_QNAME, DeleteExternalIdMappingResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteExternalIdMapping }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "deleteExternalIdMapping")
    public JAXBElement<DeleteExternalIdMapping> createDeleteExternalIdMapping(DeleteExternalIdMapping value) {
        return new JAXBElement<DeleteExternalIdMapping>(_DeleteExternalIdMapping_QNAME, DeleteExternalIdMapping.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateExternalNamespace }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "createExternalNamespace")
    public JAXBElement<CreateExternalNamespace> createCreateExternalNamespace(CreateExternalNamespace value) {
        return new JAXBElement<CreateExternalNamespace>(_CreateExternalNamespace_QNAME, CreateExternalNamespace.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteExternalNamespace }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "deleteExternalNamespace")
    public JAXBElement<DeleteExternalNamespace> createDeleteExternalNamespace(DeleteExternalNamespace value) {
        return new JAXBElement<DeleteExternalNamespace>(_DeleteExternalNamespace_QNAME, DeleteExternalNamespace.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetExternalNamespace }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "getExternalNamespace")
    public JAXBElement<GetExternalNamespace> createGetExternalNamespace(GetExternalNamespace value) {
        return new JAXBElement<GetExternalNamespace>(_GetExternalNamespace_QNAME, GetExternalNamespace.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CreateExternalIdMappingResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "createExternalIdMappingResponse")
    public JAXBElement<CreateExternalIdMappingResponse> createCreateExternalIdMappingResponse(CreateExternalIdMappingResponse value) {
        return new JAXBElement<CreateExternalIdMappingResponse>(_CreateExternalIdMappingResponse_QNAME, CreateExternalIdMappingResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateExternalNamespaceResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "updateExternalNamespaceResponse")
    public JAXBElement<UpdateExternalNamespaceResponse> createUpdateExternalNamespaceResponse(UpdateExternalNamespaceResponse value) {
        return new JAXBElement<UpdateExternalNamespaceResponse>(_UpdateExternalNamespaceResponse_QNAME, UpdateExternalNamespaceResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link UpdateExternalNamespace }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "updateExternalNamespace")
    public JAXBElement<UpdateExternalNamespace> createUpdateExternalNamespace(UpdateExternalNamespace value) {
        return new JAXBElement<UpdateExternalNamespace>(_UpdateExternalNamespace_QNAME, UpdateExternalNamespace.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetObjectIdByExternalIdResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:protex.blackducksoftware.com:sdk:v6.3:externalid", name = "getObjectIdByExternalIdResponse")
    public JAXBElement<GetObjectIdByExternalIdResponse> createGetObjectIdByExternalIdResponse(GetObjectIdByExternalIdResponse value) {
        return new JAXBElement<GetObjectIdByExternalIdResponse>(_GetObjectIdByExternalIdResponse_QNAME, GetObjectIdByExternalIdResponse.class, null, value);
    }

}
