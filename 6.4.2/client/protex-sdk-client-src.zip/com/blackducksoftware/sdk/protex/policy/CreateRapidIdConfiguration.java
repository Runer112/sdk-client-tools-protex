
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;
import com.blackducksoftware.sdk.protex.common.RapidIdConfigurationRequest;


/**
 * <p>Java class for createRapidIdConfiguration complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="createRapidIdConfiguration">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="rapidIdConfigurationRequest" type="{urn:protex.blackducksoftware.com:sdk:v6.3:common}rapidIdConfigurationRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "createRapidIdConfiguration", propOrder = {
    "rapidIdConfigurationRequest"
})
public class CreateRapidIdConfiguration {

    protected RapidIdConfigurationRequest rapidIdConfigurationRequest;

    /**
     * Gets the value of the rapidIdConfigurationRequest property.
     * 
     * @return
     *     possible object is
     *     {@link RapidIdConfigurationRequest }
     *     
     */
    public RapidIdConfigurationRequest getRapidIdConfigurationRequest() {
        return rapidIdConfigurationRequest;
    }

    /**
     * Sets the value of the rapidIdConfigurationRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link RapidIdConfigurationRequest }
     *     
     */
    public void setRapidIdConfigurationRequest(RapidIdConfigurationRequest value) {
        this.rapidIdConfigurationRequest = value;
    }

}
