
package com.blackducksoftware.sdk.protex.policy;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for deleteRapidIdConfiguration complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="deleteRapidIdConfiguration">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="rapidIdConfigurationId" type="{http://www.w3.org/2001/XMLSchema}long" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "deleteRapidIdConfiguration", propOrder = {
    "rapidIdConfigurationId"
})
public class DeleteRapidIdConfiguration {

    protected Long rapidIdConfigurationId;

    /**
     * Gets the value of the rapidIdConfigurationId property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getRapidIdConfigurationId() {
        return rapidIdConfigurationId;
    }

    /**
     * Sets the value of the rapidIdConfigurationId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setRapidIdConfigurationId(Long value) {
        this.rapidIdConfigurationId = value;
    }

}
